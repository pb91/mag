## Project Name
Magneto

## Project Description
The objective of this project to implement remote monitoring solution for plants that will address the Energy or Power Consumption use case. 

To achieve this goal it is required to measure and monitor energy parameter at source and consumption. Energy metering and real-time energy monitoring is the first step for measuring energy consumption and energy savings. 

Total energy usage across is measured at each source, monitored and managed for better energy efficiency. The initial focus is energy metering and real-time monitoring, which is crucial for taking control of main drivers of energy cost savings

## How to run
To run this project, you’ll need to install [node 5 and above](https://nodejs.org/en/). The latest version of Node.js is recommended. 
Go to project location and run 'npm start' in command prompt.
After success open 'http://localhost:4200/' in Browser. 


## FEATURES ADDED
1. Angular 7.1.4.
2. Ngrx implementation.
3. Basic routing.
4. Menu Navigation.
5. Folder structure.
6. Basic layout.
