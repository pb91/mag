import 'jest-preset-angular';
import './globalMocks';
