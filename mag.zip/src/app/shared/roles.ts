export const Roles = {
    "Dashboard" : {
      "view": [
        "ProductManagement", "SalesTeam", "GlobalAdmin", "AdopterAdmin"
      ]
    },
    "Plant": {
      "view": [
        "ProductManagement",
        "PlantAdmin",
        "GlobalAdmin",
        "SalesTeam",
        "PlantSupervisor",
        "AdopterAdmin",
        "PlantUser"
      ]
    },
    "Department": {
      "view": [
        "ProductManagement", "PlantAdmin", "SalesTeam",
        "PlantSupervisor","GlobalAdmin","AdopterAdmin","PlantUser"
      ]
    },
    "Equipment": {
      "view": [
        "ProductManagement", "PlantAdmin","SalesTeam",
        "PlantSupervisor","GlobalAdmin","EquipmentOperator", "AdopterAdmin","PlantUser"
      ]
    },
    "Alarms": {
      "view": [
        "ProductManagement", "PlantAdmin", "SalesTeam",
        "PlantSupervisor","GlobalAdmin", "AdopterAdmin","PlantUser"
      ]
    },
    "Category": {
      "view": [
        "ProductManagement", "PlantAdmin", "SalesTeam",
        "PlantSupervisor","GlobalAdmin", "AdopterAdmin","PlantUser"
      ],
      "create": [
        "ProductManagement", "PlantAdmin", "SalesTeam",
        "PlantSupervisor","GlobalAdmin", "AdopterAdmin"
      ]
    },
    "FloorPlan":{
      "view": [
        "ProductManagement", "PlantAdmin", "SalesTeam",
        "PlantSupervisor","GlobalAdmin", "AdopterAdmin","PlantUser"
      ],
      "Edit" : [ "ProductManagement", "PlantAdmin", "SalesTeam",
      "PlantSupervisor","GlobalAdmin", "AdopterAdmin"]
    },
    "SiteUsersList": {
      "view": [
        "PlantAdmin"
      ]
    },
    "UsersList": {
      "view": [
        "GlobalAdmin", "AdopterAdmin"
      ]
    },
    "SiteList": {
      "view": [
        "GlobalAdmin", "AdopterAdmin"
      ]
    },
    "DeviceList": {
      "view": [
        "GlobalAdmin", "AdopterAdmin", "PlantAdmin", "PlantUser"
      ],
      "addupdate": [
        "GlobalAdmin", "AdopterAdmin", "PlantAdmin"
      ]
    },
    "CreateUser": {
      "view": [
        "GlobalAdmin", "AdopterAdmin", "PlantAdmin"]
    },
    "activityLogs": {
      "view": [
        "GlobalAdmin", "AdopterAdmin"]
    },
    "siteHierarchy" : {
      "view": [
        "ProductManagement", "PlantAdmin","SalesTeam",
        "PlantSupervisor","GlobalAdmin","EquipmentOperator", "AdopterAdmin"]
    }
  };