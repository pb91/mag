import { Directive , ElementRef } from '@angular/core';
import { ResizeSensor } from 'css-element-queries';
import { Store } from '@ngrx/store';
import * as fromStore from '../globalStore';
import {SidebarResizeService} from './sidebar-resize.service'

@Directive({
  selector: '[appSideBarResizeEmmiter]'
})
export class SideBarResizeEmmiterDirective {

  
  private oldWidth: number;
  private oldHeight: number;
  constructor(private _elRef:ElementRef,  private store: Store<fromStore.ContainerState>, private SidebarResizeService : SidebarResizeService) { }

  ngOnInit() {
    // tslint:disable-next-line:no-unused-expression
    new ResizeSensor(this._elRef.nativeElement, _ => this.onResized());
    this.onResized();
  }

  private onResized() {
    const newWidth = this._elRef.nativeElement.clientWidth;
    const newHeight = this._elRef.nativeElement.clientHeight;

    if (newWidth === this.oldWidth && newHeight === this.oldHeight) {
      return;
    }else{
    
        // send message to subscribers via observable subject
        this.SidebarResizeService.sendMessage(newWidth);
    
     // this.store.dispatch(new fromStore.SideBarToggle(newWidth));
    }

    // console.log("newWidth", newWidth);
    // console.log("newHeight", newHeight);
    // console.log("  this.oldWidth",   this.oldWidth);
    // console.log("this.oldHeight", this.oldHeight);

    this.oldWidth = this._elRef.nativeElement.clientWidth;
    this.oldHeight = this._elRef.nativeElement.clientHeight;

  
  }

}
