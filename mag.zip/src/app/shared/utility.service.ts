import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { Roles  } from '../../app/shared/roles';
import { Router } from '@angular/router';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  constructor(private router: Router) { }

  // Get Summary Details
  getSummaryData(dataCollection: any){
   if(dataCollection &&  dataCollection.value instanceof Array){
        return dataCollection.value;
   }
  }

  // to get the sum of value from array
  getAggregateValue(array, key) {
    let sum = _.sumBy(array, function (item) {
      return item[key];
    });
    return _.isNumber(sum) ? sum.toFixed(2) : 0;
  }

  roundNumber(value:any, decimalPlace:number) {
    var number = typeof value  === "string" ? this.isNumeric(value) ? parseFloat(value) : 0 : value;

    if(number === null) { return 0; }
    if(typeof number == "undefined") { return 0; }

    var decimalValue = !decimalPlace ? 2 : decimalPlace;
    let result = number.toFixed(decimalValue);
    let convertedResult = parseFloat(result);
    return convertedResult;
  }
    
  isNumeric(num){
    return !isNaN(num);
  }

  // Search the given text from array of object
  searchByText(collection, text, exclude) {
    text = _.toLower(text);
    return _.filter(collection, function(object) {
      return _(object).omit(exclude).some(function(string) {
        return _(string).toLower().includes(text);
      });
    });
  }

  // Format data for dropdown keymap
  formatDataDropDown(collection, keymap) {
   return collection.map(function(obj) {
      return _.mapKeys(obj, function(value, key) {
        return keymap[key];
      });
    });
  }

 // Return the object from nested array of object.
  findObjects(obj, targetProp, targetValue, finalResults) {
    function getObject(theObject) {
      let result = null;
      if (theObject instanceof Array) {
        for (let i = 0; i < theObject.length; i++) {
          getObject(theObject[i]);
        }
      } else {
        for (let prop in theObject) {
          if (theObject.hasOwnProperty(prop)) {
            if (prop === targetProp) {
              if (theObject[prop] === targetValue) {
                finalResults.push(theObject);
              }
            }
            if (theObject[prop] instanceof Object || theObject[prop] instanceof Array) {
              getObject(theObject[prop]);
            }
          }
        }
      }
    }
    getObject(obj);
  }
   
  // Change the object value and key, to format the data for display in tree structure.
  toMap(data, name, value) {
    return _.reduce(data, function(acc, item) {
        acc[item[name]] = item[value];
        return acc;
    }, {});
  }

  // Difference between two days
  daysDifference(from: string, to: string) {
    let fromDate = new Date(from);
    let toDate = new Date(to);
    const timeDiff = Math.abs(toDate.getTime() - fromDate.getTime());
    const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
    return diffDays;
  }

    // Interval toggle button display
    getInteralOptions(days: number) {
      let intervalOptions = {};
      
      if(days == 1){
        intervalOptions = {
          minute : false,
          daily: true,
          hourly : false,
          weekly : true,
          monthly : true
        }
      } else if(days > 1 && days <= 14) {
        intervalOptions = {
          minute : false,
          daily: false,
          hourly : false,
          weekly : true,
          monthly : true
        }
      }  else if(days > 14 && days <= 31) {
      intervalOptions = {
        minute : false,
        daily: false,
        hourly : false,
        weekly : false,
        monthly : true
      }
    } else if(days > 31 && days <= 90) {
      intervalOptions = {
        minute : false,
        daily: false,
        hourly : false,
        weekly : false,
        monthly : false
      }
    } else if(days > 90 && days <= 365) {
      intervalOptions = {
        minute : true,
        daily: true,
        hourly : true,
        weekly : false,
        monthly : false
      }
    } else if(days >= 365) { 
      intervalOptions = {
        minute : true,
        daily: true,
        hourly : true,
        weekly : false,
        monthly : false
      }
    } else {
      intervalOptions = {
        minute : true,
        daily: true,
        hourly : true,
        weekly : true,
        monthly : true
      }
    }
      return intervalOptions;
    }

    // This function will return first false key in object
    findKey(object: object){
      if(!object['hourly']) { return 'hourly'; }
      if(!object['daily']) { return 'daily'; }
      if(!object['weekly']) { return 'weekly'; }
      if(!object['monthly']) { return 'monthly'; }
  }

  validateURL(page:string[]) {
    let checkRoles  = localStorage.getItem('userRoles');    
    var rolesArray = checkRoles.split(',');
    let presentArray = _.intersection(rolesArray, page);
    return _.size(presentArray) > 0 ? true : false;
  }

  redirectBasedonRoles(plantId:String){
    if(this.validateURL(Roles.Plant.view)) {
      this.router.navigate(['/plantsummary/' + plantId]);
    } else if(this.validateURL(Roles.Department.view)) {
      this.router.navigate(['/department/' + plantId]);
    } else if(this.validateURL(Roles.Equipment.view)) {
      this.router.navigate(['/equipment/' + plantId]);
    } else {
      this.router.navigate(['/planthierarachy/' + plantId]);
    }
  }

  returnHyperLink(plantId:String){
    if(this.validateURL(Roles.Plant.view)) {
      return `/plantsummary/${plantId}`;
    } else if(this.validateURL(Roles.Department.view)) {
      return `/department/${plantId}`;
    } else if(this.validateURL(Roles.Equipment.view)) {
      return `/equipment/${plantId}`;
    } else {
      return `/planthierarachy/${plantId}`;
    }
  }

  calcMegaWatt(consumption:any, units:string){
    let roundConsumption = typeof consumption == "number" && Math.floor(consumption);
    if(_.size(roundConsumption.toString()) >= 7) {
      let meagWatt = consumption / 1000;
      return {consumption: meagWatt.toFixed(2), units:  'MWh'}
    }  
    return {consumption: consumption, units:  units}
  }

  // Default date value selection for from and to time to call inital API.
  getDateRange() {
    let dateRange = {startDate: moment().subtract(7, 'days')};
    var start = new Date(moment(dateRange.startDate).format('YYYY-MM-DD'));
    start.setHours(0,0,0,0);
    var end = new Date();
    end.setHours(23,59,59,999);
    return { fromDate: moment.utc(start).format(), toDate: moment.utc(end).format()  }
  }

  // Default date value selection for date picker.
  getDefaultDate() {
    return {startDate: moment().subtract(7, 'days'), endDate:  moment(new Date())};
  }

  displayMessage(module: string, type: string) {
    switch (type) {
      case 'edit': {
        return `${module} Updated Successfully`;
      }
      case 'create': {
        return `${module} Created Successfully`;
      }
      case 'delete': {
        return `${module} Deleted Successfully`;
      }
    }
  }

  displayChartTitle(chartType: string) {
    switch (chartType) {
      case 'energyCostConsumption': {
        let units = "kWh";
        return { title : `Energy Consumption (kWh) and Energy Cost ($)` , units : units };
      }
      case 'carbonFootprint': {
        let units = "kg";
        return { title : `Carbon Footprint (${units})` , units : units };
      }
      case 'energyConsumption': {
        let units = "kWh";
        return { title : `Energy Consumption (${units})` , units : units  };
      }
      case 'loadPattern': {
        let units = "kW";
        return { title : `Load Pattern (${units})` , units : units  };
      }
      case 'utilization': {
        let units = "%";
        return { title : `Availability and Utilization (${units})` , units : units  };
      }
      case 'powerFactor': {
        let units = "";
        return { title : `Power Factor` , units : units  };
      }
      case 'demandChart': {
        let units = "kW";
        return { title : `Power Demand (${units}) and Peak Demand (${units})` , units : units  };
      }
      case 'globalSaving' : {
        let units= '$';
        return { title : `Global Energy Saving (${units})`, units : units}
      }
      case 'globalConsumption' : {
        let units= 'kWh';
        return { title : `Global Energy Consumption (${units})`, units : units}
      }

    }
  }
}