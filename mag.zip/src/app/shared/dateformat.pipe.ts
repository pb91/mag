import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({
  name: 'dateformat'
})
export class DateformatPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if(value != null && value != 'NAN' ) {
      var gmtDateTime = moment.utc(value);
      if(gmtDateTime.isValid()) {
      let local = gmtDateTime.local().valueOf();
      return moment(local).format('llll');
      }
      return "";
    }
    return "";
  }
}