import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'firstcharupper' })

export class FirstCharUpperPipe implements PipeTransform {
  transform(value) {

    return value[0].toUpperCase() + value.substring(1,(value.length));
  }
}