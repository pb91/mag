import { MediaMatcher } from '@angular/cdk/layout';
import { Router, ActivatedRoute } from '@angular/router';
import {MatDialog, MatDialogRef} from '@angular/material';
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';

import { AuthenticationService } from '@appServices/authentication.service';
import { NavigationService } from '@appServices/navigation.service';
import { User } from '@appModels/user';
import { UtilityService  } from '../app/shared/utility.service';
import { WindowRef  } from '../app/shared/WindowRef';
import { environment } from 'environments/environment';

// Store
import { Store } from '@ngrx/store';
import * as fromStore from './globalStore';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  navigationContent = [];
  preferences = [];
  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  hovering = false;
  hasLeft = true;
  open = false;
  userMenu = false; // toggles menu mode on mobile
  logout = false;
  title =  environment.webApp.magneto ? "Magneto" :  "PX-EVA";
  version: string = environment.version;
  currentUser: User;
  private activeRoute: Router;
 private window:object;
  constructor(
    private winRef: WindowRef,
    private utils: UtilityService,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private router: Router,
    private _navigationService: NavigationService,
    private changeDetectorRef: ChangeDetectorRef,
    private media: MediaMatcher,
    private authenticationService: AuthenticationService,
    private store: Store<fromStore.ContainerState>,
  ) {
    this.window = this.winRef.nativeWindow;
 }

 ngAfterContentInit() {
    let self = this;
    this.router.events.subscribe( (event) => {
        let location = this.window['location'].href;
       if(location.includes("sign-in") || location.includes("dashboard")) {
        self.hovering = false;
        self.hasLeft = true;
        self.open = false;
        self.userMenu = false; // toggles menu mode on mobile
        self.logout = false;
       }
    });
 }

  ngOnInit() {
    this.mobileQuery = this.media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => this.changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this._navigationService.navToggled$.subscribe(value => {
      this.open = !this.open;
    });
    this.authenticationService.currentUser.subscribe(
      x => (this.currentUser = x)
    );

    setTimeout(()=>{
      this.store.select<any>('preference').subscribe(state => {
        this.navigationContent = state.data.navigation;
        this.preferences = state.data.preference;
      });
    }, 5 );
 }

  openChanged(value) {
    if (this.mobileQuery.matches) {
      this.open = value;
    }
  }

  leave() {
  //  this.hovering = false;
  //  this.hasLeft = true;
  }
  
  enter() {
    // if (this.hasLeft) {
    //   this.hovering = true;
    // }
    // this.hasLeft = false;
  }

  toggleDesktop() {
    this.open = !this.open;
    if (!this.open) {
      this.hovering = false;
    }
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }
  openDialog(): void {
    const dialogRef = this.dialog.open(LogoutConfirmMobileDialog);    
    dialogRef.afterClosed().subscribe(result => {
      this.hovering = false;
      this.hasLeft = true;
      this.open = false;
      this.userMenu = false; // toggles menu mode on mobile
      this.logout = false;
    });
  }
}

@Component({
  selector: 'logout-confirm-mobile-dialog',
  templateUrl: 'logout-confirm-mobile-dialog.html',
})
export class LogoutConfirmMobileDialog {
  logout = false;
  hovering = false;
  open = false;
  public loading: boolean;
  isDisabled: boolean;
  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<LogoutConfirmMobileDialog>,
    private store: Store<fromStore.ContainerState>,
    private authenticationService: AuthenticationService,
    private router: Router,
  ) {
    dialogRef.disableClose = true;
  }

    cancelLogout(): void {
      this.dialogRef.close();
    }
    onLogoutClick() {      
      this.isDisabled = true;
      this.loading = true;
      this.store.dispatch(new fromStore.ResetPreference());
      this.authenticationService.logout().subscribe(state => {
        this.loading = false;
        this.logout = true;
        this.open  =  false;
        this.hovering  =  false;
        this.dialogRef.close();
        this.router.navigateByUrl('sign-in');
      }, error => {
        this.isDisabled = false;
        this.loading = false;
        this.dialogRef.close();
      });   
    }
}