
import { Action } from '@ngrx/store';

import { Dashboard } from '../../models/dashboard/dashboard.model';

// Define Actions
export const LOAD_DASHBOARD = '[Dashboard] Load Dashboard';
export const LOAD_DASHBOARD_FAIL = '[Dashboard] Load Dashboard Fail';
export const LOAD_DASHBOARD_SUCCESS = '[Dashboard] Load Dashboard Success';

//Global dashboard 
export const LOAD_GLOBAL_ENGSAVING= '[Dashboard] Load Energy Saving';
export const LOAD_GLOBAL_ENGSAVING_FAIL = '[Dashboard] Load Energy Saving Fail';
export const LOAD_GLOBAL_ENGSAVING_SUCCESS = '[Dashboard] Load Energy Saving Success';
export const LOAD_GLOBAL_ENGCONSUMPTION= '[Dashboard] Load Energy Consumption';
export const LOAD_GLOBAL_ENGCONSUMPTION_FAIL = '[Dashboard] Load Energy Consumption Fail';
export const LOAD_GLOBAL_ENGCONSUMPTION_SUCCESS = '[Dashboard] Load Energy Consumption Success';


// Define Action Creators
export class LoadDashboard implements Action {
    readonly type = LOAD_DASHBOARD;
    constructor()  {}
}

export class LoadDashboardFail implements Action {
    readonly type = LOAD_DASHBOARD_FAIL;
    constructor(public payload: any)  {}
}

export class LoadDashboardSuccess implements Action {
    readonly type = LOAD_DASHBOARD_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEnergySaving implements Action {
    readonly type = LOAD_GLOBAL_ENGSAVING;
    constructor(public from : string , public to : string, public id : string,public kpi : string )  {
    }
}

export class LoadEnergySavingFail implements Action {
    readonly type = LOAD_GLOBAL_ENGSAVING_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEnergySavingSuccess implements Action {
    readonly type = LOAD_GLOBAL_ENGSAVING_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEnergyConsumption implements Action {
    readonly type = LOAD_GLOBAL_ENGCONSUMPTION;
    constructor(public from : string , public to : string, public id : string,public kpi : string )  {
    }
}

export class LoadEnergyConsumptionFail implements Action {
    readonly type = LOAD_GLOBAL_ENGCONSUMPTION_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEnergyConsumptionSuccess implements Action {
    readonly type = LOAD_GLOBAL_ENGCONSUMPTION_SUCCESS;
    constructor(public payload: any)  {}
}

export type DashboardAction = LoadDashboard | LoadDashboardFail | LoadDashboardSuccess | LoadEnergySaving | LoadEnergySavingFail | LoadEnergySavingSuccess | LoadEnergyConsumption | LoadEnergyConsumptionFail | LoadEnergyConsumptionSuccess ;
