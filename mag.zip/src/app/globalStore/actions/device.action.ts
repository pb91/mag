import { Action } from '@ngrx/store';

// Define Actions
export const LOAD_DEVICE_DETAILS = '[DEVICE] Load Device Details';
export const LOAD_DEVICE_DETAILS_SUCCESS = '[DEVICE] Load Device Details Success';
export const LOAD_DEVICE_DETAILS_FAIL = '[DEVICE] Load Device Details Fail';
export const LOAD_RESET_DEVICE = '[Equipment] Load Reset Device';


export const LOAD_DEVICE_LIST = '[device] Load Device List';
export const LOAD_DEVICE_FAIL = '[device] Load Device Fail';
export const LOAD_DEVICE_SUCCESS = '[device] Load Device Success';
export const LOAD_RESET_DEVICE_DETAILS = '[device] Load Device Details Success';

// Define Action Creators

export class ResetDevice implements Action {
    readonly type = LOAD_RESET_DEVICE;
    constructor()  {}
}

export class ResetDeviceDetails implements Action {
    readonly type = LOAD_RESET_DEVICE_DETAILS;
    constructor()  {}
}

export class LoadDeviceList implements Action {
    readonly type = LOAD_DEVICE_LIST;
    constructor(public plantId: string)  { }
}

export class LoadDeviceListSuccess implements Action {
    readonly type = LOAD_DEVICE_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeviceListFail implements Action {
    readonly type = LOAD_DEVICE_FAIL;
    constructor(public payload: any)  {}
}


export class LoadDeviceDetails implements Action {
    readonly type = LOAD_DEVICE_DETAILS;
    constructor(public deviceId: string, public plantId: string)  { }
}

export class LoadDeviceDetailsSuccess implements Action {
    readonly type = LOAD_DEVICE_DETAILS_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeviceDetailsFail implements Action {
    readonly type = LOAD_DEVICE_DETAILS_FAIL;
    constructor(public payload: any)  {}
}

export type DeviceAction = ResetDeviceDetails | LoadDeviceList | LoadDeviceListSuccess | LoadDeviceListFail | ResetDevice | LoadDeviceDetails | LoadDeviceDetailsSuccess | LoadDeviceDetailsFail;
