import { Action } from '@ngrx/store';

// Define Actions
export const LOAD_PLANTS_USER = '[user] Load Plants';
export const LOAD_PLANTS_USER_FAIL = '[user] Load Plants Fail';
export const LOAD_PLANTS_USER_SUCCESS = '[user] Load Plants Success';

export const LOAD_USER = '[user] Load Users';
export const LOAD_USER_FAIL = '[user] Load Users Fail';
export const LOAD_USER_SUCCESS = '[user] Load Users Success';
export const CLEAR_USER = '[user] Clear Users';
export const SELECTED_USER = '[user] Selected Users ';
export const SELECTED_USER_SUCCESS = '[user] Selected Users Success';
export const SELECTED_USER_FAIL = '[user] Selected Users Fail';



export const SELECTED_PLANT = '[user] Selected Plant ';
export const SELECTED_PLANT_SUCCESS = '[user] Selected Plant Success';
export const SELECTED_PLANT_FAIL = '[user] Selected Plant Fail';



// Define Action Creators
export class LoadPlants implements Action {
    readonly type = LOAD_PLANTS_USER;
    constructor()  { }
}

export class LoadPlantsSuccess implements Action {
    readonly type = LOAD_PLANTS_USER_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadPlantsFail implements Action {
    readonly type = LOAD_PLANTS_USER_FAIL;
    constructor(public payload: any)  {}
}

// Define Action Creators
export class LoadUsers implements Action {
    readonly type = LOAD_USER;
    constructor(public plantId) {}
}

// Define Action Creators
export class ClearUser implements Action {
    readonly type = CLEAR_USER;
    constructor() {}
}

export class LoadUsersSuccess implements Action {
    readonly type = LOAD_USER_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadUsersFail implements Action {
    readonly type = LOAD_USER_FAIL;
    constructor(public payload: any)  {}
}

export class SelectedUser implements Action {
    readonly type = SELECTED_USER;
    constructor(public id: any, public plantId: any)  {
      
    }
}

export class SelectedUserSuccess implements Action {
    readonly type = SELECTED_USER_SUCCESS;
    constructor(public payload: any)  {
      
    }
}

export class SelectedUserFail implements Action {
    readonly type = SELECTED_USER_FAIL;
    constructor(public payload: any)  {
    
    }
}

export class SelectedPlant implements Action {
    readonly type = SELECTED_PLANT;
    constructor(public id: any)  {
      
    }
}

export class SelectedPlantSuccess implements Action {
    readonly type = SELECTED_PLANT_SUCCESS;
    constructor(public payload: any)  {
      
    }
}

export class SelectedPlantFail implements Action {
    readonly type = SELECTED_PLANT_FAIL;
    constructor(public payload: any)  {
    
    }
}


export type UsermanagementAction =  ClearUser | SelectedPlant  | SelectedPlantSuccess  | SelectedPlantFail   | SelectedUser | SelectedUserSuccess | SelectedUserFail | LoadPlants | LoadPlantsSuccess | LoadPlantsFail | LoadUsers | LoadUsersSuccess | LoadUsersFail;
