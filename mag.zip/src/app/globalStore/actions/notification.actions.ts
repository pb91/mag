
import { Action } from '@ngrx/store';

import { Notifications } from '../../models/headerBar/notifications.model';

// Define Actions
export const LOAD_NOTIFICATIONS = '[Notifications] Load Notification';
export const LOAD_NOTIFICATIONS_FAIL = '[Notifications] Load Notification Fail';
export const LOAD_NOTIFICATIONS_SUCCESS = '[Notifications] Load Notification Success';

// Define Action Creators
export class LoadNotifications implements Action {
    readonly type = LOAD_NOTIFICATIONS;
}

export class LoadNotificationsFail implements Action {
    readonly type = LOAD_NOTIFICATIONS_FAIL;
    constructor(public payload: any)  {}
}

export class LoadNotificationsSuccess implements Action {
    readonly type = LOAD_NOTIFICATIONS_SUCCESS;
    constructor(public payload: Notifications)  {}
}

export type NotificationsAction = LoadNotifications | LoadNotificationsFail | LoadNotificationsSuccess;
