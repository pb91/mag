
import { Action } from '@ngrx/store';

import { CombinedNavigation } from '../../models/navigationBar/combined.model';

// Define Actions
export const LOAD_PREFERENCE = '[Preference] Load Preference';
export const UPDATE_PREFERENCE = '[Preference] Update Preference';
export const LOAD_PREFERENCE_FAIL = '[Preference] Load Preference Fail';
export const LOAD_PREFERENCE_SUCCESS = '[Preference] Load Preference Success';
export const RESET_PREFERENCE = '[Preference] Reset Preference';


// Define Action Creators
export class LoadPreference implements Action {
    readonly type = LOAD_PREFERENCE;
    constructor()  {}
}

export class ResetPreference implements Action {
    readonly type = RESET_PREFERENCE;
    constructor()  {}
}

export class UpdatePreference implements Action {
    readonly type = UPDATE_PREFERENCE;
    constructor(public plantId: string)  {
    }
}

export class LoadPreferenceFail implements Action {
    readonly type = LOAD_PREFERENCE_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPreferenceSuccess implements Action {
    readonly type = LOAD_PREFERENCE_SUCCESS;
    constructor(public payload: CombinedNavigation)  {}
}

export type PreferenceAction = ResetPreference | LoadPreference | UpdatePreference | LoadPreferenceFail | LoadPreferenceSuccess;