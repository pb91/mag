import { Action } from '@ngrx/store';
import { Plant } from '../../models/plantSummary/plant.model';

// Define Actions
export const LOAD_GET_PLANT = '[Plant] Load PlantDetails';
export const LOAD_PLANTSUMMARY_FAIL = '[Plant] Load PlantDetails Fail';
export const LOAD_PLANTSUMMARY_SUCCESS = '[Plant] Load PlantDetails Success';

export const LOAD_COSTCONSUM = '[CostConsum] Load CostConsum';
export const LOAD_COSTCONSUM_FAIL = '[CostConsum] Load CostConsum Fail';
export const LOAD_COSTCONSUM_SUCCESS = '[CostConsum] Load CostConsum Success';

export const LOAD_UTILITY = '[utility] Load Utility';
export const LOAD_UTILITY_FAIL = '[utility] Load Utility Fail';
export const LOAD_UTILITY_SUCCESS = '[utility] Load Utility Success';

export const LOAD_PLANT_CONSUMPTION = '[utility] Load Plant Consumption';
export const LOAD_PLANT_CONSUMPTION_FAIL = '[utility] Load Plant Consumption Fail';
export const LOAD_PLANT_CONSUMPTION_SUCCESS = '[utility] Load Plant Consumption Success';

export const LOAD_PLANT_ENERGYCOST = '[utility] Load Plant Energycost';
export const LOAD_PLANT_ENERGYCOST_FAIL = '[utility] Load Plant Energycost Fail';
export const LOAD_PLANT_ENERGYCOST_SUCCESS = '[utility] Load Plant Energycost Success';

export const LOAD_PLANT_ENERGYIDLING = '[utility] Load Plant Energyidling';
export const LOAD_PLANT_ENERGYIDLING_FAIL = '[utility] Load Plant Energyidling Fail';
export const LOAD_PLANT_ENERGYIDLING_SUCCESS = '[utility] Load Plant Energyidling Success';

export const LOAD_PLANT_CO2EMISSSION = '[utility] Load Plant Co2Emission';
export const LOAD_PLANT_CO2EMISSSION_FAIL = '[utility] Load Plant Co2Emission Fail';
export const LOAD_PLANT_CO2EMISSSION_SUCCESS = '[utility] Load Plant Co2Emission Success';

export const LOAD_PLANT_ENERGYCONSTREND = '[utility] Load Plant EnergyConsTrend';
export const LOAD_PLANT_ENERGYCONSTREND_FAIL = '[utility] Load Plant EnergyConsTrend Fail';
export const LOAD_PLANT_ENERGYCONSTREND_SUCCESS = '[utility] Load Plant EnergyConsTrend Success';

export const LOAD_PLANT_PATTERN = '[utility] Load Plant Pattern';
export const LOAD_PLANT_PATTERN_FAIL = '[utility] Load Plant Pattern Fail';
export const LOAD_PLANT_PATTERN_SUCCESS = '[utility] Load Plant Pattern Success';

export const LOAD_PLANT_ENERGYSAVING = '[utility] Load Plant Energysave';
export const LOAD_PLANT_ENERGYSAVING_FAIL = '[utility] Load Plant Energysave Fail';
export const LOAD_PLANT_ENERGYSAVING_SUCCESS = '[utility] Load Plant Energysave Success';

export const LOAD_RESET_PLANTSUMMARY = '[utility] Load Rest PlantSummary';
export const LOAD_RESET_PLANT = '[Plant] Load Plant Rest';

// Define Action Creators
export class LoadPlant implements Action {
    readonly type = LOAD_GET_PLANT;
    constructor(public plantId: any)  {
    }
}

export class LoadRestPlant implements Action {
    readonly type = LOAD_RESET_PLANT;
    constructor()  {
    }
}

export class ResetPlantSummary implements Action {
    readonly type = LOAD_RESET_PLANTSUMMARY;
    constructor()  {}
}

export class LoadPlantFail implements Action {
    readonly type = LOAD_PLANTSUMMARY_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPlantSuccess implements Action {
    readonly type = LOAD_PLANTSUMMARY_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadCostConsum implements Action {
    readonly type = LOAD_COSTCONSUM;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadCostConsumSuccess implements Action {
    readonly type = LOAD_COSTCONSUM_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadCostConsumFail implements Action {
    readonly type = LOAD_COSTCONSUM_FAIL;
    constructor(public payload: any)  {}
}

export class LoadUtility implements Action {
    readonly type = LOAD_UTILITY;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadUtilitySuccess implements Action {
    readonly type = LOAD_UTILITY_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadUtilityFail implements Action {
    readonly type = LOAD_UTILITY_FAIL;
    constructor(public payload: any)  {}
}


export class LoadPlantCunsupmtion implements Action {
    readonly type = LOAD_PLANT_CONSUMPTION;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}
export class LoadPlantCunsupmtionSuccess implements Action {
    readonly type = LOAD_PLANT_CONSUMPTION_SUCCESS;
    constructor(public payload: any)  {}
}
export class LoadPlantCunsupmtionFail implements Action {
    readonly type = LOAD_PLANT_CONSUMPTION_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPlantEnergyCost implements Action {
    readonly type = LOAD_PLANT_ENERGYCOST;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}
export class LoadPlantEnergyCostSuccess implements Action {
    readonly type = LOAD_PLANT_ENERGYCOST_SUCCESS;
    constructor(public payload: any)  {}
}
export class LoadPlantEnergyCostFail implements Action {
    readonly type = LOAD_PLANT_ENERGYCOST_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPlantEnergyIdling implements Action {
    readonly type = LOAD_PLANT_ENERGYIDLING;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}
export class LoadPlantEnergyIdlingSuccess implements Action {
    readonly type = LOAD_PLANT_ENERGYIDLING_SUCCESS;
    constructor(public payload: any)  {}
}
export class LoadPlantEnergyIdlingFail implements Action {
    readonly type = LOAD_PLANT_ENERGYIDLING_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPlantCo2Emission implements Action {
    readonly type = LOAD_PLANT_CO2EMISSSION;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}
export class LoadPlantCo2EmissionSuccess implements Action {
    readonly type = LOAD_PLANT_CO2EMISSSION_SUCCESS;
    constructor(public payload: any)  {}
}
export class LoadPlantCo2EmissionFail implements Action {
    readonly type = LOAD_PLANT_CO2EMISSSION_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPlantEngyConsTrend implements Action {
    readonly type = LOAD_PLANT_ENERGYCONSTREND;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}
export class LoadPlantEngyConsTrendSuccess implements Action {
    readonly type = LOAD_PLANT_ENERGYCONSTREND_SUCCESS;
    constructor(public payload: any)  {}
}
export class LoadPlantEngyConsTrendFail implements Action {
    readonly type = LOAD_PLANT_ENERGYCONSTREND_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPlantPattern implements Action {
    readonly type = LOAD_PLANT_PATTERN;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}
export class LoadPlantPatternSuccess implements Action {
    readonly type = LOAD_PLANT_PATTERN_SUCCESS;
    constructor(public payload: any)  {}
}
export class LoadPlantPatternFail implements Action {
    readonly type = LOAD_PLANT_PATTERN_FAIL;
    constructor(public payload: any)  {}
}

export class LoadPlantEnergySaving implements Action {
    readonly type = LOAD_PLANT_ENERGYSAVING;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}
export class LoadPlantEnergySavingSuccess implements Action {
    readonly type = LOAD_PLANT_ENERGYSAVING_SUCCESS;
    constructor(public payload: any)  {}
}
export class LoadPlantEnergySavingFail implements Action {
    readonly type = LOAD_PLANT_ENERGYSAVING_FAIL;
    constructor(public payload: any)  {}
}


export type PlantAction = LoadRestPlant | ResetPlantSummary | LoadPlant | LoadPlantFail | LoadPlantSuccess  | LoadUtility | LoadUtilitySuccess | LoadUtilityFail |
LoadCostConsum | LoadCostConsumFail | LoadCostConsumSuccess | LoadPlantCunsupmtion | LoadPlantCunsupmtionSuccess | LoadPlantCunsupmtionFail |
LoadPlantCo2Emission | LoadPlantCo2EmissionSuccess | LoadPlantCo2EmissionFail | LoadPlantEnergyCost | LoadPlantEnergyCostSuccess | LoadPlantEnergyCostFail |
LoadPlantEnergyIdling | LoadPlantEnergyIdlingSuccess | LoadPlantEnergyIdlingFail | LoadPlantEngyConsTrend | LoadPlantEngyConsTrendSuccess | LoadPlantEngyConsTrendFail |
LoadPlantPattern | LoadPlantPatternSuccess | LoadPlantPatternFail | LoadPlantEnergySaving | LoadPlantEnergySavingSuccess | LoadPlantEnergySavingFail;
