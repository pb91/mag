import { Action } from '@ngrx/store';

// Define Actions
export const LOAD_DEPT_COST = '[Department] Load Cost';
export const LOAD_DEPT_COST_SUCCESS = '[Department] Load Cost Success';
export const LOAD_DEPT_COST_FAIL = '[Department] Load Cost Fail';

export const LOAD_DEPT_IDLE = '[Department] Load Idle';
export const LOAD_DEPT_IDLE_SUCCESS = '[Department] Load Idle Success';
export const LOAD_DEPT_IDLE_FAIL = '[Department] Load Idle Fail';

export const LOAD_DEPT_SAVE = '[Department] Load Save';
export const LOAD_DEPT_SAVE_SUCCESS = '[Department] Load Save Success';
export const LOAD_DEPT_SAVE_FAIL = '[Department] Load Save Fail';

export const LOAD_DEPT_COSTCONSUM = '[Department] Load CostConsum';
export const LOAD_DEPT_COSTCONSUM_SUCCESS = '[Department] Load CostConsum Success';
export const LOAD_DEPT_COSTCONSUM_FAIL = '[Department] Load CostConsum Fail';

export const LOAD_DEPT_ENGCONSUM = '[Department] Load EngConsum';
export const LOAD_DEPT_ENGCONSUM_SUCCESS = '[Department] Load EngConsum Success';
export const LOAD_DEPT_ENGCONSUM_FAIL = '[Department] Load EngConsum Fail';

export const LOAD_DEPT_ENGCONSUMTREND = '[Department] Load EngConsumTrend';
export const LOAD_DEPT_ENGCONSUMTREND_SUCCESS = '[Department] Load EngConsumTrend Success';
export const LOAD_DEPT_ENGCONSUMTREND_FAIL = '[Department] Load EngConsumTrend Fail';

export const LOAD_DEPT_CO2 = '[Department] Load Co2';
export const LOAD_DEPT_CO2_SUCCESS = '[Department] Load Co2 Success';
export const LOAD_DEPT_CO2_FAIL = '[Department] Load Co2 Fail';

export const LOAD_DEPT_AVAUTILIZATION = '[Department] Load Utilization';
export const LOAD_DEPT_AVAUTILIZATION_SUCCESS = '[Department] Load Utilization Success';
export const LOAD_DEPT_AVAUTILIZATION_FAIL = '[Department] Load Utilization Fail';

export const LOAD_RESET_DEPARTSUMMARY = '[Department] Load Department Summary';

// Define Action Creators

export class LoadDeptIdle implements Action {
    readonly type = LOAD_DEPT_IDLE;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class ResetDepartSummary implements Action {
    readonly type = LOAD_RESET_DEPARTSUMMARY;
    constructor()  {}
}

export class LoadDeptIdleSuccess implements Action {
    readonly type = LOAD_DEPT_IDLE_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptIdleFail implements Action {
    readonly type = LOAD_DEPT_IDLE_FAIL;
    constructor(public payload: any)  {}
}

export class LoadDeptSave implements Action {
    readonly type = LOAD_DEPT_SAVE;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadDeptSaveSuccess implements Action {
    readonly type = LOAD_DEPT_SAVE_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptSaveFail implements Action {
    readonly type = LOAD_DEPT_SAVE_FAIL;
    constructor(public payload: any)  {}
}


export class LoadDeptCost implements Action {
    readonly type = LOAD_DEPT_COST;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadDeptCostSuccess implements Action {
    readonly type = LOAD_DEPT_COST_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptCostFail implements Action {
    readonly type = LOAD_DEPT_COST_FAIL;
    constructor(public payload: any)  {}
}

export class LoadDeptCostConsum implements Action {
    readonly type = LOAD_DEPT_COSTCONSUM;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadDeptCostConsumSuccess implements Action {
    readonly type = LOAD_DEPT_COSTCONSUM_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptCostConsumFail implements Action {
    readonly type = LOAD_DEPT_COSTCONSUM_FAIL;
    constructor(public payload: any)  {}
}

export class LoadDeptEngConsum implements Action {
    readonly type = LOAD_DEPT_ENGCONSUM;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadDeptEngConsumSuccess implements Action {
    readonly type = LOAD_DEPT_ENGCONSUM_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptEngConsumFail implements Action {
    readonly type = LOAD_DEPT_ENGCONSUM_FAIL;
    constructor(public payload: any)  {}
}

export class LoadDeptEngConsumTrend implements Action {
    readonly type = LOAD_DEPT_ENGCONSUMTREND;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadDeptEngConsumTrendSuccess implements Action {
    readonly type = LOAD_DEPT_ENGCONSUMTREND_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptEngConsumTrendFail implements Action {
    readonly type = LOAD_DEPT_ENGCONSUMTREND_FAIL;
    constructor(public payload: any)  {}
}

export class LoadDeptCo2 implements Action {
    readonly type = LOAD_DEPT_CO2;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadDeptCo2Success implements Action {
    readonly type = LOAD_DEPT_CO2_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptCo2Fail implements Action {
    readonly type = LOAD_DEPT_CO2_FAIL;
    constructor(public payload: any)  {}
}

export class LoadDeptAvaUtilization implements Action {
    readonly type = LOAD_DEPT_AVAUTILIZATION;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadDeptAvaUtilizationSuccess implements Action {
    readonly type = LOAD_DEPT_AVAUTILIZATION_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadDeptAvaUtilizationFail implements Action {
    readonly type = LOAD_DEPT_AVAUTILIZATION_FAIL;
    constructor(public payload: any)  {}
}

export type DepartmentAction = ResetDepartSummary | LoadDeptCost | LoadDeptCostSuccess | LoadDeptCostFail |
LoadDeptIdle | LoadDeptIdleSuccess | LoadDeptIdleFail |
LoadDeptSave | LoadDeptSaveSuccess | LoadDeptSaveFail |
LoadDeptCostConsum | LoadDeptCostConsumSuccess | LoadDeptCostConsumFail |
LoadDeptEngConsum | LoadDeptEngConsumSuccess | LoadDeptEngConsumFail |
LoadDeptEngConsumTrend | LoadDeptEngConsumTrendSuccess | LoadDeptEngConsumTrendFail |
LoadDeptCo2 | LoadDeptCo2Success | LoadDeptCo2Fail |
LoadDeptAvaUtilization | LoadDeptAvaUtilizationSuccess | LoadDeptAvaUtilizationFail