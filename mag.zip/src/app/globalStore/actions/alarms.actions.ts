import { Action } from '@ngrx/store';

// Define Actions
export const LOAD_ALARMS = '[Alarms] Load Alarms';
export const LOAD_ALARMS_FAIL = '[Alarms] Load Alarms Fail';
export const LOAD_ALARMS_SUCCESS = '[Alarms] Load Alarms Success';

// Define Action Creators
export class LoadAlarms implements Action {
    readonly type = LOAD_ALARMS;
    constructor(public plantId: string, public from: any, public to: any)  { }
}

export class LoadAlarmsSuccess implements Action {
    readonly type = LOAD_ALARMS_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadAlarmsFail implements Action {
    readonly type = LOAD_ALARMS_FAIL;
    constructor(public payload: any)  {}
}

export type AlarmsAction = LoadAlarms | LoadAlarmsSuccess | LoadAlarmsFail;
