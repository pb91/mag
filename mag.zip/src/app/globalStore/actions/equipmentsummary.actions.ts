import { Action } from '@ngrx/store';

// Define Actions
export const LOAD_EQUIP_COST = '[Equipment] Load Cost';
export const LOAD_EQUIP_COST_SUCCESS = '[Equipment] Load Cost Success';
export const LOAD_EQUIP_COST_FAIL = '[Equipment] Load Cost Fail';

export const LOAD_EQUIP_IDLE = '[Equipment] Load Idle';
export const LOAD_EQUIP_IDLE_SUCCESS = '[Equipment] Load Idle Success';
export const LOAD_EQUIP_IDLE_FAIL = '[Equipment] Load Idle Fail';

export const LOAD_EQUIP_SAVE = '[Equipment] Load Save';
export const LOAD_EQUIP_SAVE_SUCCESS = '[Equipment] Load Save Success';
export const LOAD_EQUIP_SAVE_FAIL = '[Equipment] Load Save Fail';

export const LOAD_EQUIP_ENGCONSUM = '[Equipment] Load EngConsum';
export const LOAD_EQUIP_ENGCONSUM_SUCCESS = '[Equipment] Load EngConsum Success';
export const LOAD_EQUIP_ENGCONSUM_FAIL = '[Equipment] Load EngConsum Fail';

export const LOAD_EQUIP_COSTCONSUM = '[Equipment] Load CostConsum';
export const LOAD_EQUIP_COSTCONSUM_SUCCESS = '[Equipment] Load CostConsum Success';
export const LOAD_EQUIP_COSTCONSUM_FAIL = '[Equipment] Load CostConsum Fail';


export const LOAD_EQUIP_ENGCONSUMTREND = '[Equipment] Load EngConsumTrend';
export const LOAD_EQUIP_ENGCONSUMTREND_SUCCESS = '[Equipment] Load EngConsumTrend Success';
export const LOAD_EQUIP_ENGCONSUMTREND_FAIL = '[Equipment] Load EngConsumTrend Fail';

export const LOAD_EQUIP_CO2 = '[Equipment] Load Co2';
export const LOAD_EQUIP_CO2_SUCCESS = '[Equipment] Load Co2 Success';
export const LOAD_EQUIP_CO2_FAIL = '[Equipment] Load Co2 Fail';

export const LOAD_EQUIP_AVAUTILIZATION = '[Equipment] Load Utilization';
export const LOAD_EQUIP_AVAUTILIZATION_SUCCESS = '[Equipment] Load Utilization Success';
export const LOAD_EQUIP_AVAUTILIZATION_FAIL = '[Equipment] Load Utilization Fail';

export const LOAD_EQUIP_DEVICESTATUS = '[Equipment] Load Device Status';
export const LOAD_EQUIP_DEVICESTATUS_SUCCESS = '[Equipment] Load Device Status Success';
export const LOAD_EQUIP_DEVICESTATUS_FAIL = '[Equipment] Load Device Status Fail';

export const LOAD_EQUIP_POWERFACTOR = '[Equipment] Load Power Factor';
export const LOAD_EQUIP_POWERFACTOR_SUCCESS = '[Equipment] Load Power Factor Success';
export const LOAD_EQUIP_POWERFACTOR_FAIL = '[Equipment] Load Power Factor Fail';

export const LOAD_EQUIP_PEAKDEMAND = '[Equipment] Load Peak Demand';
export const LOAD_EQUIP_PEAKDEMAND_SUCCESS = '[Equipment] Load Peak Demand Success';
export const LOAD_EQUIP_PEAKDEMAND_FAIL = '[Equipment] Load Peak Demand Fail';

export const LOAD_RESET_EQUIPSUMMARY = '[Equipment] Load Equip Summary';

// Define Action Creators

export class ResetEquipSummary implements Action {
    readonly type = LOAD_RESET_EQUIPSUMMARY;
    constructor()  {}
}

export class LoadEquipIdle implements Action {
    readonly type = LOAD_EQUIP_IDLE;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipIdleSuccess implements Action {
    readonly type = LOAD_EQUIP_IDLE_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipIdleFail implements Action {
    readonly type = LOAD_EQUIP_IDLE_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipSave implements Action {
    readonly type = LOAD_EQUIP_SAVE;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipSaveSuccess implements Action {
    readonly type = LOAD_EQUIP_SAVE_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipSaveFail implements Action {
    readonly type = LOAD_EQUIP_SAVE_FAIL;
    constructor(public payload: any)  {}
}


export class LoadEquipCost implements Action {
    readonly type = LOAD_EQUIP_COST;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipCostSuccess implements Action {
    readonly type = LOAD_EQUIP_COST_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipCostFail implements Action {
    readonly type = LOAD_EQUIP_COST_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipCostConsum implements Action {
    readonly type = LOAD_EQUIP_COSTCONSUM;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipCostConsumSuccess implements Action {
    readonly type = LOAD_EQUIP_COSTCONSUM_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipCostConsumFail implements Action {
    readonly type = LOAD_EQUIP_COSTCONSUM_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipEngConsum implements Action {
    readonly type = LOAD_EQUIP_ENGCONSUM;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipEngConsumSuccess implements Action {
    readonly type = LOAD_EQUIP_ENGCONSUM_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipEngConsumFail implements Action {
    readonly type = LOAD_EQUIP_ENGCONSUM_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipEngConsumTrend implements Action {
    readonly type = LOAD_EQUIP_ENGCONSUMTREND;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipEngConsumTrendSuccess implements Action {
    readonly type = LOAD_EQUIP_ENGCONSUMTREND_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipEngConsumTrendFail implements Action {
    readonly type = LOAD_EQUIP_ENGCONSUMTREND_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipCo2 implements Action {
    readonly type = LOAD_EQUIP_CO2;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipCo2Success implements Action {
    readonly type = LOAD_EQUIP_CO2_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipCo2Fail implements Action {
    readonly type = LOAD_EQUIP_CO2_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipAvaUtilization implements Action {
    readonly type = LOAD_EQUIP_AVAUTILIZATION;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipAvaUtilizationSuccess implements Action {
    readonly type = LOAD_EQUIP_AVAUTILIZATION_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipAvaUtilizationFail implements Action {
    readonly type = LOAD_EQUIP_AVAUTILIZATION_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipDeviceStatus implements Action {
    readonly type = LOAD_EQUIP_DEVICESTATUS;
    constructor(public plantId: string)  {
    }
}

export class LoadEquipDeviceStatusSuccess implements Action {
    readonly type = LOAD_EQUIP_DEVICESTATUS_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipDeviceStatusFail implements Action {
    readonly type = LOAD_EQUIP_DEVICESTATUS_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipPowerFactor implements Action {
    readonly type = LOAD_EQUIP_POWERFACTOR;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipPowerFactorSuccess implements Action {
    readonly type = LOAD_EQUIP_POWERFACTOR_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipPowerFactorFail implements Action {
    readonly type = LOAD_EQUIP_POWERFACTOR_FAIL;
    constructor(public payload: any)  {}
}

export class LoadEquipPeakDemand implements Action {
    readonly type = LOAD_EQUIP_PEAKDEMAND;
    constructor(public plantId: string, public trait: any, public tag: any,
        public from: any, public to: any, public id: any, public interval: any)  {
    }
}

export class LoadEquipPeakDemandSuccess implements Action {
    readonly type = LOAD_EQUIP_PEAKDEMAND_SUCCESS;
    constructor(public payload: any)  {}
}

export class LoadEquipPeakDemandFail implements Action {
    readonly type = LOAD_EQUIP_PEAKDEMAND_FAIL;
    constructor(public payload: any)  {}
}

export type EquipmentAction = ResetEquipSummary | LoadEquipCost | LoadEquipCostSuccess | LoadEquipCostFail |
LoadEquipIdle | LoadEquipIdleSuccess | LoadEquipIdleFail |
LoadEquipSave | LoadEquipSaveSuccess | LoadEquipSaveFail |
LoadEquipCostConsum | LoadEquipCostConsumSuccess | LoadEquipCostConsumFail |
LoadEquipEngConsum | LoadEquipEngConsumSuccess | LoadEquipEngConsumFail |
LoadEquipEngConsumTrend | LoadEquipEngConsumTrendSuccess | LoadEquipEngConsumTrendFail |
LoadEquipCo2 | LoadEquipCo2Success | LoadEquipCo2Fail |
LoadEquipAvaUtilization | LoadEquipAvaUtilizationSuccess | LoadEquipAvaUtilizationFail |
LoadEquipDeviceStatus | LoadEquipDeviceStatusSuccess | LoadEquipDeviceStatusFail |
LoadEquipPowerFactor | LoadEquipPowerFactorSuccess | LoadEquipPowerFactorFail |
LoadEquipPeakDemand | LoadEquipPeakDemandSuccess | LoadEquipPeakDemandFail