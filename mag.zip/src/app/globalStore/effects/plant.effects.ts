import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';
import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as PlantAction from '../actions/plantsummary.actions';
import * as fromServices from '../../services';

@Injectable()
export class PlantEffects {
    constructor(
        private actions$: Actions,
        private plantService: fromServices.PlantService 
    ) { }

    @Effect()
    loadPlants$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_GET_PLANT),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            return this.plantService
                .getPlantById(plantId)
                .pipe(
                    map(plants => new PlantAction.LoadPlantSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantFail(error)))
                );
        })
    );
   
    @Effect()
    loadCostConsum$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_COSTCONSUM),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getCostAndConsumpPlant(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadCostConsumSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadCostConsumFail(error)))
                );
        })
    );

    @Effect()
    loadUtility$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_UTILITY),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getAvailabilityUtilization(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadUtilitySuccess(plants)),
                    catchError(error => of(new PlantAction.LoadUtilityFail(error)))
                );
        })
    );

    @Effect()
    loadConsumption$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_PLANT_CONSUMPTION),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getPlantCumulative(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadPlantCunsupmtionSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantCunsupmtionFail(error)))
                );
        })
    );

    @Effect()
    loadEnergyCost$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_PLANT_ENERGYCOST),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergyCost(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadPlantEnergyCostSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantEnergyCostFail(error)))
                );
        })
    );

    @Effect()
    loadEnergyIdling$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_PLANT_ENERGYIDLING),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergyIdle(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadPlantEnergyIdlingSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantEnergyIdlingFail(error)))
                );
        })
    );

    @Effect()
    loadEnergySaving$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_PLANT_ENERGYSAVING),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergySaving(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadPlantEnergySavingSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantEnergySavingFail(error)))
                );
        })
    );

    @Effect()
    loadCo2Emission$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_PLANT_CO2EMISSSION),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getPlantCumulative(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadPlantCo2EmissionSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantCo2EmissionFail(error)))
                );
        })
    );

    @Effect()
    loadEngyConsTrend$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_PLANT_ENERGYCONSTREND),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getPlantTelemetry(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadPlantEngyConsTrendSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantEngyConsTrendFail(error)))
                );
        })
    );

    @Effect()
    loadPattern$: Observable<Action> = this.actions$.pipe(
        ofType(PlantAction.LOAD_PLANT_PATTERN),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getPlantTelemetry(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new PlantAction.LoadPlantPatternSuccess(plants)),
                    catchError(error => of(new PlantAction.LoadPlantPatternFail(error)))
                );
        })
    );
}