import { MainContainerEffects } from './mainContainer.effects';
import { DashboardEffects } from './dashboard.effects';
import { PlantEffects } from './plant.effects';
import { DepartmentEffects } from './department.effects';
import { EquipmentEffects } from './equipment.effects';
import { AlarmsEffects } from './alarams.effects';
import {UserManagementEffects} from  './UserManagement.effects';
import {DeviceEffects} from  './device.effects';

export const effects: any[] = [AlarmsEffects, MainContainerEffects, DashboardEffects, PlantEffects, DepartmentEffects, EquipmentEffects , UserManagementEffects, DeviceEffects];
export * from './mainContainer.effects';
