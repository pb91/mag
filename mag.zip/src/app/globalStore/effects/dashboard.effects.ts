import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';
import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as DashboardActions from '../actions/dashboard.actions';
import * as fromServices from '../../services';

@Injectable()
export class DashboardEffects {
    constructor(
        private actions$: Actions,
        private plantService: fromServices.PlantService  // Changed
    ) { }

    @Effect()
    loadNotifications$: Observable<Action> = this.actions$.pipe(
        ofType(DashboardActions.LOAD_DASHBOARD),
        switchMap(() => {
            return this.plantService
                .getPlantList()
                .pipe(
                    map(plants => new DashboardActions.LoadDashboardSuccess(plants)),
                    catchError(error => of(new DashboardActions.LoadDashboardFail(error)))
                );
        })
    );


    @Effect()
    loadEnergySavingGlobal$: Observable<Action> = this.actions$.pipe(
        ofType(DashboardActions.LOAD_GLOBAL_ENGSAVING),
        switchMap((payload) => {
            const from = payload['from'];
            const to = payload['to'];
            const id = payload['id'];
            const kpi = payload['kpi'];
            return this.plantService
                .getGlobalKPI(from , to, id, kpi)
                .pipe(
                    map(plants => new DashboardActions.LoadEnergySavingSuccess(plants)),
                    catchError(error => of(new DashboardActions.LoadEnergySavingFail(error)))
                );
        })
    );

    @Effect()
    loadEnergyConsumptionGlobal$: Observable<Action> = this.actions$.pipe(
        ofType(DashboardActions.LOAD_GLOBAL_ENGCONSUMPTION),
        switchMap((payload) => {
            const from = payload['from'];
            const to = payload['to'];
            const id = payload['id'];
            const kpi = payload['kpi'];
            return this.plantService
                .getGlobalKPI(from , to, id, kpi)
                .pipe(
                    map(plants => new DashboardActions.LoadEnergyConsumptionSuccess(plants)),
                    catchError(error => of(new DashboardActions.LoadEnergyConsumptionFail(error)))
                );
        })
    );



}
