import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';

import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as UsermanagementAction  from '../actions/userManagement.actions'
import * as fromServices from '../../services';

@Injectable()
export class UserManagementEffects {
    constructor(
        private actions$: Actions,
        private UsersService: fromServices.UsersService 
    ) { }

    @Effect()
    loadUsers$: Observable<Action> = this.actions$.pipe(
        ofType(UsermanagementAction.LOAD_USER),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            return this.UsersService
            .getUserList(plantId)
            .pipe(
                map(users => new UsermanagementAction.LoadUsersSuccess(users)),
                catchError(error => of(new UsermanagementAction.LoadUsersFail(error)))
            );
        })
    );

    @Effect()
    SelectedUser$: Observable<Action> = this.actions$.pipe(
        ofType(UsermanagementAction.SELECTED_USER),
        switchMap((payload) => {
            let obj : any = payload;
            return this.UsersService
            .getSelectedUser(obj.id, obj.plantId)
            .pipe(
                map(users => new UsermanagementAction.SelectedUserSuccess(users)),
                catchError(error => of(new UsermanagementAction.SelectedUserFail(error)))
            );
        })
    );

    @Effect()
    SelectedPlant$: Observable<Action> = this.actions$.pipe(
        ofType(UsermanagementAction.SELECTED_PLANT),
        switchMap((payload) => {
            
            let obj : any = payload;            
            return this.UsersService
            .GetPlantById(obj.id)
            .pipe(
                map(users => new UsermanagementAction.SelectedPlantSuccess(users)),
                catchError(error => of(new UsermanagementAction.SelectedPlantFail(error)))
            );
        })
    );
}