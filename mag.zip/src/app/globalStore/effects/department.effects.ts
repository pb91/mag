import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';
import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as DepartmentAction from '../actions/departmentsummary.actions';
import * as fromServices from '../../services';

@Injectable()
export class DepartmentEffects {
    constructor(
        private actions$: Actions,
        private plantService: fromServices.PlantService 
    ) { }

    @Effect()
    loadCost$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_COST),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergyCost(plantId, trait, tag, from, to, id, interval)
            .pipe(
                map(plants => new DepartmentAction.LoadDeptCostSuccess(plants)),
                catchError(error => of(new DepartmentAction.LoadDeptCostFail(error)))
            );
        })
    );

    @Effect()
    loadIdle$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_IDLE),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergyIdle(plantId, trait, tag, from, to, id, interval)
            .pipe(
                map(plants => new DepartmentAction.LoadDeptIdleSuccess(plants)),
                catchError(error => of(new DepartmentAction.LoadDeptIdleFail(error)))
            );
        })
    );

    @Effect()
    loadSave$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_COST),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergySaving(plantId, trait, tag, from, to, id, interval)
            .pipe(
                map(plants => new DepartmentAction.LoadDeptSaveSuccess(plants)),
                catchError(error => of(new DepartmentAction.LoadDeptSaveFail(error)))
            );
        })
    );

    @Effect()
    loadCostConsum$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_COSTCONSUM),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getCostAndConsumpDepartment(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new DepartmentAction.LoadDeptCostConsumSuccess(plants)),
                    catchError(error => of(new DepartmentAction.LoadDeptCostConsumFail(error)))
                );
        })
    );

    @Effect()
    loadEngConsum$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_ENGCONSUM),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getDepartmentCumulative(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new DepartmentAction.LoadDeptEngConsumSuccess(plants)),
                    catchError(error => of(new DepartmentAction.LoadDeptEngConsumFail(error)))
                );
        })
    );

    @Effect()
    loadEngConsumTrend$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_ENGCONSUMTREND),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getDepartmentTelemetry(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new DepartmentAction.LoadDeptEngConsumTrendSuccess(plants)),
                    catchError(error => of(new DepartmentAction.LoadDeptEngConsumTrendFail(error)))
                );
        })
    );

    @Effect()
    loadCo2$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_CO2),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getDepartmentCumulative
            (plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new DepartmentAction.LoadDeptCo2Success(plants)),
                    catchError(error => of(new DepartmentAction.LoadDeptCo2Fail(error)))
                );
        })
    );

    @Effect()
    loadUtilization$: Observable<Action> = this.actions$.pipe(
        ofType(DepartmentAction.LOAD_DEPT_AVAUTILIZATION),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getDepartmentTelemetry
            (plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new DepartmentAction.LoadDeptAvaUtilizationSuccess(plants)),
                    catchError(error => of(new DepartmentAction.LoadDeptAvaUtilizationFail(error)))
                );
        })
    );    


}