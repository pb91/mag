import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';
import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as NotificationActions from '../actions/notification.actions';
import * as PreferenceActions from '../actions/preference.actions';
import * as fromServices from '../../services';

@Injectable()
export class MainContainerEffects {
    constructor(
        private actions$: Actions,
        private MainContainerService: fromServices.MainContainerService
    ) { }

    @Effect()
    loadNotifications$: Observable<Action> = this.actions$.pipe(
        ofType(NotificationActions.LOAD_NOTIFICATIONS),
        switchMap(() => {
            return this.MainContainerService
                .getNotifications()
                .pipe(
                    map(notifications => new NotificationActions.LoadNotificationsSuccess(notifications)),
                    catchError(error => of(new NotificationActions.LoadNotificationsFail(error)))
                );
        })
    );

    @Effect()
    loadPreference$: Observable<Action> = this.actions$.pipe(
        ofType(PreferenceActions.LOAD_PREFERENCE),
        switchMap(() => {
            return this.MainContainerService
                .getPreferences()
                .pipe(
                    map(preference => new PreferenceActions.LoadPreferenceSuccess(preference)),
                    catchError(error => of(new PreferenceActions.LoadPreferenceFail(error)))
                );
        })
    );


    // // Observable without dispatch
    // @Effect({dispatch : false})
    // SuccessNotifications$ = this.actions$.pipe(
    //     ofType(NotificationActions.LOAD_NOTIFICATIONS_SUCCESS),
    //     map(() => {
    //         console.log('Hurry Success');
    //     })
    // );
}
