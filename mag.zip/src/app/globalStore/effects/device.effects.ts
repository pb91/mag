import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';
import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as DeviceAction from '../actions/device.action';
import * as fromServices from '../../services/device.service';

@Injectable()
export class DeviceEffects {
    constructor(
        private actions$: Actions,
        private deviceService: fromServices.DeviceService
    ) { }

    @Effect()
    getDeviceDetails$: Observable<Action> = this.actions$.pipe(
        ofType(DeviceAction.LOAD_DEVICE_DETAILS),
        switchMap((payload) => {
            const deviceId= payload['deviceId'];
            const plantId= payload['plantId'];
            return this.deviceService.getDeviceDeatils(deviceId, plantId).pipe(
                map(device => new DeviceAction.LoadDeviceDetailsSuccess(device)),
                catchError(error => of(new DeviceAction.LoadDeviceDetailsFail(error)))
            );
        })
    );

    @Effect()
    loadDevice$: Observable<Action> = this.actions$.pipe(
        ofType(DeviceAction.LOAD_DEVICE_LIST),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            return this.deviceService
                .getDeviceList(plantId)
                .pipe(
                    map(devices => new DeviceAction.LoadDeviceListSuccess(devices)),
                    catchError(error => of(new DeviceAction.LoadDeviceListFail(error)))
                );
        })
    );

}