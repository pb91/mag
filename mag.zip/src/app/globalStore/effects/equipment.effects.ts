import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';
import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as EquipmentAction from '../actions/equipmentsummary.actions';
import * as fromServices from '../../services';

@Injectable()
export class EquipmentEffects {
    constructor(
        private actions$: Actions,
        private plantService: fromServices.PlantService 
    ) { }

    @Effect()
    loadCost$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_COST),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergyCost(plantId, trait, tag, from, to, id, interval)
            .pipe(
                map(plants => new EquipmentAction.LoadEquipCostSuccess(plants)),
                catchError(error => of(new EquipmentAction.LoadEquipCostFail(error)))
            );
        })
    );

    @Effect()
    loadIdle$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_IDLE),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergyIdle(plantId, trait, tag, from, to, id, interval)
            .pipe(
                map(plants => new EquipmentAction.LoadEquipIdleSuccess(plants)),
                catchError(error => of(new EquipmentAction.LoadEquipIdleFail(error)))
            );
        })
    );

    @Effect()
    loadSave$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_COST),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEnergySaving(plantId, trait, tag, from, to, id, interval)
            .pipe(
                map(plants => new EquipmentAction.LoadEquipSaveSuccess(plants)),
                catchError(error => of(new EquipmentAction.LoadEquipSaveFail(error)))
            );
        })
    );

    @Effect()
    loadCostConsum$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_COSTCONSUM),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getCostAndConsumpEquipment(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipCostConsumSuccess(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipCostConsumFail(error)))
                );
        })
    );

    @Effect()
    loadEngConsum$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_ENGCONSUM),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getEnergyConsumption
            (plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipEngConsumSuccess(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipEngConsumFail(error)))
                );
        })
    );

    @Effect()
    loadEngConsumTrend$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_ENGCONSUMTREND),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getEquipmentTelemetry(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipEngConsumTrendSuccess(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipEngConsumTrendFail(error)))
                );
        })
    );

    @Effect()
    loadCo2$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_CO2),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getCarbonEmmision
            (plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipCo2Success(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipCo2Fail(error)))
                );
        })
    );

    @Effect()
    loadUtilization$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_AVAUTILIZATION),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getEquipmentTelemetry
            (plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipAvaUtilizationSuccess(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipAvaUtilizationFail(error)))
                );
        })
    );

    @Effect()
    loadDeviceStatus$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_DEVICESTATUS),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            return this.plantService.getDeviceStatus
            (plantId)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipDeviceStatusSuccess(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipDeviceStatusFail(error)))
                );
        })
    );
    
    @Effect()
    loadPowerFactor$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_POWERFACTOR),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService.getEquipmentTelemetry(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipPowerFactorSuccess(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipPowerFactorFail(error)))
                );
        })
    ); 
    
    @Effect()
    loadPeakDemand$: Observable<Action> = this.actions$.pipe(
        ofType(EquipmentAction.LOAD_EQUIP_PEAKDEMAND),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const trait = payload['trait'];
            const tag= payload['tag'];
            const from = payload['from'];
            const to= payload['to'];
            const id= payload['id'];
            const interval = payload['interval'];
            return this.plantService
            .getEquipmentTelemetry(plantId, trait, tag, from, to, id, interval)
                .pipe(
                    map(plants => new EquipmentAction.LoadEquipPeakDemandSuccess(plants)),
                    catchError(error => of(new EquipmentAction.LoadEquipPeakDemandFail(error)))
                );
        })
    );     
    
}