import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action} from '@ngrx/store';

import { of } from 'rxjs/Observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import * as AlarmsAction from '../actions/alarms.actions';
import * as fromServices from '../../services';

@Injectable()
export class AlarmsEffects {
    constructor(
        private actions$: Actions,
        private plantService: fromServices.PlantService 
    ) { }

    @Effect()
    loadAlarms$: Observable<Action> = this.actions$.pipe(
        ofType(AlarmsAction.LOAD_ALARMS),
        switchMap((payload) => {
            const plantId= payload['plantId'];
            const fromDate = payload['from'];
            const toDate= payload['to'];
            return this.plantService
            .getAlarms(plantId, fromDate, toDate)
            .pipe(
                map(plants => new AlarmsAction.LoadAlarmsSuccess(plants)),
                catchError(error => of(new AlarmsAction.LoadAlarmsFail(error)))
            );
        })
    );
}