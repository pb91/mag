import * as fromAlarams from "../actions/alarms.actions";
import { Alarms } from '../../models/alarms/alarms.model';
import * as moment from 'moment';
import * as _ from 'lodash';

export interface AlarmsState {
  data: Alarms;
  loaded: boolean;
  loading: boolean;
}

export const initialState: AlarmsState = {
  data: {
    AlarmsData: []
  },
  loaded: false,
  loading: false
};

export function reducer(
  state = initialState,
  action: fromAlarams.AlarmsAction
): AlarmsState {
  switch (action.type) {
    case fromAlarams.LOAD_ALARMS: {
      return {
        ...state,
        loading: true
      };
    }
    case fromAlarams.LOAD_ALARMS_SUCCESS: {
      let  data = action.payload;
      data = _.orderBy(data, ['created'], ['desc']);
      let tableData = [];
      data.forEach(element  => {
        if (element) {

          // var gmtDateTime = moment.utc(element['created']);
          // let local = gmtDateTime.local().valueOf();

          tableData.push({
            Icon: element['severity'],
            Device_Id : element['deviceid'],
            Device_Name : element['device_name'],
            Device_Type: element['devicetype'],
            Status: element['alaramstatus'],
            Severity: element['severity'],
            Equipment: element['equipmentid'],
            Building: element['building'],
            Departments: element['department'],
            Created: element['created']
          });
        }
      });
      return {
        ...state,
        loading: false,
        loaded: true,
        data: { AlarmsData: tableData  }
      };
    }
    case fromAlarams.LOAD_ALARMS_FAIL: {
      return {
        ...state,
        loading: false,
        loaded: false
      };
    }
  }
  return state;
}

export const getAlarmsLoading = (state: AlarmsState) => state.loading;
export const getAlarmsLoaded = (state: AlarmsState) => state.loaded;
export const getAlarms = (state: AlarmsState) => state.data;
