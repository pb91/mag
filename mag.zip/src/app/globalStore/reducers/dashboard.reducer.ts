import * as fromDashboard from "../actions/dashboard.actions";
import { Dashboard } from "../../models/dashboard/dashboard.model";
import * as _ from 'lodash';

export interface DashboardState {
  data: Dashboard;
  loaded: boolean;
  loading: boolean;
}

export const initialState: DashboardState = {
  data: {
    KPI: [
      {
        colorDark: "#5C6BC0",
        colorLight: "#7986CB",
        number: 0,
        title: "PLANTS",
        icon: "home"
      },
      {
        colorDark: "#42A5F5",
        colorLight: "#64B5F6",
        number: 0,
        title: "DEPARTMENTS",
        icon: "account_balance"
      },
      {
        colorDark: "#26A69A",
        colorLight: "#4DB6AC",
        number: 0,
        title: "BUILDINGS",
        icon: "account_balance"
      },
      {
        colorDark: "#66BB6A",
        colorLight: "#81C784",
        number: 0,
        title: "EQUIPMENTS",
        icon: "device_hub"
      }
    ]
  },
  loaded: false,
  loading: false
};

// export interface DashboardTable {
//   Site: String;
//   Contact: String;
//   Email: String;
//   Building: String;
//   Departments: String;
//   Description: String;
//   Action: String;
// }

export function reducer(
  state = initialState,
  action: fromDashboard.DashboardAction
): DashboardState {
  switch (action.type) {
    case fromDashboard.LOAD_DASHBOARD: {
      return {
        ...state,
        loading: true
      };
    }
    case fromDashboard.LOAD_DASHBOARD_SUCCESS: {
      let data = action.payload;
      const mapsData = [];

      state.data.KPI[0].number = data.length;
      state.data.KPI[1].number = 0;
      state.data.KPI[2].number = 0;
      state.data.KPI[3].number = 0;

      let tableData = [];
      
      data.forEach(element => {
      if (element) {
      state.data.KPI[1].number +=
      element.Departments instanceof Array ? element.Departments.length : 0;
      state.data.KPI[2].number +=
      element.Buildings instanceof Array ? element.Buildings.length : 0;
      state.data.KPI[3].number +=
      element.Equipments instanceof Array ? element.Equipments.length : 0;
      mapsData.push({
      latitude: element.Location && _.hasIn( element.Location, "Latitude") ?  element.Location.Latitude : '',
      longitude: element.Location && _.hasIn( element.Location, "Longitude") ?  element.Location.Longitude : '',
      user: element.PlantName,
      PlantID: element.id
      });
      tableData.push({
      PlantID: element.id,
      Name: element['PlantName'],
      Phone: element.Contacts[0]['PhoneNo'],
      Contact: element.Contacts[0]['ContactName'],
      Email: element.Contacts[0]['Email'],
      Building: _.size(element.Buildings),
      Departments: _.size(element.Departments),
      Action: 'View',
      Description: element.description,
      });
      }
      });  

      tableData = _.orderBy(tableData, ['Name'],['asc']);

      return {
        ...state,
        loading: false,
        loaded: true,
        data: {
          KPI: state.data.KPI,
          tableData: tableData,
          mappingData : mapsData
        }
      };
    }
    case fromDashboard.LOAD_DASHBOARD_FAIL: {
      return {
        ...state,
        loading: false,
        loaded: false
      };
    }
  }
  return state;
}

export const getDashboardLoading = (state: DashboardState) => state.loading;
export const getDashboardLoaded = (state: DashboardState) => state.loaded;
export const getDashboard = (state: DashboardState) => state.data;
