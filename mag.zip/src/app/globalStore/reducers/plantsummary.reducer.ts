import * as plantsummary from "../actions/plantsummary.actions";
import { Plant } from "../../models/plantSummary/plant.model";

export interface PlantSummaryState {
  costConsmData: { data: Plant, loaded: boolean, loading: boolean },
  utilityData: { data: Plant, loaded: boolean, loading: boolean },
  consumption: { data: Plant, loaded: boolean, loading: boolean },
  energyCost: { data: Plant, loaded: boolean, loading: boolean },
  energyIdling: { data: Plant, loaded: boolean, loading: boolean },
  energySaving: { data: Plant, loaded: boolean, loading: boolean },
  co2Emission: { data: Plant, loaded: boolean, loading: boolean },
  engyConsTrend: { data: Plant, loaded: boolean, loading: boolean },
  plantPattern: { data: Plant, loaded: boolean, loading: boolean }
}

export const initialState: PlantSummaryState = {
  costConsmData: { data: {}, loaded: false, loading: false },
  utilityData: { data: {}, loaded: false, loading: false },
  consumption: { data: {}, loaded: false, loading: false },
  energyCost: { data: {}, loaded: false, loading: false },
  energyIdling: { data: {}, loaded: false, loading: false },
  energySaving: { data: {}, loaded: false, loading: false },
  co2Emission: { data: {}, loaded: false, loading: false },
  engyConsTrend: { data: {}, loaded: false, loading: false },
  plantPattern: { data: {}, loaded: false, loading: false }
};

export function reducer(
  state = initialState,
  action: plantsummary.PlantAction
): PlantSummaryState {
  switch (action.type) {
    case plantsummary.LOAD_COSTCONSUM: {
      return { ...state, costConsmData: { ...state.costConsmData, loading: true } };
    }
    case plantsummary.LOAD_COSTCONSUM_SUCCESS: {
      const data = action.payload;
      return {
        ...state, costConsmData: {
          ...state.costConsmData,
          data: data, loaded: true, loading: false
        }
      };
    }

    case plantsummary.LOAD_RESET_PLANTSUMMARY: {
      return { ...state,   
        costConsmData: { ...initialState.costConsmData },
        utilityData: { ...initialState.utilityData },
        consumption: { ...initialState.consumption },
        energyCost: { ...initialState.energyCost },
        energyIdling: { ...initialState.energyIdling },
        energySaving: { ...initialState.energySaving },
        co2Emission: { ...initialState.co2Emission },
        engyConsTrend: { ...initialState.engyConsTrend },
        plantPattern: { ...initialState.plantPattern }
      }
    }

    case plantsummary.LOAD_COSTCONSUM_FAIL: {
      return { ...state, costConsmData: { ...initialState.costConsmData} };
    }
    case plantsummary.LOAD_UTILITY: {
      return { ...state, utilityData: { ...state.utilityData, loading: true } };
    }
    case plantsummary.LOAD_UTILITY_SUCCESS: {
      const data = action.payload;
      return {
        ...state, utilityData: {
          ...state.utilityData,
          data: data, loaded: true, loading: false
        }
      };
    }

    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_UTILITY_FAIL: {
      return { ...state, utilityData: { ...initialState.utilityData} };
    }


    case plantsummary.LOAD_PLANT_CONSUMPTION: {
      return { ...state, consumption: { ...state.consumption, loading: true } };
    }
    case plantsummary.LOAD_PLANT_CONSUMPTION_SUCCESS: {
      const data = action.payload;
      return {
        ...state, consumption: {
          ...state.consumption,
          data: data, loaded: true, loading: false
        }
      };
    }

    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_PLANT_CONSUMPTION_FAIL: {
      return { ...state, consumption: { ...initialState.consumption} };
    }

    case plantsummary.LOAD_PLANT_ENERGYCOST: {
      return { ...state, energyCost: { ...state.energyCost, loading: true } };
    }
    case plantsummary.LOAD_PLANT_ENERGYCOST_SUCCESS: {
      const data = action.payload;
      return {
        ...state, energyCost: {
          ...state.energyCost,
          data: data, loaded: true, loading: false
        }
      };
    }

    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_PLANT_ENERGYCOST_FAIL: {
      return { ...state, energyCost: { ...initialState.energyCost} };
    }


    case plantsummary.LOAD_PLANT_ENERGYIDLING: {
      return { ...state, energyIdling: { ...state.energyIdling, loading: true } };
    }
    case plantsummary.LOAD_PLANT_ENERGYIDLING_SUCCESS: {
      const data = action.payload;
      return {
        ...state, energyIdling: {
          ...state.energyIdling,
          data: data, loaded: true, loading: false
        }
      };
    }
    
    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_PLANT_ENERGYIDLING_FAIL: {

      return { ...state, energySaving: { ...initialState.energyIdling } };
    }

    case plantsummary.LOAD_PLANT_ENERGYSAVING: {
      return { ...state, energySaving: { ...state.energySaving, loading: true } };
    }
    case plantsummary.LOAD_PLANT_ENERGYSAVING_SUCCESS: {
      const data = action.payload;
      return {
        ...state, energySaving: {
          ...state.energySaving,
          data: data, loaded: true, loading: false
        }
      };
    }

    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_PLANT_ENERGYSAVING_FAIL: {
      return { ...state, energySaving: {  ...initialState.energySaving} };
    }

    case plantsummary.LOAD_PLANT_CO2EMISSSION: {
      return { ...state, co2Emission: { ...state.co2Emission , loading: true } };
    }
    case plantsummary.LOAD_PLANT_CO2EMISSSION_SUCCESS: {
      const data = action.payload;
      return {
        ...state, co2Emission: {
          ...state.co2Emission,
          data: data, loaded: true, loading: false
        }
      };
    }

    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_PLANT_CO2EMISSSION_FAIL: {
      return { ...state, co2Emission: {...initialState.co2Emission } };
    }

    case plantsummary.LOAD_PLANT_ENERGYCONSTREND: {
      return { ...state, engyConsTrend: { ...state.engyConsTrend, loading: true } };
    }
    case plantsummary.LOAD_PLANT_ENERGYCONSTREND_SUCCESS: {
      const data = action.payload;
      return {
        ...state, engyConsTrend: {
          ...state.engyConsTrend,
          data: data, loaded: true, loading: false
        }
      };
    }

    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_PLANT_ENERGYCONSTREND_FAIL: {
      return { ...state, engyConsTrend: { ...initialState.engyConsTrend } };
    }


    case plantsummary.LOAD_PLANT_PATTERN: {
      return { ...state, plantPattern: { ...state.plantPattern, loading: true } };
    }
    case plantsummary.LOAD_PLANT_PATTERN_SUCCESS: {
      const data = action.payload;
      return {
        ...state, plantPattern: {
          ...state.plantPattern,
          data: data, loaded: true, loading: false
        }
      };
    }

    // Code updated :: Handling failure case by clearing the data array 
    case plantsummary.LOAD_PLANT_PATTERN_FAIL: {
      return { ...state, plantPattern: { ...initialState.plantPattern} };
    }



  }
  return state;
}

export const getCostConsumLoading = (state: PlantSummaryState) => state.costConsmData.loading;
export const getCostConsumLoaded = (state: PlantSummaryState) => state.costConsmData.loaded;
export const getCostConsum = (state: PlantSummaryState) => state.costConsmData.data;