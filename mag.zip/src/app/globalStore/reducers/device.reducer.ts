import * as Device from "../actions/device.action";


export interface DeviceState {
    deviceDetails : { data: {}, loaded: boolean, loading: boolean },
    deviceList : { data: {}, loaded: boolean, loading: boolean }
  }
  
  export const initialState: DeviceState = {
    deviceDetails : { data: {}, loaded: false, loading: false },
    deviceList : { data: {}, loaded: false, loading: false }
  };
export function reducer(
  state = initialState,
  action: Device.DeviceAction
): DeviceState  {
  switch (action.type) {

    case Device.LOAD_DEVICE_LIST: {
      return {...state , deviceList : {...state.deviceList , 
        loading : true}
      };
    }
    case Device.LOAD_DEVICE_SUCCESS: {
      let  data = action.payload;
      return { ...state , deviceList : {...state.deviceList , data , loading : false, loaded: true}};
    }

    case Device.LOAD_DEVICE_FAIL: {
      return {...state , deviceList : {...state.deviceList, loading : false}};
    }

    case Device.LOAD_RESET_DEVICE: {
      return { ...state,   
        deviceDetails: { ...initialState.deviceDetails },
        deviceList: { ...initialState.deviceList },
      }
    }

    case Device.LOAD_RESET_DEVICE_DETAILS: {
      return { ...state,   
        deviceDetails: { ...initialState.deviceDetails }
      }
    }

    case Device.LOAD_DEVICE_DETAILS: {
      return { ...state, deviceDetails: { ...state.deviceDetails, loading: true, loaded: false } };
    }
    case Device.LOAD_DEVICE_DETAILS_SUCCESS: {
      const data = action.payload;
      return {
        ...state, deviceDetails: {
          ...state.deviceDetails,
          data: data, loading: false, loaded: true
        }
      };
    }
    case Device.LOAD_DEVICE_DETAILS_FAIL: {
      return { ...state, deviceDetails: { ...state.deviceDetails, loading: false, loaded: true } };
    }
    
  }
  return state;
}

// export const getPlantLoading = (state: DeviceState) => state.loading;
// export const getPlantLoaded = (state: DeviceState) => state.loaded;
// export const getPlant = (state: DeviceState) => state.data;