import * as fromDashboard from "../actions/dashboard.actions";
import { Dashboard } from "../../models/dashboard/dashboard.model";

export interface GlobalDashboardState {
    globalEnergyConsumption: { data: any, loaded: boolean, loading: boolean },
    globalEnergySaving: { data: any, loaded: boolean, loading: boolean }
}

export const initialState: GlobalDashboardState = {
    globalEnergyConsumption: { data: {}, loaded: false, loading: false },
    globalEnergySaving: { data: {}, loaded: false, loading: false }
};

// export interface DashboardTable {
//   Site: String;
//   Contact: String;
//   Email: String;
//   Building: String;
//   Departments: String;
//   Description: String;
//   Action: String;
// }

export function reducer(
  state = initialState,
  action: fromDashboard.DashboardAction
): GlobalDashboardState {
  switch (action.type) {
    case fromDashboard.LOAD_GLOBAL_ENGCONSUMPTION: {
        return { ...state, globalEnergyConsumption: { ...state.globalEnergyConsumption, loading: true } };
      }
      case fromDashboard.LOAD_GLOBAL_ENGCONSUMPTION_SUCCESS: {
        const data = action.payload;
        return {
          ...state, globalEnergyConsumption: {
            ...state.globalEnergyConsumption,
            data: data, loaded: true, loading: false
          }
        };
      }
  
      // Code updated :: Handling failure case by clearing the data array 
      case fromDashboard.LOAD_GLOBAL_ENGCONSUMPTION_FAIL: {

        return { ...state, globalEnergyConsumption: { ...initialState.globalEnergySaving } };
      }


    case fromDashboard.LOAD_GLOBAL_ENGSAVING: {
        return { ...state, globalEnergySaving: { ...state.globalEnergySaving, loading: true } };
      }
      case fromDashboard.LOAD_GLOBAL_ENGSAVING_SUCCESS: {
        const data = action.payload;
        return {
          ...state, globalEnergySaving: {
            ...state.globalEnergySaving,
            data: data, loaded: true, loading: false
          }
        };
      }
  
      // Code updated :: Handling failure case by clearing the data array 
      case fromDashboard.LOAD_GLOBAL_ENGSAVING_FAIL: {
  
        return { ...state, globalEnergySaving: { ...initialState.globalEnergySaving } };
      }


  }
  return state;
}


