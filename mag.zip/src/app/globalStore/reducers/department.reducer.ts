import * as departmentsummary from "../actions/departmentsummary.actions";

export interface DepartmentSummaryState {
    idleData: { data: {}, loaded: boolean, loading: boolean },
    saveData: { data: {}, loaded: boolean, loading: boolean },
    costData: { data: {}, loaded: boolean, loading: boolean },
    costConsumData: { data: {}, loaded: boolean, loading: boolean },
    consumData: { data: {}, loaded: boolean, loading: boolean },
    consumTrendData : { data: {}, loaded: boolean, loading: boolean },
    co2Data : { data: {}, loaded: boolean, loading: boolean },
    avaUtilizationData : { data: {}, loaded: boolean, loading: boolean }
}

export const initialState: DepartmentSummaryState = {
    idleData: { data: {}, loaded: false, loading: false },
    saveData: { data: {}, loaded: false, loading: false },
    costData: { data: {}, loaded: false, loading: false },
    costConsumData : { data: {}, loaded: false, loading: false },
    consumData : { data: {}, loaded: false, loading: false },
    consumTrendData : { data: {}, loaded: false, loading: false },
    co2Data : { data: {}, loaded: false, loading: false },
    avaUtilizationData: { data: {}, loaded: false, loading: false }
}

export function reducer(
  state = initialState,
  action: departmentsummary.DepartmentAction
): DepartmentSummaryState {
  switch (action.type) {

    case departmentsummary.LOAD_DEPT_COST: {
        return {...state, costData: { ...state.costData, loading: true }};
    }

    case departmentsummary.LOAD_RESET_DEPARTSUMMARY: {
        return { ...state,   
            idleData: { ...initialState.idleData },
            saveData: { ...initialState.saveData },
            costData: { ...initialState.costData },
            costConsumData: { ...initialState.costConsumData },
            consumData: { ...initialState.consumData },
            consumTrendData: { ...initialState.consumTrendData },
            co2Data: { ...initialState.co2Data },
            avaUtilizationData: { ...initialState.avaUtilizationData }
        }
      }

    case departmentsummary.LOAD_DEPT_COST_SUCCESS: {
        const data = action.payload;
        return {...state, costData: { ...state.costData, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_COST_FAIL: {
        return {...state, costData: { ...initialState.costData }};
    }

    case departmentsummary.LOAD_DEPT_IDLE: {
        return {...state, idleData: { ...state.idleData, loading: true }};
    }
    case departmentsummary.LOAD_DEPT_IDLE_SUCCESS: {
        const data = action.payload;
        return {...state, idleData: { ...state.idleData, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_IDLE_FAIL: {
        return {...state, idleData: { ...initialState.idleData }};
    }

    case departmentsummary.LOAD_DEPT_SAVE: {
        return {...state, saveData: { ...state.saveData, loading: true }};
    }
    case departmentsummary.LOAD_DEPT_SAVE_SUCCESS: {
        const data = action.payload;
        return {...state, saveData: { ...state.saveData, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_SAVE_FAIL: {
        return {...state, saveData: { ...initialState.saveData}};
    }
    case departmentsummary.LOAD_DEPT_COSTCONSUM: {
        return {...state, costConsumData: { ...state.costConsumData, loading: true }};
    }
    case departmentsummary.LOAD_DEPT_COSTCONSUM_SUCCESS: {
        const data = action.payload;
        return {...state, costConsumData: { ...state.costConsumData, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_COSTCONSUM_FAIL: {
        return {...state, costConsumData: { ...initialState.costConsumData}};
    }
    case departmentsummary.LOAD_DEPT_ENGCONSUM: {
        return {...state, consumData: { ...state.consumData, loading: true }};
    }
    case departmentsummary.LOAD_DEPT_ENGCONSUM_SUCCESS: {
        const data = action.payload;
        return {...state, consumData: { ...state.consumData, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_ENGCONSUM_FAIL: {
        return {...state, consumData: { ...initialState.consumData }};
    }
    case departmentsummary.LOAD_DEPT_ENGCONSUMTREND: {
        return {...state, consumTrendData: { ...state.consumTrendData, loading: true }};
    }
    case departmentsummary.LOAD_DEPT_ENGCONSUMTREND_SUCCESS: {
        const data = action.payload;
        return {...state, consumTrendData: { ...state.consumTrendData, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_ENGCONSUMTREND_FAIL: {
        return {...state, consumTrendData: { ...initialState.consumTrendData }};
    }
    case departmentsummary.LOAD_DEPT_CO2: {
        return {...state, co2Data: { ...state.co2Data, loading: true }};
    }
    case departmentsummary.LOAD_DEPT_CO2_SUCCESS: {
        const data = action.payload;
        return {...state, co2Data: { ...state.co2Data, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_CO2_FAIL: {
        return {...state, co2Data: { ...initialState.co2Data }};
    }
    case departmentsummary.LOAD_DEPT_AVAUTILIZATION: {
        return {...state, avaUtilizationData: { ...state.avaUtilizationData, loading: true }};
    }
    case departmentsummary.LOAD_DEPT_AVAUTILIZATION_SUCCESS: {
        const data = action.payload;
        return {...state, avaUtilizationData: { ...state.avaUtilizationData, 
          data: data, loaded: true, loading: false }};
    }
    case departmentsummary.LOAD_DEPT_AVAUTILIZATION_FAIL: {
        return {...state, avaUtilizationData: { ...initialState.avaUtilizationData}};
    }
  }
  return state;
}
