import * as equipmentsummary from "../actions/equipmentsummary.actions";

export interface  EquipmentSummaryState {
    idleData: { data: {}, loaded: boolean, loading: boolean },
    saveData: { data: {}, loaded: boolean, loading: boolean },
    costData: { data: {}, loaded: boolean, loading: boolean },
    costConsumData: { data: {}, loaded: boolean, loading: boolean },
    consumData: { data: {}, loaded: boolean, loading: boolean },
    consumTrendData : { data: {}, loaded: boolean, loading: boolean },
    co2Data : { data: {}, loaded: boolean, loading: boolean },
    avaUtilizationData: { data: {}, loaded: boolean, loading: boolean },
    deviceStatus: { data: {}, loaded: boolean, loading: boolean },
    powerFactor: { data: {}, loaded: boolean, loading: boolean },
    peakDemand: { data: {}, loaded: boolean, loading: boolean }
}

export const initialState: EquipmentSummaryState = {
    idleData: { data: {}, loaded: false, loading: false },
    saveData: { data: {}, loaded: false, loading: false },
    costData: { data: {}, loaded: false, loading: false },
    costConsumData : { data: {}, loaded: false, loading: false },
    consumData : { data: {}, loaded: false, loading: false },
    consumTrendData : { data: {}, loaded: false, loading: false },
    co2Data : { data: {}, loaded: false, loading: false },
    avaUtilizationData: { data: {}, loaded: false, loading: false },
    deviceStatus: { data: {}, loaded: false, loading: false },
    powerFactor: { data: {}, loaded: false, loading: false },
    peakDemand: { data: {}, loaded: false, loading: false }
}

export function reducer(
  state = initialState,
  action: equipmentsummary.EquipmentAction
): EquipmentSummaryState {
  switch (action.type) {

    case equipmentsummary.LOAD_RESET_EQUIPSUMMARY: {
        return { ...state,   
            idleData: { ...initialState.idleData },
            saveData: { ...initialState.saveData },
            costData: { ...initialState.costData },
            costConsumData: { ...initialState.costConsumData },
            consumData: { ...initialState.consumData },
            consumTrendData: { ...initialState.consumTrendData },
            co2Data: { ...initialState.co2Data },
            avaUtilizationData: { ...initialState.avaUtilizationData },
            deviceStatus: { ...initialState.deviceStatus },
            powerFactor: { ...initialState.powerFactor },
            peakDemand:  { ...initialState.peakDemand }
        }
      }
    case equipmentsummary.LOAD_EQUIP_COST: {
        return {...state, costData: { ...state.costData, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_COST_SUCCESS: {
        const data = action.payload;
        return {...state, costData: { ...state.costData, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_COST_FAIL: {
        return {...state, costData: { ...initialState.costData}};
    }
    case equipmentsummary.LOAD_EQUIP_IDLE: {
        return {...state, idleData: { ...state.idleData, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_IDLE_SUCCESS: {
        const data = action.payload;
        return {...state, idleData: { ...state.idleData, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_IDLE_FAIL: {
        return {...state, idleData: { ...initialState.idleData}};
    }

    case equipmentsummary.LOAD_EQUIP_SAVE: {
        return {...state, saveData: { ...state.saveData, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_SAVE_SUCCESS: {
        const data = action.payload;
        return {...state, saveData: { ...state.saveData, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_SAVE_FAIL: {
        return {...state, saveData: { ...initialState.saveData}};
    }
    case equipmentsummary.LOAD_EQUIP_COSTCONSUM: {
        return {...state, costConsumData: { ...state.costConsumData, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_COSTCONSUM_SUCCESS: {
        const data = action.payload;
        return {...state, costConsumData: { ...state.costConsumData, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_COSTCONSUM_FAIL: {
        return {...state, costConsumData: { ...initialState.costConsumData }};
    }
    case equipmentsummary.LOAD_EQUIP_ENGCONSUM: {
        return {...state, consumData: { ...state.consumData, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_ENGCONSUM_SUCCESS: {
        const data = action.payload;
        return {...state, consumData: { ...state.consumData, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_ENGCONSUM_FAIL: {
        return {...state, consumData: { ...initialState.consumData}};
    }
    case equipmentsummary.LOAD_EQUIP_ENGCONSUMTREND: {
        return {...state, consumTrendData: { ...state.consumTrendData, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_ENGCONSUMTREND_SUCCESS: {
        const data = action.payload;
        return {...state, consumTrendData: { ...state.consumTrendData, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_ENGCONSUMTREND_FAIL: {
        return {...state, consumTrendData: { ...initialState.consumTrendData}};
    }
    case equipmentsummary.LOAD_EQUIP_CO2: {
        return {...state, co2Data: { ...state.co2Data, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_CO2_SUCCESS: {
        const data = action.payload;
        return {...state, co2Data: { ...state.co2Data, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_CO2_FAIL: {
        return {...state, co2Data: { ...initialState.co2Data}};
    }
    case equipmentsummary.LOAD_EQUIP_AVAUTILIZATION: {
        return {...state, avaUtilizationData: { ...state.avaUtilizationData, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_AVAUTILIZATION_SUCCESS: {
        const data = action.payload;
        return {...state, avaUtilizationData: { ...state.avaUtilizationData, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_AVAUTILIZATION_FAIL: {
        return {...state, avaUtilizationData: { ...initialState.avaUtilizationData }};
    }
    case equipmentsummary.LOAD_EQUIP_DEVICESTATUS: {
        return {...state, deviceStatus: { ...state.deviceStatus, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_DEVICESTATUS_SUCCESS: {
        const data = action.payload;
        return {...state, deviceStatus: { ...state.deviceStatus, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_DEVICESTATUS_FAIL: {
        return {...state, deviceStatus: { ...initialState.deviceStatus}};
    }    
    case equipmentsummary.LOAD_EQUIP_POWERFACTOR: {
        return {...state, powerFactor: { ...state.powerFactor, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_POWERFACTOR_SUCCESS: {
        const data = action.payload;
        return {...state, powerFactor: { ...state.powerFactor, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_POWERFACTOR_FAIL: {
        return {...state, powerFactor: { ...initialState.powerFactor}};
    }   
    case equipmentsummary.LOAD_EQUIP_PEAKDEMAND: {
        return {...state, peakDemand: { ...state.peakDemand, loading: true }};
    }
    case equipmentsummary.LOAD_EQUIP_PEAKDEMAND_SUCCESS: {
        const data = action.payload;
        return {...state, peakDemand: { ...state.peakDemand, 
          data: data, loaded: true, loading: false }};
    }
    case equipmentsummary.LOAD_EQUIP_PEAKDEMAND_FAIL: {
        return {...state, peakDemand: { ...initialState.peakDemand}};
    }   
  }
  return state;
}