import * as fromNotifications from '../actions/notification.actions';
import { Notifications } from '../../models/headerBar/notifications.model';

export interface NotificationsState {
    data: Notifications;
    loaded: boolean;
    loading: boolean;
}

export const initialState: NotificationsState = {
    data: {},
    loaded: false,
    loading: false
};


export function reducer(
    state = initialState,
    action: fromNotifications.NotificationsAction
): NotificationsState {
    switch (action.type) {
        case fromNotifications.LOAD_NOTIFICATIONS: {
            return {
                ...state,
                loading: true
            };
        }
        case fromNotifications.LOAD_NOTIFICATIONS_SUCCESS: {
            const data = action.payload;
            return {
                ...state,
                loading: false,
                loaded: true,
                data
            };
        }
        case fromNotifications.LOAD_NOTIFICATIONS_FAIL: {
            return {
                ...state,
                loading: false,
                loaded: false
            };
        }
    }
    return state;
}

export const getNotificationsLoading = (state: NotificationsState) => state.loading;
export const getNotificationsLoaded = (state: NotificationsState) => state.loaded;
export const getNotifications = (state: NotificationsState) => state.data;
