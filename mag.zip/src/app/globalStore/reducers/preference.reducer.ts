import * as fromPreference from "../actions/preference.actions";
import { CombinedNavigation } from "../../models/navigationBar/combined.model";
import { UtilityService } from '../../shared/utility.service';
import { Roles  } from '../../shared/roles';
import { AuthenticationService } from '@appServices/authentication.service';
import * as _ from 'lodash';

export interface PreferenceState {
  data: CombinedNavigation;
  loaded: boolean;
  loading: boolean;
}

export const initialState: PreferenceState = {
  data: {
    navigation: [
      
      {
        "type": "content",
        "title": "Dashboard",
        "icon": "move_to_inbox",
        "link": "/dashboard"
      }
    ]
  },
  loaded: false,
  loading: false
};

function validateURL(page:string[]) {
  let checkRoles  = localStorage.getItem('userRoles');
  var rolesArray = checkRoles.split(',');
  let presentArray = _.intersection(rolesArray, page);
  return _.size(presentArray) > 0 ? true : false;
}

// This function is to check contains plant admin & does not contains global admin
function validateURLPlantAdmin(page:string[]) {
  let checkRoles  = localStorage.getItem('userRoles');
  var rolesArray = checkRoles.split(',');
  if(rolesArray.indexOf('AdopterAdmin') !== -1 ||  rolesArray.indexOf('GlobalAdmin') !== -1){
    console.log("Contains  AdopterAdmin && GlobalAdmin");
    return false;
  } else {
    if(rolesArray.indexOf('PlantAdmin') !== -1){
      console.log("Contains only PlantAdmin");
      return true;
    } else {
      console.log("Does not contain GlobalAdmin, AdopterAdmin & PlantAdmin");
      return false;
    }
  }
}

function configureRoutingInitial() {

  let rolesArray = [{
      "type": "title",
      "title": "Summary"
  },
  {
      "type": "content",
      "title": "Dashboard",
      "icon": "move_to_inbox",
      "link": "/dashboard"
  }];

  validateURL(Roles.SiteList.view) && rolesArray.push({"type": "content", "title": "Sites", "icon": "ac_unit", "link": `/usersManagement/plant`});

  validateURL(Roles.UsersList.view) && rolesArray.push({"type": "content",
    "title": "Users", "icon": "group", "link": `/usersManagement/user/`});

    validateURL(Roles.Category.view) && rolesArray.push({"type": "content",
    "title": "Category", "icon": "info", "link": `/category/7b5a783d-61d7-46b4-ae07-2371ff1a45c3`});  
  return rolesArray;

}

function configureRouting(plantId:string) {
  
  var finalArray = [{"type": "content",
  "title": "Dashboard", "icon": "move_to_inbox", "link": "/dashboard"}];
  
  validateURL(Roles.Plant.view) && finalArray.push(
    {"type": "content",
      "title": "Site", "icon": "send", "link": `/plantsummary/${plantId}`});
      
  validateURL(Roles.Department.view) && finalArray.push(
    {"type": "content",
      "title": "Department", "icon": "folder", "link": `/department/${plantId}`});

  validateURL(Roles.Equipment.view) && finalArray.push(
    {"type": "content",
      "title": "Equipment", "icon": "info", "link": `/equipment/${plantId}`});

   finalArray.push({
      "type": "content",
      "title": "Site Hierarchy",
      "icon": "device_hub",
      "link": `/planthierarachy/${plantId}`
    },
    {
      "type": "content",
      "title": "Alarms",
      "icon": "notifications",
      "link": `/alarms/${plantId}`
    });


  validateURL(Roles.Category.view) && finalArray.push({"type": "content",
  "title": "Category", "icon": "info", "link": `/category/${plantId}`});

  validateURL(Roles.SiteList.view) && finalArray.push({"type": "content", "title": "Sites", "icon": "ac_unit", "link": `/usersManagement/plant`});

  validateURLPlantAdmin(Roles.SiteUsersList.view) && finalArray.push(
  {"type": "content", "title": "Users", "icon": "group", "link": `/usersManagement/user/${plantId}`});

  validateURL(Roles.UsersList.view) && finalArray.push({"type": "content",
  "title": "Users", "icon": "group", "link": `/usersManagement/user/`});


  validateURL(Roles.FloorPlan.view) && finalArray.push({ "type": "title", "title": "Floor Plan", "icon": "", "link": "" },
   

  {"type": "content", "title": "View Floor", "icon": "pageview", "link": `/viewFloorplanOrg/${plantId}`}

);

validateURL(Roles.FloorPlan.Edit) && finalArray.push(
{"type": "content", "title": "Edit Floor", "icon": "add_location", "link": `/editFloorPlan/${plantId}`},

);


  // validateURL(Roles.CreateUser.view) && finalArray.push( {"type": "content", "title": "Upload Floor", "icon": "file_upload", "link": `/uploadFloorplan/${plantId}`},
  // {"type": "content", "title": "Edit Floor", "icon": "add_location", "link": `/editFloorPlan/${plantId}`});

  return finalArray;
}

export function reducer(
  state = initialState,
  action: fromPreference.PreferenceAction
): PreferenceState {
  switch (action.type) {
    case fromPreference.LOAD_PREFERENCE: {
      return {
        ...state,
        loading: true
      };
    }

    case fromPreference.UPDATE_PREFERENCE: {
      const plantId = action.plantId;
      return {
        ...state,
        loading: true,
        data: {
          navigation: configureRouting(plantId)
        }
      };
    }
    case fromPreference.RESET_PREFERENCE: {
      return {
        ...state,
        loading: true,
        data: {
          navigation: configureRoutingInitial()
        }
      };
    }
    
    case fromPreference.LOAD_PREFERENCE_SUCCESS: {
      const data = action.payload;
      return {
        ...state,
        loading: false,
        loaded: true,
        data
      };
    }
    case fromPreference.LOAD_PREFERENCE_FAIL: {
      return {
        ...state,
        loading: false,
        loaded: false
      };
    }
  }
  return state;
}

export const getPreferenceLoading = (state: PreferenceState) => state.loading;
export const getPreferenceLoaded = (state: PreferenceState) => state.loaded;
export const getPreference = (state: PreferenceState) => state.data;
