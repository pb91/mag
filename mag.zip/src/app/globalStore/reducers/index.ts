import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import * as fromPreference from './preference.reducer';
import * as fromNotifications from './notifications.reducer';
import * as fromDashboard from './dashboard.reducer';
import * as plant from './plant.reducer';
import * as plantsummary from './plantsummary.reducer';
import * as department from './department.reducer';
import * as equipment from './equipment.reducer';      
import * as alarms from './alarms.reducer'; 
import * as globalDashboard from './dashboard.global.reducer';
import * as UserManagement from './userManagement.reducer';
import * as device from './device.reducer';


export interface ContainerState {
    notifications: fromNotifications.NotificationsState;
    preference: fromPreference.PreferenceState;
    dashboard: fromDashboard.DashboardState;
    plant: plant.PlantState;
    plantsummary: plantsummary.PlantSummaryState;
    departmentsummary: department.DepartmentSummaryState;
    equipmentsummary: equipment.EquipmentSummaryState;
    alarms: alarms.AlarmsState;
    globalDashboard : globalDashboard.GlobalDashboardState;
    UserManagement : UserManagement.UserManagementState;
    device: device.DeviceState

}

export const reducers: ActionReducerMap<ContainerState> = {
    notifications: fromNotifications.reducer,
    preference : fromPreference.reducer,
    dashboard: fromDashboard.reducer,
    plant: plant.reducer,
    plantsummary: plantsummary.reducer,
    departmentsummary: department.reducer,
    equipmentsummary: equipment.reducer,
    alarms: alarms.reducer,
    globalDashboard : globalDashboard.reducer,
    UserManagement : UserManagement.reducer,
    device : device.reducer
};

export const getMainContainerState = createFeatureSelector<ContainerState>(
    'maincontainer'
);