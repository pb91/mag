import * as fromUserManagement from "../actions/userManagement.actions";
import * as moment from 'moment';
import * as _ from 'lodash';

export interface UserManagementState {
    User: { data: any, loaded: boolean, loading: boolean },
    SelectedUser : { data: any, loaded: boolean, loading: boolean },
    SelectedPlant : { data: any, loaded: boolean, loading: boolean },
}

export const initialState: UserManagementState = {
 User: { data: [], loaded: false, loading: false },
 SelectedUser : { data: [] , loaded: false, loading: false  },
 SelectedPlant : { data: [] , loaded: false, loading: false  },
};

export function reducer(
  state = initialState,
  action: fromUserManagement.UsermanagementAction
): UserManagementState {
  switch (action.type) {
    case fromUserManagement.LOAD_USER: {
      return {...state , User : {...state.User , 
        loading : true}
      };
    }
    case fromUserManagement.LOAD_USER_SUCCESS: {
        
      let  data = action.payload;
      return { ...state , User : {...state.User , data , loading : false}};
    }
    case fromUserManagement.LOAD_USER_FAIL: {
      return {...state , User : {...state.User, loading : false}};
    }

    case fromUserManagement.SELECTED_USER: {
      return {...state , SelectedUser : {...initialState.SelectedUser, loading : true}};
    }

    case fromUserManagement.CLEAR_USER: {
      return {...state, User: { ...state.User, data: [] }};
    }

    case fromUserManagement.SELECTED_USER_SUCCESS: {
        let  data = action.payload;
        return {...state , SelectedUser : {...state.SelectedUser , data, loading : false}};
      }

      case fromUserManagement.SELECTED_USER_FAIL: {
        return {...state , SelectedUser : {...state.SelectedUser, loading : false  }};
      }

      case fromUserManagement.SELECTED_PLANT: {
        return {...state , SelectedPlant : {...initialState.SelectedPlant, loading : true}};
      }
  
      case fromUserManagement.SELECTED_PLANT_SUCCESS: {
          let  data = action.payload;
          return {...state , SelectedPlant : {...state.SelectedPlant , data, loading : false}};
        }
  
        case fromUserManagement.SELECTED_PLANT_FAIL: {

          return {...state , SelectedPlant : {...state.SelectedPlant, loading : false }};
        }

  }
  return state;
}


