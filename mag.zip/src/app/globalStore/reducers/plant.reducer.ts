import * as plantsummary from "../actions/plantsummary.actions";
import { Plant } from "../../models/plantSummary/plant.model";

export interface PlantState {
  data: Plant;
  loaded: boolean;
  loading: boolean;
}

export const initialState: PlantState = {
  data: {},
  loaded: false,
  loading: false,
};

export function reducer(
  state = initialState,
  action: plantsummary.PlantAction
): PlantState {
  switch (action.type) {

    case plantsummary.LOAD_RESET_PLANT: {
      return {...state, 
        data: {},
        loaded: false,
        loading: false,
        };
    }

    case plantsummary.LOAD_GET_PLANT: {
      return {...state, loading: true };
    }
    case plantsummary.LOAD_PLANTSUMMARY_SUCCESS: {
      const data = action.payload;
      return { ...state, loading: false, loaded: true, data: data};
    }
    case plantsummary.LOAD_PLANTSUMMARY_FAIL: {
      return { ...state, loading: false, loaded: false };
    }
    
  }
  return state;
}

export const getPlantLoading = (state: PlantState) => state.loading;
export const getPlantLoaded = (state: PlantState) => state.loaded;
export const getPlant = (state: PlantState) => state.data;