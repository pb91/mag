import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Roles } from './shared/roles';

import { DashboardComponent } from '@appContainers/dashboard/dashboard.component';
import { LoginComponent } from '@appContainers/login/login.component';
import { AuthGuard } from '@appGuards/auth.guard';
import { PlantsummaryComponent } from '@appContainers/plantsummary/plantsummary.component';
import { DepartmentComponent } from '@appContainers/department/department.component';
import { EquipmentComponent } from '@appContainers/equipment/equipment.component';
import {EquipmentViewComponent} from '@appContainers/equipment/equipmentView/equipmentView.component'
import {EquipmentMainComponent} from '@appContainers/equipment/equipmentMain/equipmentMain.component';
import {DeviceListComponent } from '@appContainers/equipment/equipmentDevice/equipmentDevice.component';
import { PlanthierarchyComponent } from '@appContainers/planthierarchy/planthierarchy.component';
import { AlarmsComponent } from '@appContainers/alarms/alarms.component';
import { UnauthorizedComponent } from '@appContainers/unauthorized/unauthorized.component';
import {PlantComponent} from '@appContainers/usersManagement/plant/plant.component'
import { EditComponent } from '@appContainers/usersManagement/plant/edit/edit.component';
import {UserEditComponent} from '@appContainers/usersManagement/user/user-edit/user-edit.component';
import {UserComponent} from '@appContainers/usersManagement/user/user.component';
import {FloorPlanViewComponent} from '@appContainers/floorplan/floor-plan-view/floor-plan-view.component';
import {FloorPlanViewOrgComponent} from '@appContainers/floorplan/floor-plan-view-org/floor-plan-view-org.component';
import {FloorPlanEditComponent} from '@appContainers/floorplan/floor-plan-edit/floor-plan-edit.component';
import { DeviceEditComponent } from '@appContainers/planthierarchy/device-edit/device-edit.component';
import { DeviceUpdateComponent } from '@appContainers/planthierarchy/device-update/device-update.component';
import { ForgotComponent } from '@appContainers/forgot/forgot.component';
import { ChangepasswordComponent } from '@appContainers/changepassword/changepassword.component';
import { VerifyaccountComponent } from '@appContainers/verifyaccount/verifyaccount.component';
// import { CategoryComponent } from '@appContainers/category/category.component';
// import { CategoryEditComponent } from '@appContainers/category/category-edit/category-edit.component';


const routes: Routes = [
  { path: '', redirectTo: 'sign-in', pathMatch: 'full' },
  {
    path: 'sign-in',
    component: LoginComponent,
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    data: { title: 'Organization Sites'},
    canActivate: [AuthGuard],
  },
  {
    path: 'plantsummary/:id',
    component: PlantsummaryComponent,
    data:{ title: 'Site Summary', roles: Roles.Plant.view},
    canActivate: [AuthGuard]
  },
  {
    path: 'department/:id',
    component: DepartmentComponent,
    data:{ title: 'Department Summary', roles: Roles.Department.view},
    canActivate: [AuthGuard]
  },
  {
    path: 'equipment/:id',
    component: EquipmentMainComponent ,
    data:{ title: 'Equipment List', roles: Roles.Equipment.view},
    canActivate: [AuthGuard]
  },
  
  {
    path: 'equipmentdevicelist/:deviceId/:plantId/:deviceName',
    component: DeviceListComponent ,
    data:{ title: 'Equipment Summary', roles: Roles.Equipment.view},
    canActivate: [AuthGuard]
  },
  {
    path: 'equipmentsummary/:deviceId/:plantId/:deviceName',
    component: EquipmentComponent ,
    data:{ title: 'Equipment Summary', roles: Roles.Equipment.view},
    canActivate: [AuthGuard]
  },
  {
    path : 'equipmentview/:operation/:deviceId/:plantId/:deviceName',
    component: EquipmentViewComponent,
    data:{ title: 'Equipment Details', roles: Roles.Equipment.view},
    canActivate: [AuthGuard]
  },
  {
    path: 'planthierarachy/:id',
    component: PlanthierarchyComponent ,
    data:{ title: 'Site Hierarchy'},
    canActivate: [AuthGuard]
  },
  {
    path: 'alarms/:id',
    component: AlarmsComponent ,
    data:{ title: 'Alarms'},
    canActivate: [AuthGuard]
  },
  // {
  //   path: 'category/:id',
  //   component: CategoryComponent ,
  //   data:{ title: 'Category List', roles: Roles.Category.view},
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path : 'category/:operation/:plantId/:categoryId',
  //   component: CategoryEditComponent,
  //   data:{ title: 'Create Category', roles: Roles.Category.create},
  //   canActivate: [AuthGuard]
  // },
  {
    path : 'usersManagement/user/:plantId',
    component: UserComponent ,
    data:{ title: 'Users List' , roles: Roles.SiteUsersList.view},
    canActivate: [AuthGuard]
  },
  {
    path: 'unauthorized',
    component: UnauthorizedComponent ,
    data:{ title: 'Unauthorized Access'},
    canActivate: [AuthGuard]
  },
  {
    path : 'usersManagement/plant',
    component: PlantComponent ,
    data:{ title: 'Sites List' , roles: Roles.SiteList.view},
    canActivate: [AuthGuard]
  },
  {
    path : 'usersManagement/plant/:page/:plantId',
    component: EditComponent,
    data:{ title: 'Site Details', roles: Roles.SiteList.view},
    canActivate: [AuthGuard]
  }
  ,{
    path : 'usersManagement/user',
    component: UserComponent ,
    data:{ title: 'Users List', roles: Roles.UsersList.view},
    canActivate: [AuthGuard]
  },{
    path : 'usersManagement/user/operation/:type/:id/:plantId',
    component : UserEditComponent,
    data:{ title: 'Edit User', roles: Roles.CreateUser.view},
    canActivate: [AuthGuard]
  },
  {
    path : 'viewFloorplan/:id',
    component : FloorPlanViewComponent ,
    data:{ title: 'View Floor Plan'},
    canActivate: [AuthGuard]
  },
  {
    path : 'editFloorPlan/:id',
    component : FloorPlanEditComponent,
    data : {title : "Edit Floor Plan"},
    canActivate : [AuthGuard]
  },{
    path : 'viewFloorplanOrg/:id',
    component : FloorPlanViewOrgComponent ,
    data:{ title: 'View Floor Plan'},
    canActivate: [AuthGuard]
  },
  {
    path : 'planthierarachy/:operation/:plantId',
    component: DeviceEditComponent,
    data:{ title: 'Device Details', roles: Roles.DeviceList.addupdate},
    canActivate: [AuthGuard]
  },
  {
    path : 'planthierarachy/:operation/:deviceId/:plantId',
    component: DeviceEditComponent,
    data:{ title: 'Device Details', roles: Roles.DeviceList.view},
    canActivate: [AuthGuard]
  },  
  {
    path : 'deviceupdate/:deviceId/:plantId',
    component: DeviceUpdateComponent,
    data:{ title: 'Device Details', roles: Roles.DeviceList.addupdate},
    canActivate: [AuthGuard]
  },
  {
    path : 'changepassword',
    component: ChangepasswordComponent,
    data:{ title: 'Change Password'}
  },
  {
    path: 'verifyaccount/activate/:userId',
    component: VerifyaccountComponent ,
    data:{ title: 'Verify Account'}
  },
  {
    path : 'forgot',
    component: ForgotComponent,
    data:{ title: 'Reset Password', flag: "reset"},
  },
  {
    path : 'register',
    component: ForgotComponent,
    data:{ title: 'Register an Account', flag: "register"},
  },
  {
    path : 'register/verifyaccount/:emailId',
    component: ForgotComponent,
    data:{ title: 'Register an Account', flag: "verifyaccount"},
  },
  { path: '**', redirectTo: 'sign-in' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule] 
})
export class AppRoutingModule {}