import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-unauthorized',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.scss']
})
export class UnauthorizedComponent implements OnInit {
  public pageTitle : string;

  constructor(private route : ActivatedRoute) {
    this.pageTitle = this.route.snapshot.data.title
  }
  
  ngOnInit() {
  }

}
