import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup, Validators, AbstractControl} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '@appServices/authentication.service';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-verifyaccount',
  templateUrl: './verifyaccount.component.html',
  styleUrls: ['./verifyaccount.component.scss']
})
export class VerifyaccountComponent implements OnInit {
  public pageTitle: string;
  formGroup:FormGroup;
  userId: string;
  loadingFlag: boolean = false;
  titleAlert: string = 'This field is mandatory';
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public notificationMsg: ToastComponent,
    private authenticationService: AuthenticationService) {
    this.pageTitle = this.route.snapshot.data.title;
    this.userId = this.route.snapshot.params.userId;
   }

   ngOnInit() {
    this.formGroup = this.formBuilder.group({
      verificationcode : ["", Validators.required],
      password: ['', Validators.compose([Validators.required, , this.checkPassword])],
      confirmPassword: ['', Validators.compose([Validators.required])]
  });

    this.formGroup.validator = this.matchingPasswords;
}


matchingPasswords(AC: AbstractControl) {
  if (AC.get('password') && AC.get('confirmPassword')) {
    const password = AC.get('password').value;
    const confirmPassword = AC.get('confirmPassword').value;
    if (password !== confirmPassword) {
      AC.get('confirmPassword').setErrors({matchingPasswords: true});
    } else {
      return null;
    }
  }
}

checkPassword(control) {
  let enteredPassword = control.value
  let passwordCheck = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/;
  return (!passwordCheck.test(enteredPassword) && enteredPassword) ? { 'requirements': true } : null;
}


getErrorPassword() {
  return this.formGroup.get('password').hasError('required') ? 'Password needs to be at least eight characters. Password should contain Uppercase character, Lowercase character, Number (0-9) or Special characters.' :
    this.formGroup.get('password').hasError('requirements') ? 'Password needs to be at least eight characters, one lowercase letter uppercase letter and one number' : '';
}

onSubmit(post:any) {
  if(this.formGroup.valid){
    this.loadingFlag = true;
    let object = { "verification_code": post['verificationcode'], "new_password": post['password'] }
    this.authenticationService.verifyAccount(this.userId, object)
    .pipe(first())
    .subscribe(data => {
      this.loadingFlag = false;
      this.notificationMsg.showSucess("Password Reset Successfully");
      this.router.navigate(['/sign-in']);
    }, error => {
    this.loadingFlag = false;
    });
  }
}

}
