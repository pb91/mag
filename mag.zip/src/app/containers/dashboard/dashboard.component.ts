import { Component, OnInit, NgZone } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavigationService } from '@appServices/navigation.service';
import * as _ from 'lodash';
import { Roles  } from '../../shared/roles';
import * as moment from 'moment';
import { UtilityService  } from '../../shared/utility.service';

// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../globalStore';

// import { UPDATE_PREFERENCE } from 'app/globalStore/actions/preference.actions';
// import { LOAD_DASHBOARD } from 'app/globalStore/actions/dashboard.actions';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public pageTitle: string;
  public plant;
  public mapsData;
  public showHideFlag: boolean = false;
  public dashCard = [];
  public loadingBar: boolean;

  // Declaration for Global engery consumption 
  public loadingEnergyConsumption: boolean;
  public titleEnergyConsumption: string = '';
  public SeriesDataEnergyConsumption: object;

  //Declaration for Global engery Saving 
  public titleEnergySaving: string = '';
  public SeriesDataEnergySaving: object;
  public loadingEnergySaving: boolean;
  public displayGlobalDashboard : boolean = false;
  
  //Sidebar toggle
  public toggle:any ;
  public selectedId: string;

  defaultToDate : any = new Date().toISOString();
  defaultfromDate : any = new Date(`01-01-${new Date().getFullYear()}`); 
  months : any = [];
  presentRolesArray: [];
  configuration = {
    filters: {
      column: true,
      sort: true,
      search: true,
      groupBy: true,
      filter: true
    },
    others: {
      dateFormat: ''
    },
    columnFilterConditions: [
      { value: 'contains', label: 'Contains', search: true }
    ],
    columns: [
      {
        column: 'Name',
        visibility: true,
        groupBy: true,
        isAnchor: true,
        sort: true,
        filter: true,
        groupByState: true,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Email',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Contact',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: true,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Phone',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Building',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Departments',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      }
    ]
  };

  savingsYear:string;
  consumptionYear:string;
  currentYear: number;

  constructor(
    private _navigationService: NavigationService,
    private route: ActivatedRoute,
    private utils: UtilityService,
    private router: Router,
    private store: Store<fromStore.ContainerState>
  ) {
    this.pageTitle = this.route.snapshot.data.title;
    this.presentRolesArray = this.route.snapshot.data.roles;

    //Get Current Year 
    let today = new Date();
    this.currentYear = today.getFullYear();

   }

  getLast3Years() {
    for (let i = 0; i < 4; i++) {
      this.months.push({name : this.currentYear - i } );
    }
  }

  getDate(year:number) {
    const startOfYear = moment().year(year).startOf('year').toISOString();
    const endOfYear  = moment().year(year).endOf('year').toISOString();
    return {from: startOfYear, to: endOfYear };
  }    


  getOnChangeSaving(year:string) {
    if(this.savingsYear != year){
      this.savingsYear = year;
      let range = this.getDate(parseInt(year));
      this.callEnergySaving(range.from, range.to);
    }
  }

  getOnChangeConsumption(year:string) {
    if(this.consumptionYear != year){
      this.consumptionYear = year;
      let range = this.getDate(parseInt(year));
    this.callEnergyConsumption(range.from, range.to);
    }
  }

  onMenuClicked() {
    this._navigationService.toggleMenu();
  }

  toggleEvent() {
    this.showHideFlag = !this.showHideFlag;
  }

  getPlants() {
    this.store.dispatch(new fromStore.LoadDashboard());
    this.store.select<any>('dashboard').subscribe(state => {
      this.loadingBar = state.loading;
      this.dashCard = state.data.KPI;
      this.plant = state.data.tableData;
      this.mapsData = state.data.mappingData;
      this.selectedId = _.size(this.plant) > 0 ? _.map(this.plant.map((obj)=>obj.PlantID)).join(',') : '' ;

      if(_.size(this.plant) > 0 && this.utils.validateURL(Roles.Dashboard.view) && this.selectedId) {
        this.displayGlobalDashboard = true;
        this.getGlobalChartData();
      }

      
    });
  }

  getGlobalChartData() {
    let dateRange = this.getDate(this.currentYear);
    this.callEnergyConsumption(dateRange.from, dateRange.to);
    this.callEnergySaving(dateRange.from, dateRange.to);
    this.store.select<any>('globalDashboard').subscribe(state => {
      this.displayGlobalEnergyConsumption(state.globalEnergyConsumption);
      this.displayGlobalEnergySaving(state.globalEnergySaving);
    });
  }

  // To get energy cost and consumption.
  callEnergyConsumption(from:any, to:any) {
    this.store.dispatch(new fromStore.LoadEnergyConsumption(from , to, this.selectedId, "GlobalEnergyConsumption"));
  }

  callEnergySaving(from:any, to:any) {
    this.store.dispatch(new fromStore.LoadEnergySaving(from , to, this.selectedId, "GlobalEnergySaving"));
  }

  isArrayEqual(x: any, y:any) {
    return _(x).differenceWith(y, _.isEqual).isEmpty();
  };
  
  displayGlobalEnergyConsumption(energyConsumption) {

    // Checking if loaded 
    if(energyConsumption.loaded) {
      // First time if value key is not there assiging to variable else checking the difference.
      if(!_.hasIn(this.SeriesDataEnergyConsumption, 'value')) {
        this.SeriesDataEnergyConsumption = energyConsumption.data;
      } else
      if(!this.isArrayEqual(this.SeriesDataEnergyConsumption['value'], energyConsumption.data.value)) {
        this.SeriesDataEnergyConsumption = energyConsumption.data;
      }
    }

    let chartTitle = this.utils.displayChartTitle('globalConsumption');
    this.titleEnergyConsumption = chartTitle['title'];
    this.loadingEnergyConsumption = energyConsumption.loading;
  }

  displayGlobalEnergySaving(energySaving) {
     this.loadingEnergySaving = energySaving.loading;

     let chartTitle = this.utils.displayChartTitle('globalSaving');
     this.titleEnergySaving = chartTitle['title'];

    // Checking if loaded 
    if(energySaving.loaded) {
      // First time if value key is not there assiging to variable else checking the difference.
      if(!_.hasIn(this.SeriesDataEnergySaving, 'value')) {
        this.SeriesDataEnergySaving = energySaving.data;
      } else
      if(!this.isArrayEqual(this.SeriesDataEnergySaving['value'], energySaving.data.value)) {
        this.SeriesDataEnergySaving = energySaving.data;
      }
    }
     
  }

  ngOnInit() {
    this.getLast3Years();
    this.toggleEvent();
    this.getPlants();
    this.store.dispatch(new fromStore.ResetPreference());
    this.store.dispatch(new fromStore.ClearUser());
  }

  anchorPressed(event) {
    let plantId = event.data.PlantID;
    this.store.dispatch(new fromStore.ResetPlantSummary());
    this.store.dispatch(new fromStore.ResetDepartSummary());
    this.store.dispatch(new fromStore.ResetEquipSummary());
    this.store.dispatch(new fromStore.ResetDevice());
    this.store.dispatch(new fromStore.LoadRestPlant());
    this.store.dispatch(new fromStore.UpdatePreference(plantId));
    this.utils.redirectBasedonRoles(plantId);
  }

  ngOnDestroy(){
  }

}
