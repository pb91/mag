import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { UtilityService } from '../../../shared/utility.service';
import { PlantService } from '@appServices/plant.service';

import * as _ from 'lodash';
import * as moment from 'moment';

import { Store } from '@ngrx/store';
import * as fromStore from '../../../globalStore';
import { stringify } from '@angular/compiler/src/util';


export interface details {
  name: string;
}

export interface imageDetails {
  name: string
  details: polygon
}


export interface polygon {
  data: any
  palette: any
  hex: any
  name: any
}




@Component({
  selector: 'app-floor-plan-view-org',
  templateUrl: './floor-plan-view-org.component.html',
  styleUrls: ['./floor-plan-view-org.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('animationOption2', [      
      transition(':enter', [
        style({ 
        
          opacity : 1
      }),
        animate(3000)
      ]),
    ])
  ]
})
export class FloorPlanViewOrgComponent implements OnInit {
    
  public asset : string = "PLANT"
  public viewOnly : boolean = true;
  public loadingFlag : boolean = false;
  public pageTitle: string;
  public plantId: string;
  public buildingId: string;
  public imageName: string = "";
  public buildingImages: Array<imageDetails> = [];
  public departmentImages: Array<imageDetails> = [];


  //selected Building in Building level
  public selectedBuilding : any = null ;
  public selectedBuildingName : any = null ;
  //Selected Department in department level 
  public selectedDepartment : any = null ;
  public selectedDepartmentName : any = null ;

  public loading: boolean = false;
  public plantName: string;
  public plantData : any ;
  public herarchy : any;
  public selectedIndex : number = 0;

  levelDataBuilding: any = [];
  levelDataDepartment : any =[];
  levelDataEquipments : any = [];
  //DrawingBoard data
  DR;
  CR;
  HR;
  NM;
  palette = [];
  hex = [];
  data = [];
  name: Array<details> = [];

  tool : boolean = false;
 listViewData : any ;
 dashCardCloneBuilding ;
 dashCardCloneDepartment;
 stateName = 'hide';
  public dashCard = [
    {
      colorDark: '#5C6BC0',
      colorLight: '#7986CB',
      number: '0',
      title: `CONSUMPTION`,
      unit: ``,
      icon: 'offline_bolt'
    }, {
      colorDark: '#42A5F5',
      colorLight: '#64B5F6',
      number: 0,
      unit: ``,
      title: 'ENERGY COST',
      icon: 'attach_money'
    },
    {
      colorDark: "rgb(245, 170, 170)",
      colorLight: "rgb(254, 205, 205)",
      number: 0,
      unit: ``,
      title: 'SAVING',
     
    },
    {
      colorDark: "rgb(245, 170, 170)",
      colorLight: "rgb(254, 205, 205)",
      number: 0,
      unit: ``,
      title: 'ALARMS',
     
    } ,{
      colorDark: "#66BB6A",
      colorLight: "#81C784",
      number: 0,
      unit: ``,
      title: 'DEVICES',
  
    },
    {
      colorDark: "rgb(245, 170, 170)",
      colorLight: "rgb(254, 205, 205)",
      number: 0,
      unit: ``,
      title: 'DEPARTMENTS',
     
    },
  ];



  constructor(private store: Store<fromStore.ContainerState>,
    private utils: UtilityService,
    private plantService: PlantService, private route: ActivatedRoute) {
    this.pageTitle = this.route.snapshot.data.title
    this.plantId = this.route.snapshot.params.id;
  }

  ngOnInit() {
    this.loading = true;
    this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.getPlantDetails();
    
    // this.retrieveDrawingData();
  }

 


  getPlantDetails() {
    this.store.select<any>('plant').subscribe(state => {
      
      this.plantData = state.data;
      this.levelDataBuilding = state.data && state.data['Buildings'] ? state.data['Buildings'] : [];
      this.levelDataDepartment = state.data && state.data['Departments'] ? state.data['Departments'] : [];
      this.levelDataEquipments = state.data && state.data['Equipments'] ? state.data['Equipments'] : [];
      this.herarchy =  this.getHerarchy(state.data);
      if(this.asset === "PLANT" && this.herarchy['PLANT']['Images'] && this.herarchy['PLANT']['Images'].length){
     
        this.imgClick(this.herarchy['PLANT']['Images'][this.selectedIndex]);
        this.getLIstViewData(this.herarchy);
      }else{
        this.loading = state.loading
       
      }
     // this.loading = state.loading
      this.plantName = state.data.PlantName;
      
    });
  }

  getLIstViewData(data){
    switch (this.asset.trim()) {
 
      case 'PLANT':
      this.listViewData = [data['PLANT']];
      break;
      case 'DEPARTMENT':
      this.listViewData = [];
      this.listViewData = [data];
      break;
      case 'BUILDING':
      this.listViewData = [];
      this.listViewData = [data];
      break;
  
    default:
  }
  }

  imgClick(img) {
    
   
    this.stateName = "hide"
   // this.loading = true;
    this.imageName = undefined;
    setTimeout(()=>{
   
      this.imageName = img ? img['ImagePath'] : "";
   
      if(img){
        this.retrieveDrawingData(img);
      }
      console.log("end")
     this.loading = false;
      this.stateName = "show"
    
    },1000)
   
  }

  
  retrieveDrawingData(obj) {
    this.data = obj.details && obj.details.data ? obj.details.data : [];
    this.palette = obj.details && obj.details.palette ? obj.details.palette : [];
    this.hex = obj.details && obj.details.hex ? obj.details.hex : [];
    this.name = obj.details && obj.details.name ? obj.details.name : [];
  }



  getHerarchy(data){
    let herarchy = {'PLANT' : {
      'id' : this.plantId ?  this.plantId : null,
      'name' : data.PlantName ? data.PlantName : "",
      'Images' : data.Images ? data.Images : null,
      'BUILDING' : []
    }};

    let eqipData = [];

    if(this.levelDataBuilding.length){
      this.levelDataBuilding.forEach((ele , index) => {
      let building = {'id' : ele['BuildingID'] , 'name' : ele['BuildingName'] , 'Images' : ele['Images'] , 'DEPARTMENT' :[] };
      let bldg = _.filter(data['Equipments'], _.conforms({ 'Building': function(n) { return n ===  ele['BuildingID']; } }));
    
        eqipData.push({ id  : ele['BuildingID'] , data : bldg});

        if(this.levelDataDepartment.length){
          this.levelDataDepartment.forEach((element , i) => {
            if(bldg.length && _.findIndex(bldg, ['Department', element['DepartmentID']])){
              let Department = {'id' : element['DepartmentID'] , 'name' : element['DepartmentName'] , 'Images' : element['Images'] , 'EQUIPMENT' :[] };
              let dept = _.filter(bldg, _.conforms({ 'Department': function(n) { return n ===  element['DepartmentID']; } }));
              Department['EQUIPMENT'] = dept;
              building['DEPARTMENT'].push(Department);
            }
          });
        }

        herarchy['PLANT']['BUILDING'].push(building);

      });
    }

 
    return herarchy;
  }

  getPlantMetaData(deviceIDs){
    this.loading = true;
   if(deviceIDs.length){
   const  endDate = moment().subtract(7, 'days').toISOString() ;
   const startDate= moment(new Date()).toISOString();
      this.plantService.getPlantTelemetry(this.plantId, "", "NA", endDate, startDate,  deviceIDs, "60mins").subscribe(data => {
     
        let convertedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, "Kwh");
  
        this.dashCard[0].unit = "Kwh";
        this.dashCard[0].unit = convertedValue.units;
        this.dashCard[0].number = this.utils.roundNumber(convertedValue.consumption, 2);
  
        this.dashCard[1].unit = '$'
        this.dashCard[1].number = this.utils.roundNumber( data.totalEnergyCost, 2);
        

        this.dashCard[2].unit = '$'
        this.dashCard[2].number = this.utils.roundNumber( data.totalSaving, 2);

        
        
          let equip = 0 ;
          this.herarchy['PLANT']['BUILDING'].forEach(element => {
            if(deviceIDs === element.id){
              element['DEPARTMENT'].forEach(ele => {
                equip = equip + ele['EQUIPMENT'].length
              });
              

              
        this.dashCard[3].unit = "";
        this.dashCard[3].number = this.utils.roundNumber(equip ? equip : 0, 2);
        
              this.dashCard[5].unit = "";
              this.dashCard[5].number = this.utils.roundNumber(element['DEPARTMENT'] ? element['DEPARTMENT'].length : 0, 2);
              this.dashCard[4].unit = "";
              this.dashCard[4].number = this.utils.roundNumber(equip ? equip : 0, 2);
            }
         
          });
        
      
      

      
      
        this.loading = false;
        this.dashCardCloneBuilding = _.cloneDeep(this.dashCard);
      }, error => {
     
        this.loading = false;
      });}
  }

  getDepartmentMetaData(deviceIDs){
    this.loading = true;
    if(deviceIDs.length){
    const  endDate = moment().subtract(7, 'days').toISOString() ;
    const startDate= moment(new Date()).toISOString();
       this.plantService.getDepartmentTelemetry(this.plantId, "", "NA", endDate, startDate,  deviceIDs, "60mins").subscribe(data => {
       
         let convertedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, "Kwh");
   
         this.dashCard[0].unit = "Kwh";
         this.dashCard[0].unit = convertedValue.units;
         this.dashCard[0].number = this.utils.roundNumber(convertedValue.consumption, 2);
   
         this.dashCard[1].unit = '$'
         this.dashCard[1].number = this.utils.roundNumber( data.totalEnergyCost, 2);
         
 
         this.dashCard[2].unit = '$'
         this.dashCard[2].number = this.utils.roundNumber( data.totalSaving, 2);
 
         this.dashCard[3].unit = "";
         this.dashCard[3].number = this.utils.roundNumber(this.herarchy['PLANT']['BUILDING'].Devices ? this.herarchy['PLANT']['BUILDING'].Devices.length : 0, 2);
         
         
           let equip = 0 ;
           this.herarchy['PLANT']['BUILDING'].forEach(element => {
             if(this.selectedBuilding === element.id){
               element['DEPARTMENT'].forEach(ele => {
                 if(ele.id == deviceIDs){
                  equip = equip + ele['EQUIPMENT'].length
                 }
               });
               
 
               this.dashCard[3].unit = "";
               this.dashCard[3].number = this.utils.roundNumber(equip ? equip : 0, 2);
         
               this.dashCard[5].unit = "";
               this.dashCard[5].number = this.utils.roundNumber(element['DEPARTMENT'] ? element['DEPARTMENT'].length : 0, 2);
               this.dashCard[4].unit = "";
               this.dashCard[4].number = this.utils.roundNumber(equip ? equip : 0, 2);
             }
          
           });

       
         this.loading = false;
         this.dashCardCloneDepartment = _.cloneDeep(this.dashCard);
       }, error => {
     
         this.loading = false;
       });}

  }

  getEquipmentMetaData(deviceIDs){
    

    this.loading = true;
    if(deviceIDs.length){
    const  endDate = moment().subtract(7, 'days').toISOString() ;
    const startDate= moment(new Date()).toISOString();
       this.plantService.getEquipmentTelemetry(this.plantId, "", "NA", endDate, startDate,  deviceIDs, "60mins").subscribe(data => {
       
         let convertedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, "Kwh");
   
         this.dashCard[0].unit = "Kwh";
         this.dashCard[0].unit = convertedValue.units;
         this.dashCard[0].number = this.utils.roundNumber(convertedValue.consumption, 2);
   
         this.dashCard[1].unit = '$'
         this.dashCard[1].number = this.utils.roundNumber( data.totalEnergyCost, 2);
         
 
         this.dashCard[2].unit = '$'
         this.dashCard[2].number = this.utils.roundNumber( data.totalSaving, 2);
 
         this.dashCard[3].unit = "";
         this.dashCard[3].number = this.utils.roundNumber(this.herarchy['PLANT']['BUILDING'].Devices ? this.herarchy['PLANT']['BUILDING'].Devices.length : 0, 2);
         
    
         this.dashCard[3].unit = "";
         this.dashCard[3].number = 0;
   
         this.dashCard[5].unit = "";
         this.dashCard[5].number = 0;
         this.dashCard[4].unit = "";
         this.dashCard[4].number = 0;

       
         this.loading = false;
       }, error => {
     
         this.loading = false;
       });}

  }


  actionEvnt(e) {
   
  
    switch (e.event.trim()) {

        case 'META':
        if(e.asset === 'PLANT'){
          this.getPlantMetaData(e.data);
         
        }else if(e.asset === 'BUILDING'){
          this.getDepartmentMetaData(e.data)
         
        }else if (e.asset === 'DEPARTMENT'){
          this.getEquipmentMetaData(e.data)
        }
        break;



        case 'NAV':
        if(e.asset === 'PLANT'){
        this.selectedBuilding = e.id;
         if(this.asset === "PLANT" && this.herarchy['PLANT']['BUILDING']){
          let bld ;
          this.asset = "BUILDING";
          this.herarchy['PLANT']['BUILDING'].forEach(element => {
            if(element.id == e.id){
              bld = element;
              this.selectedBuildingName = element.name;
            }
          });
          this.imgClick(bld['Images'] && bld['Images'].length ? bld['Images'][0]:null)
          this.getLIstViewData(bld);
        }
        }else if(e.asset === 'BUILDING'){
          this.selectedDepartment = e.id;
  
          if(this.asset === "BUILDING" && this.herarchy['PLANT']['BUILDING']){
           let dpr ;
           this.asset = "DEPARTMENT";
           this.herarchy['PLANT']['BUILDING'].forEach(element => {
         
             if(element.id == this.selectedBuilding){
             
               element['DEPARTMENT'].forEach(ele => {
                 if(ele.id == e.id){
                  dpr = ele;
              
                  this.selectedDepartmentName = ele.name;
                 }
               });
              
             }
           });
           this.imgClick(dpr['Images'] && dpr['Images'].length ? dpr['Images'][0]:null)
           this.getLIstViewData(dpr);
         }
          
        }
        break;


        case 'BREAD':
        if(e.to === "PLANT"){
          this.imgClick(this.herarchy['PLANT']['Images'][0])
          this.asset = "PLANT";
          this.getLIstViewData(this.herarchy);
          this.selectedBuildingName = undefined;
          this.selectedBuilding = undefined;
          this.selectedDepartment = undefined;
          this.selectedDepartmentName = undefined;
        }else if(e.to === "BUILDING"){
        
          this.asset = "BUILDING";
          let bld;
          this.herarchy['PLANT']['BUILDING'].forEach(element => {
            if(element.id == e.id){
              bld = element;
              this.selectedBuildingName = element.name;
            }
          });
          this.imgClick(bld['Images'][0]);
          this.getLIstViewData(bld);
          this.selectedDepartment = undefined;
          this.selectedDepartmentName = undefined;
        }
      default:
    }

  }



changeLevel(asset , plant , building , department){

}




}
