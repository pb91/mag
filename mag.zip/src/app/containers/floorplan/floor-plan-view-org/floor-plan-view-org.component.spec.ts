import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FloorPlanViewOrgComponent } from './floor-plan-view-org.component';

describe('FloorPlanViewOrgComponent', () => {
  let component: FloorPlanViewOrgComponent;
  let fixture: ComponentFixture<FloorPlanViewOrgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FloorPlanViewOrgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FloorPlanViewOrgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
