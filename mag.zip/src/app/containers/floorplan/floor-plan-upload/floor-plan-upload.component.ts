import { Component, OnInit } from '@angular/core';
import { UsersService } from '@appServices/users.service';
import {ActivatedRoute, Router} from '@angular/router';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { UtilityService  } from '../../../shared/utility.service';
// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../../globalStore';
import { DialogboxComponent } from '@appComponents/dialogbox/dialogbox.component';
import { MatDialog } from '@angular/material';
import * as _ from 'lodash';

@Component({
  selector: 'app-floor-plan-upload',
  templateUrl: './floor-plan-upload.component.html',
  styleUrls: ['./floor-plan-upload.component.scss']
})
export class FloorPlanComponent implements OnInit {
  pageTitle : string;
  plantID = "";
  plantName;
  constructor(public dialog: MatDialog, private usersService: UsersService, 
    public notificationMsg : ToastComponent,
    private utils: UtilityService,
    private route: ActivatedRoute, private router: Router , private store: Store<fromStore.ContainerState>) { 

      this.pageTitle = this.route.snapshot.data.title
      this.plantID = this.route.snapshot.params.id;
    }

  ngOnInit() {
    this.store.dispatch(new fromStore.UpdatePreference(this.plantID));
    
    this.store.select<any>('plant').subscribe(state => {

      this.plantName = state.data.PlantName;

    });
  }


  onFileComplete(data: any) {
    console.log(data);
  }

}
