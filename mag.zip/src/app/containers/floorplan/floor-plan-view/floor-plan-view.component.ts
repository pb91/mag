import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { UtilityService } from '../../../shared/utility.service';
import { PlantService } from '@appServices/plant.service';

import * as _ from 'lodash';
import * as moment from 'moment';

import { Store } from '@ngrx/store';
import * as fromStore from '../../../globalStore';
import { stringify } from '@angular/compiler/src/util';


export interface details {
  name: string;
}

export interface imageDetails {
  name: string
  details: polygon
}


export interface polygon {
  data: any
  palette: any
  hex: any
  name: any
}

export interface save {
  plantId: string
  images: Array<imageDetails>
}



@Component({
  selector: 'app-floor-plan-view',
  templateUrl: './floor-plan-view.component.html',
  styleUrls: ['./floor-plan-view.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FloorPlanViewComponent implements OnInit {
  public viewOnly : boolean = true;
  public loadingFlag : boolean = false;
  public pageTitle: string;
  public plantId: string;
  public buildingId: string;
  public imageName: string = "";
  public images: Array<imageDetails> = [];
  public buildingImages: Array<imageDetails> = [];
  public departmentImages: Array<imageDetails> = [];


  //selected Building in Building level
  public selectedBuilding : any = null ;
  public selectedBuildingName : any = null ;
  //Selected Department in department level 
  public selectedDepartment : any = null ;
  public selectedDepartmentName : any = null ;

  public loading: boolean = false;
  public plantName: string;
  public plantData : any ;
  private compData: Array<imageDetails>;
  private compDataBuildingLevel: Array<imageDetails>;
  private compDataDepartmentLevel: Array<imageDetails>;

  links = ['First', 'Second', 'Third'];
  activeLink = this.links[0];
  background = '';
  levelDataBuilding: any = [];
  levelDataDepartment : any =[];
  levelDataEquipments : any = [];
  //DrawingBoard data
  DR;
  CR;
  HR;
  NM;
  palette = [];
  hex = [];
  data = [];
  name: Array<details> = [];
  savedJSON: Array<save> = [];
  selectedIndex : number =0;
  asset : string = "building"
  public dashCard = [
    {
      colorDark: '#5C6BC0',
      colorLight: '#7986CB',
      number: '0',
      title: `CONSUMPTION`,
      unit: ``,
      icon: 'offline_bolt'
    }, {
      colorDark: '#42A5F5',
      colorLight: '#64B5F6',
      number: 0,
      unit: ``,
      title: 'ENERGY COST',
      icon: 'attach_money'
    },
    {
      colorDark: "#66BB6A",
      colorLight: "#81C784",
      number: 0,
      unit: ``,
      title: 'DEVICES',
  
    },
    {
      colorDark: "rgb(245, 170, 170)",
      colorLight: "rgb(254, 205, 205)",
      number: 0,
      unit: ``,
      title: 'DEPARTMENTS',
     
    }
  ];



  constructor(private store: Store<fromStore.ContainerState>,
    private utils: UtilityService,
    private plantService: PlantService, private route: ActivatedRoute) {
    this.pageTitle = this.route.snapshot.data.title
    this.plantId = this.route.snapshot.params.id;
  }

  ngOnInit() {
    this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.getPlantDetails();
    // this.retrieveDrawingData();
  }


  getPlantDetails() {
    this.store.select<any>('plant').subscribe(state => {
      this.images = [];
      console.log('state', state)
      this.plantData = state.data;
      //TODO :: Update it according to the tab selected
      this.levelDataBuilding = state.data && state.data['Buildings'] ? state.data['Buildings'] : [];
      this.levelDataDepartment = state.data && state.data['Departments'] ? state.data['Departments'] : [];
      this.levelDataEquipments = state.data && state.data['Equipments'] ? state.data['Equipments'] : [];
      this.buildingData();
      this.departmentData();
      
      this.getMetaData();

      if (state.data && state.data.Images && state.data.Images.length) {

        state.data.Images.forEach((obj) => {
          this.images.push({ name: obj['ImagePath'], details: obj['details'] })
        })

        this.compData = _.cloneDeep(this.images);
        
      }

      this.loading = state.loading
      console.log("this.loading ", this.loading)
      this.plantName = state.data.PlantName;
    });
  }

  imgClick(img) {
    this.imageName = img.name;
    console.log("img", img)
    this.retrieveDrawingData(img);
  }

  changeBuilding(d){
    console.log(d);
    this.buildingData();
  }

  changeDepartment(d){
    this.departmentData()
  }

  buildingData(){
   
    if(this.selectedBuilding){
      this.buildingId =  this.selectedBuilding;
      this.buildingImages = [];
      this.levelDataBuilding.forEach((obj) => {
        if(obj['BuildingID'].trim() === this.selectedBuilding.trim()){
          this.selectedBuildingName = obj['BuildingName']
          if(obj.Images){
            obj.Images.forEach((obj) => {
              this.buildingImages.push({ name: obj['ImagePath'], details: obj['details'] })
            })
          }
         
        }
      });

      this.compDataBuildingLevel = _.cloneDeep(this.buildingImages);
    
    }
  }

  departmentData(){
    if(this.selectedDepartment){
      this.departmentImages = [];
      this.levelDataDepartment.forEach((obj)=>{
        if(obj['DepartmentID'].trim() === this.selectedDepartment.trim()){
          this.selectedDepartmentName = obj['DepartmentName']
          if(obj.Images){
            obj.Images.forEach((obj) => {
              this.departmentImages.push({ name: obj['ImagePath'], details: obj['details'] })
            })
          }
         
        }
      })

      this.compDataDepartmentLevel = _.cloneDeep(this.departmentImages);

    }
  }

  getMetaData(){
    this.loading = true;
    let deviceIDs = "";
    this.levelDataBuilding.forEach((obj,index)=>{
      if(index === this.levelDataBuilding.length -1){
        deviceIDs =  deviceIDs + obj.BuildingID;
      }else{
        deviceIDs =  deviceIDs + obj.BuildingID + ",";
      }
     
    })

    console.log("device" , deviceIDs)
   if(deviceIDs.length){
   const  endDate = moment().subtract(7, 'days').toISOString() ;
   const startDate= moment(new Date()).toISOString();
      this.plantService.getPlantTelemetry(this.plantId, "", "NA", endDate, startDate,  deviceIDs, "60mins").subscribe(data => {
        console.log("data" , data)
        let convertedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, "Kwh");
  
        this.dashCard[0].unit = "Kwh";
        this.dashCard[0].unit = convertedValue.units;
        this.dashCard[0].number = this.utils.roundNumber(convertedValue.consumption, 2);
  
        this.dashCard[1].unit = '$'
        this.dashCard[1].number = this.utils.roundNumber( data.totalEnergyCost, 2);
  
        this.dashCard[2].unit = "";
        this.dashCard[2].number = this.utils.roundNumber(this.plantData.Devices ? this.plantData.Devices.length : 0, 2);
  
        this.dashCard[3].unit = "";
        this.dashCard[3].number = this.utils.roundNumber(this.plantData.Departments ? this.plantData.Departments.length : 0, 2);
        console.log(" this.dashCard", this.dashCard)
        this.loading = false;
      }, error => {
        console.log(error);
        this.loading = false;
      });}
  }

  getDepartmentMetaData(){
    this.loading = true;
    let departmentIDs = "";
    this.levelDataDepartment.forEach((obj,index)=>{
      if(index === this.levelDataDepartment.length -1){
        departmentIDs =  departmentIDs + obj.DepartmentID;
      }else{
        departmentIDs =  departmentIDs + obj.DepartmentName + ",";
      }
     
    })

    if(departmentIDs.length){
      const endDate = moment().subtract(7, 'days').toISOString() ;
      const startDate = moment(new Date()).toISOString();
    this.plantService.getDepartmentTelemetry(this.plantId, "", "NA", endDate, startDate,  departmentIDs, "60mins").subscribe(data => {


      let convertedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, "Kwh");
      this.dashCard[0].unit = convertedValue.units;
      this.dashCard[0].number = this.utils.roundNumber(convertedValue.consumption, 2);

      this.dashCard[1].unit = '$'
      this.dashCard[1].number = this.utils.roundNumber( data.totalEnergyCost, 2);

      this.dashCard[2].unit = "";
      this.dashCard[2].number = this.utils.roundNumber(this.plantData.Devices ? this.plantData.Devices.length : 0, 2);

      this.dashCard[3].unit = "";
      this.dashCard[3].number = this.utils.roundNumber(this.plantData.Departments ? this.plantData.Departments.length : 0, 2);
      this.loading = false;
    }, error => {
      console.log(error);
      this.loading = false;
    });}

  }

  getEquipmentMetaData(){
    this.loading = true;
    let equipmentIDs ;
    // this.levelDataEquipments.forEach((obj,index)=>{
    //   if(index === this.levelDataEquipments.length -1){
    //     equipmentIDs =  equipmentIDs + obj.Equipment;
    //   }else{
    //     equipmentIDs =  equipmentIDs + obj.Equipment + ",";
    //   }
     
    // })

    equipmentIDs =  this.levelDataEquipments.map((obj,index)=> obj.Equipment)

    if(equipmentIDs.length){
      const endDate = moment().subtract(7, 'days').toISOString() ;
      const startDate = moment(new Date()).toISOString();


      this.plantService.getEquipmentTelemetry(this.plantId, "", "NA", endDate, startDate,  equipmentIDs, "60mins").subscribe(data => {
      
        let consumedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, 'kWh');
        this.dashCard[0].unit = consumedValue.units;
        this.dashCard[0].number = this.utils.roundNumber(consumedValue.consumption, 2);
  
        this.dashCard[1].unit = '$'
        this.dashCard[1].number = this.utils.roundNumber( data.totalEnergyCost, 2);


        
        this.dashCard[2].unit = "";
        this.dashCard[2].number = this.utils.roundNumber(this.plantData.Devices ? this.plantData.Devices.length : 0, 2);
    
  
        this.dashCard[3].unit = "";
        this.dashCard[3].number = this.utils.roundNumber(this.plantData.Departments ? this.plantData.Departments.length : 0, 2);
        this.loading = false;
      }, error => {
        console.log(error);
        this.loading = false;
      });
  }

  }

  compareForUpdate(x, y) {
    console.log("x", x)
    console.log("y", y)
    let prev, curr;
    if (x.length && y.length) {
      prev = x[0].details;
      curr = y[0].details;

      if(prev ==  null && curr == null){
        return false;
      }else if(prev != null && curr == null){
        return true;
      }
      else if(prev == null && curr != null  ){
        return true;
      }
      else if (prev.data.length !== curr.data.length) {
        return true;
      } else if (prev.hex.length !== curr.hex.length) {
        return true;
      } else if (prev.palette.length !== curr.palette.length) {
        return true;
      } else if (prev.name.length !== curr.name.length) {
        return true;
      } else {
        let eql = false;
        if (prev.name.length && curr.name.length) {
          curr.name.forEach(element1 => {
            prev.name.forEach(element2 => {
              if(element1 == null && element2 != null){
                eql = true;
              }else if(element1 != null && element2 == null){
                eql = true;
              }
              else if ( (element1 != null && element2 != null) && (element1.name.trim() !== element2.name.trim())  ) {
                eql = true;
              }
            });
          });
        }


        return eql;
      }

    }

  }


  saveDrawingData(event, data, palette, hex, name, imageName, plantId) {
    let prev , curr;
    if(this.asset === "building"){
    const compareValues =   this.plantLevelSaveCoordinate(event, data, palette, hex, name, imageName, plantId );
    prev = compareValues.prev;
    curr = compareValues.curr;
    }else if(this.asset === "department"){
      const compareValues =   this.buildingLevelSaveCoordinate(event, data, palette, hex, name, imageName, plantId );
      prev = compareValues.prev;
      curr = compareValues.curr;
    }else if (this.asset === "equipment"){
      const compareValues =   this.departmentLevelSaveCoordinate(event, data, palette, hex, name, imageName, plantId );
      prev = compareValues.prev;
      curr = compareValues.curr;
    }

    console.log("this.compareForUpdate( this.compData )", this.compareForUpdate(prev, curr))

    if (this.compareForUpdate(prev, curr)) {

      this.plantService.updateCoordinates(event, data, palette, hex, name, imageName, plantId ,  this.selectedBuilding , this.selectedDepartment, this.asset).subscribe(data => {
        console.log("got data for coordinates", data)

        this.store.dispatch(new fromStore.LoadPlant(this.plantId));
        //  this.notificationMsg.showSucess("File Upload Successfully");
        //this.getPlantDetails();

      }, error => {
        this.loading = false;
      });
    } else {
      this.plantService.saveCoordinates(event, data, palette, hex, name, imageName, plantId, this.selectedBuilding , this.selectedDepartment, this.asset).subscribe(data => {
        console.log("got data for coordinates", data)

        this.store.dispatch(new fromStore.LoadPlant(this.plantId));
        //  this.notificationMsg.showSucess("File Upload Successfully");
        //this.getPlantDetails();

      }, error => {
        this.loading = false;
      });
    }



    ///Below code was used for local storage approach

    // let found = false;
    // let imgFound = false;
    // console.log("this.savedJSON", this.savedJSON);
    // this.savedJSON.forEach(obj => {
    //   if (obj['plantId'] === this.plantId) {
    //     found = true;
    //     if (_.size(obj['images']) > 0) {
    //       obj['images'].forEach((img) => {
    //         if (img.name.trim() === this.imageName.trim()) {
    //           imgFound = true;
    //           img['details'].data = data;
    //           img['details'].palette = palette,
    //             img['details'].hex = hex,
    //             img['details'].name = name;
    //         }
    //       });
    //     }

    //     if(!imgFound){
    //       obj['images'].push({
    //         name: this.imageName,
    //         details: {
    //           data,
    //           palette,
    //           hex,
    //           name
    //         }
    //       });
    //     }


    //   } 
    // });

    // if(!found){
    //   this.savedJSON.push({
    //     plantId: this.plantId,
    //     images: [{
    //       name: this.imageName,
    //       details: {
    //         data,
    //         palette,
    //         hex,
    //         name
    //       }
    //     }]
    //   });
    //   }

    // // this.savedJSON.images.forEach((img)=>{
    // //     if(img.name.trim === this.imageName.trim) {
    // //       img.details['data'] = data;
    // //       img.details['palette'] = palette;
    // //       img.details['hex'] = hex;
    // //       img.details['name'] = name;
    // //     }
    // // });


    // localStorage.setItem('polygon', JSON.stringify(this.savedJSON))

    // // localStorage.setItem('polygn', JSON.stringify(data));
    // // localStorage.setItem('palette', JSON.stringify(palette));
    // // localStorage.setItem('hex', JSON.stringify(hex));
    // // localStorage.setItem('name', JSON.stringify(name));

    // function pushImage(obj){

    //   console.log("obj", obj);
    //   console.log("this.imageName", this.imageName);
    //   obj['images'].push({
    //     name: this.imageName,
    //     details: {
    //       data,
    //       palette,
    //       hex,
    //       name
    //     }
    //   });
    // }

  }


  plantLevelSaveCoordinate(event, data, palette, hex, name, imageName, plantId){
    console.log("this.data", this.images)
    this.images.forEach((obj)=>{
      if(obj['name'].trim() === this.imageName.trim()){
        obj['details'] = {
          data, 
          palette, 
          hex, 
          name
        }
      }
    })
    console.log("images", this.compData)
    

    this.loading = true;

    let prev = _.filter(this.compData, (o) => { return o.name === this.imageName; });
    let curr = _.filter(this.images, (o) => { return o.name === this.imageName; });
    return {prev , curr}
  }

  buildingLevelSaveCoordinate(event, data, palette, hex, name, imageName, plantId){
    console.log("this.buildingImages", this.buildingImages)
    this.buildingImages.forEach((obj)=>{
      if(obj['name'].trim() === this.imageName.trim()){
        obj['details'] = {
          data, 
          palette, 
          hex, 
          name
        }
      }
    })
    console.log("compDataDepartmentLevel", this.compDataBuildingLevel)
    

    this.loading = true;

    let prev = _.filter(this.compDataBuildingLevel, (o) => { return o.name === this.imageName; });
    let curr = _.filter(this.buildingImages, (o) => { return o.name === this.imageName; });
    return {prev , curr}
    
  }

  departmentLevelSaveCoordinate(event, data, palette, hex, name, imageName, plantId){
    console.log("this.data", this.buildingImages)
    this.departmentImages.forEach((obj)=>{
      if(obj['name'].trim() === this.imageName.trim()){
        obj['details'] = {
          data, 
          palette, 
          hex, 
          name
        }
      }
    })
    console.log("images", this.compDataDepartmentLevel)
    

    this.loading = true;

    let prev = _.filter(this.compDataDepartmentLevel, (o) => { return o.name === this.imageName; });
    let curr = _.filter(this.departmentImages, (o) => { return o.name === this.imageName; });
    return {prev , curr}
    
  }

  retrieveDrawingData(obj) {


    this.data = obj.details && obj.details.data ? obj.details.data : [];
    this.palette = obj.details && obj.details.palette ? obj.details.palette : [];
    this.hex = obj.details && obj.details.hex ? obj.details.hex : [];
    this.name = obj.details && obj.details.name ? obj.details.name : [];

    ///Code written for Local storage approach


    // let found = false;
    // const current = JSON.parse(localStorage.getItem('polygon'));
    // if(current && current.length){
    //   this.savedJSON = current;
    // }
    // if (this.plantId && this.plantId.length && _.size(current) > 0) {
    //   current.forEach(obj => {
    //       if(obj.plantId.trim() === this.plantId.trim() ){

    //         let selectedPoly = obj;
    //         if(selectedPoly['images'] && selectedPoly['images'].length){
    //           selectedPoly['images'].forEach(element => {
    //             console.log("element.name.trim() === this.imageName.trim()" , element.name.trim() === this.imageName.trim());
    //             if(element.name.trim() === this.imageName.trim()){
    //               found = true;
    //               this.DR = element['details'].data ;// JSON.parse(localStorage.getItem('polygn'));
    //               this.CR =   element['details'].palette;
    //               this.HR = element['details'].hex;
    //               this.NM =  element['details'].name;
    //               if (this.DR && this.DR.length) {
    //                 this.data = this.DR;
    //                 if (this.CR && this.CR.length && this.HR && this.HR.length) {
    //                   this.palette = this.CR;
    //                   this.hex = this.HR;
    //                   this.name = this.NM;
    //                 }
    //               }
    //             }
    //           });
    //         }
    //       }
    //   });

    // }

    // if(!found){
    //   this.palette = [];
    //   this.hex = [];
    //   this.name = [];
    //   this.data = [];
    // }


  }


  addItem(e) {
    console.log("i am hit", e)

    this.plantService.addAsset(this.plantId, this.asset, e.id, e.name).subscribe(data => {
      console.log("got data", data)

      this.store.dispatch(new fromStore.LoadPlant(this.plantId));
      //  this.notificationMsg.showSucess("File Upload Successfully");
      //this.getPlantDetails();
      //  this.loadingBar = false;
    }, error => {
      // this.loadingBar = false;
    });
  }

  updateItem(e) {
    this.plantService.updateAsset(this.plantId, this.asset, e).subscribe(data => {
      console.log("got data", data)

      this.store.dispatch(new fromStore.LoadPlant(this.plantId));
      //  this.notificationMsg.showSucess("File Upload Successfully");
      //this.getPlantDetails();
      //  this.loadingBar = false;
    }, error => {
      // this.loadingBar = false;
    });
  }

  deleteItem(e){
    this.plantService.deleteAsset(this.plantId, this.asset, e).subscribe(data => {
      console.log("got data", data)

      if(this.asset === "building"){
        this.name.forEach((obj , index)=>{
          if(obj.name === e.BuildingID){
            this.name[index] = null;
          }
        })
      }else if(this.asset === "department"){
        this.name.forEach((obj , index)=>{
          if(obj.name === e.DepartmentID){
            this.name[index] = null;
          }
        })
      }

      let type;
      if(this.asset === "building"){
        type = 'plant'
      }else if(this.asset === "department"){
        type = 'building'
      }else {
        type = 'department'
      }
      this.saveDrawingData(type, this.data, this.palette, this.hex, this.name, this.imageName, this.plantId)
      

    //  this.store.dispatch(new fromStore.LoadPlant(this.plantId));
      //  this.notificationMsg.showSucess("File Upload Successfully");
      //this.getPlantDetails();
      //  this.loadingBar = false;
    }, error => {
      // this.loadingBar = false;
    });
  }


  actionEvnt(e) {
    console.log("e", e)
    let event, data, palette, hex, name, imageName;

    event = e.event;
    data = e.data;
    palette = e.palette;
    hex = e.hex;
    name = e.name;
    imageName = e.imageName;

    switch (event.trim()) {
      case "SAVE":
        // this.data = data;
        // this.palette = palette;
        // this.hex = hex;
        // this.name = name;
        // this.imageName = imageName;
        let type;
        if(this.asset === "building"){
          type = 'plant'
        }else if(this.asset === "department"){
          type = 'building'
        }else {
          type = 'department'
        }
        this.saveDrawingData(type, data, palette, hex, name, imageName, this.plantId)
        console.log("saved in main component")
        break;

      default:
    }

  }

  deleteImage(e){
    console.log(e)
    let data = {imagePath : e.name, rolluplevel:"plant", id:this.plantId}
    console.log(data);
      this.plantService.deleteImage(this.plantId, "plant", e.name ,data ).subscribe(data => {
        console.log("got data", data)
  
        this.store.dispatch(new fromStore.LoadPlant(this.plantId));
        //  this.notificationMsg.showSucess("File Upload Successfully");
        //this.getPlantDetails();
        //  this.loadingBar = false;
      }, error => {
        // this.loadingBar = false;
      });
    
  }

  changeTab(e){
    this.selectedBuilding =  null;
    this.selectedDepartment =  null;
    this.selectedBuildingName =  null;
    this.selectedDepartmentName = null;
    if(e.index === 1){
      this.asset = 'department';
      this.getDepartmentMetaData();

    }else if(e.index === 0){
      this.asset = 'building';
      this.getMetaData()
    }else if(e.index === 2){
      this.asset = 'equipment'
      this.getEquipmentMetaData();
    }
    console.log("eee" , e.index)

  }

  back(){
    this.imageName = undefined;
    if( this.asset === 'department'){
      this.selectedIndex = 1;
    }else if(this.asset === 'building'){
      this.selectedIndex = 0;
    }else if(this.asset === 'equipment'){
      this.selectedIndex = 2;
    }
  }

  onFileComplete(data: any) {
    console.log(data);
    this.loading = true;
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
  }

}
