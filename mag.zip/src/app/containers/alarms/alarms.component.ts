import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../globalStore';
import * as moment from 'moment';

@Component({
  selector: 'app-alarms',
  templateUrl: './alarms.component.html',
  styleUrls: ['./alarms.component.scss']
})
export class AlarmsComponent implements OnInit {

  
  public pageTitle: string;
  public plantName: string;
  public plantId: string;
  public dataSource: [];
  public defaultValue: object;
  public loadingBar:boolean;

  configuration = {
    filters: {
      column: true,
      sort: true,
      search: true,
      groupBy: true,
      filter : false
    },
    others: {
      dateFormat : ''
    },
    columnFilterConditions: [
      { value: 'contains', label: 'Contains', search: true }
    ],
    columns: [
      {
        column: 'Icon',
        visibility: true,
        groupBy: false,
        isAnchor: false,
        isIcon: true,
        sort: false,
        filter : false,
        isBtn: false,
        groupByState: false,
      },
      {
        column: 'Device_Name',
        visibility: true,
        groupBy: true,
        isAnchor: false,
        isIcon: false,
        sort: false,
        filter : true,
        isBtn: false,
        groupByState: false,
      },
      {
        column: 'Device_Type',
        visibility: true,
        groupBy: true,
        isAnchor: false,
        sort: true,
        filter : true,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'Status',
        visibility: true,
        groupBy: false,
        sort: true,
        filter : true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Equipment',
        visibility: true,
        groupBy: true,
        sort: true,
        isStatus: true,
        filter : true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Building',
        visibility: true,
        groupBy: true,
        sort: true,
        filter : true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Departments',
        visibility: true,
        groupBy: true,
        sort: true,
        filter : true,
        groupByState: true,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Created',
        visibility: true,
        groupBy: false,
        sort: true,
        filter : false,
        isDate: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      }
    ]
  };

  constructor(
    private route: ActivatedRoute,
    private store: Store<fromStore.ContainerState>
  ) {
     this.pageTitle = this.route.snapshot.data.title;
     this.plantId = this.route.snapshot.params.id;
  }

  getAlarms() {
    this.store.select<any>('alarms').subscribe(state => {
      this.loadingBar = state.loading;
      this.dataSource = state.data.AlarmsData;
    });
  }

  // Get the selected daterange picker value and call API.
  getSelectedvalue(range) {
    let fromDate = range.startDate;
    let toDate = range.endDate;
    this.store.dispatch(new fromStore.LoadAlarms(this.plantId, fromDate, toDate));
  }

  ngOnInit() {
    this.defaultValue = { startDate: moment().subtract(7, 'days'), endDate: moment(new Date()) };
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    this.store.select<any>('plant').subscribe(state => {
      this.plantName = state.data.PlantName;
    });
    this.getAlarms();
  }
}
