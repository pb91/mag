import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {LoginComponent} from './login.component';
import {AuthenticationService} from '@appServices/authentication.service';
import {store} from '@angular/core/src/render3';
import {Component, CUSTOM_ELEMENTS_SCHEMA, DebugElement} from '@angular/core';

describe('LoginComponent', () => {
  let component : LoginComponent;
  let service : AuthenticationService;
  let fixture : ComponentFixture < LoginComponent >;
  let fb : FormBuilder;
  let router : Router;
  let spy : any;
  let x : 'PrashanthYelavarthiPrabakararaju@eaton.com';
  let debugElement : DebugElement;
  let expected : any;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });


  // it('Login function', () => {
  //   component
  //     .loginForm
  //     .disable();
  //   component.remember = true;
  //   component.onLoginClick();

  //   expect(component.submitted).toBe(true);
  //   expect(component.error).toBe('');
  //   expect(service.login).toHaveBeenCalled();

  //   // expect(authservice.login).toEqual(' ');
  //   // expect(localStorage.getItem('Name')).toEqual('hi');
  //   // expect(localStorage.getItem('Name')).toBe('hi');
  //   expect(localStorage.getItem('RememberMe')).toBe('true');

  // });


  // spy = spyOn(service, 'login')
  //   .and
  //   .returnValue(expected);
  // it('canLogin returns false when the user is  authenticated', () => {
  //   // spy = spyOn(service, 'login').and.returnValue(false);

  //   component
  //     .loginForm
  //     .controls['username']
  //     .setValue(x);
  //   component
  //     .loginForm
  //     .controls['password']
  //     .setValue('Temppass@789');
  //   expect(component.onLoginClick()).toBeTruthy();
  //   expect(component.loginForm.valid).toBeTruthy();
  //   expect(service.login).toHaveBeenCalled();

  // });

  // it('canLogin returns false when the user is not authenticated', () => {
  //   // spy = spyOn(service, 'login').and.returnValue(true);

  //   component
  //     .loginForm
  //     .controls['username']
  //     .setValue('');
  //   component
  //     .loginForm
  //     .controls['password']
  //     .setValue('');
  //   expect(component.onLoginClick()).toBeFalsy();
  //   expect(component.loginForm.valid).toBeFalsy();
  //   expect(service.login).toHaveBeenCalled();
  // });
});
