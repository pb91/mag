import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '@appServices/authentication.service';
import { first } from 'rxjs/operators';
import { environment } from 'environments/environment';
const EMAIL_REGEX =  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

@Component({ selector: 'app-login', templateUrl: './login.component.html', styleUrls: ['./login.component.scss'] })
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  public errorMessage: string;
  public loading: boolean;
  public webapp : object = environment.webApp;
  public submitted: boolean;
  public Eula = environment.EULA; 
  public privacypolicy =  environment.privacyPolicy;
  constructor(private fb: FormBuilder, private router: Router, private authenticationService: AuthenticationService) {
    // redirect to home if already logged in
    if (this.authenticationService.currentUserValue) {
      this.router.navigate(['/dashboard']);
    }
  }

  ngOnInit() {
    this.loginForm = this.fb.group({
        email: ['', Validators.compose([Validators.required, Validators.pattern(EMAIL_REGEX)])],
        password: ['', Validators.compose([Validators.required])],
        remember: [true]
      });
  }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

  // On Click function for login
  onLoginClick() {
    if (this.loginForm.valid) {
      this.loading = true;
      this.errorMessage = "";
      this.authenticationService.login(this.loginForm.controls.email.value, this.loginForm.controls.password.value)
        .pipe(first())
        .subscribe(data => {
          this.loading = false;
          this.router.navigate(['/dashboard']);
        }, error => {
          this.loading = false;
          this.errorMessage = error.error.Message
        });
    }
  }
}