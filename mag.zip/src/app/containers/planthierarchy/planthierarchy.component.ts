import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromStore from '../../globalStore';
import { UtilityService  } from '../../shared/utility.service';
import {ActivatedRoute, Router} from '@angular/router';
import * as _ from 'lodash';
import { environment } from 'environments/environment';
import { MatDialog } from '@angular/material';
import {PlantService} from '@appServices/plant.service';
import { ToastComponent } from '@appComponents/toast/toast.component';
import * as moment from 'moment';
import { ExcelService } from '@appServices/excel.service';
import { Roles  } from '../../shared/roles';

@Component({
  selector: 'app-planthierarchy',
  templateUrl: './planthierarchy.component.html',
  styleUrls: ['./planthierarchy.component.scss']
})
export class PlanthierarchyComponent implements OnInit {

  // Declartion for plant Hierarchy
  public getSelectedTreeObj;
  public pageDetails: string = "plantHierarchy";
  public plantHierarchy:any;
  public treeData = {};
  public pageTitle : string;
  public plantId : string;
  public plantName : string;
  public plantHierarchySource : any;

  // Peak demand chart declaration.
  public deviceStautsChartTitle: string =  `Device Status`;
  public deviceStatusLoadingBar: boolean;
  public deviceStautsSeriesName: string = "";
  public deviceStatusSeriesData : object;
  public excelTemplatePath: string = environment.excelTemplatePath;

  public hierarchyData: any;
  public loadingBar: boolean;
  public displayOperations : boolean = false;
  configuration = {
    filters: {
      column: true,
      sort: true,
      search: true,
      groupBy: false,
      filter : false
    },
    others: {
      dateFormat : ''
    },
    columnFilterConditions: [
      { value: 'contains', label: 'Contains', search: true }
    ],
    columns: [
      {
        column: 'Device',
        visibility: true,
        groupBy: true,
        isAnchor: true,
        sort: true,
        filter : true,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'Building',
        visibility: false,
        minWidth : "92",
        groupBy: true,
        sort: true,
        filter : true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Department',
        visibility: false,
        groupBy: true,
        sort: true,
        isStatus: true,
        filter : true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Equipment',
        visibility: true,
        groupBy: true,
        isAnchor: false,
        sort: true,
        filter : true,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'Description',
        visibility: false,
        groupBy: true,
        sort: true,
        filter : true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Meter',
        visibility: true,
        groupBy: true,
        isAnchor: false,
        sort: true,
        filter : true,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'PXG',
        visibility: true,
        groupBy: true,
        sort: true,
        filter : true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'PXG900_IP',
        visibility: true,
        groupBy: true,
        isAnchor: false,
        sort: true,
        filter : false,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'Device_Type',
        visibility: true,
        groupBy: true,
        isAnchor: false,
        sort: true,
        filter : true,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'Serial_Number',
        visibility: false,
        groupBy: true,
        isAnchor: false,
        isStatus: true,
        sort: true,
        filter : true,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'Current_Status',
        visibility: true,
        groupBy: true,
        isAnchor: false,
        isStatus: true,
        sort: true,
        filter : true,
        isBtn: false,
        groupByState: true,
      },
      {
        column: 'Last_Reading',
        visibility: true,
        isDate: true,
        isAction: false,
        groupBy: false,
        groupByState: false,
        sort: false,
        BtnCSS: ''
      }
    ]
  };

  constructor(private excelService: ExcelService,
    private router: Router,
    public dialog: MatDialog, private store: Store<fromStore.ContainerState>,
    private plantService : PlantService,
    public notificationMsg: ToastComponent,
    private utils: UtilityService, private route : ActivatedRoute) {
      this.pageTitle = this.route.snapshot.data.title
      this.plantId = this.route.snapshot.params.id;
     }

  treeStructureEvent(event) {
    var finalResults = [];
    this.utils.findObjects(this.plantHierarchy, 'id', event.id, finalResults);
    this.getSelectedTreeObj = _.size(finalResults[0]) > 0 ? finalResults[0] : event;
    return event;
  }

  convertTreeToTable(plantHierarchy) {
    let self = this;
    let tempDevice = [];
    plantHierarchy = _.sortBy(plantHierarchy, [function (o) { return o.IIOT_End_Point_Device; }]);
    plantHierarchy.forEach(element => {
      if (element) {
        tempDevice.push({
          Device: _.hasIn(element, "IIOT_End_Point_Device") ? element.IIOT_End_Point_Device : "",
          Building: _.hasIn(element, "Building") ? element.Building : "",
          Department: _.hasIn(element, "Department") ? element.Department : "",
          Equipment: _.hasIn(element, "Equipment") ? element.Equipment : "",
          Description: _.hasIn(element, "Description") ? element.Description : "",
          Meter: _.hasIn(element, "Meter") ? element.Meter : "",
          PXG: _.hasIn(element, "PXG") ? element.PXG : "",
          PXG900_IP:  _.hasIn(element, "PXG900_IP_Address") ? element.PXG900_IP_Address : "", 
          Device_Type:  _.hasIn(element, "Device_Type") ? element.Device_Type : "", 
          Current_Status:  _.hasIn(element, "Current_Status") ? element.Current_Status : "", 
          id:  _.hasIn(element, "id") ? element.id : "",
          plantId:  _.hasIn(element, "PlantID") ? element.PlantID : "",
          Serial_Number :  _.hasIn(element, "serial") ? element.serial : "",
          Last_Reading :  _.hasIn(element, "lastTimeStamp") ? moment(element.lastTimeStamp).valueOf() : "", 
        });
      }
    });
    return tempDevice;
  }

  convertDeviceTreeToTable(plantHierarchy) {
    let self = this;
    let tempDevice = [];
    plantHierarchy.forEach(element => {
      if (element) {
        tempDevice.push({
          Device: _.hasIn(element, "name") ? element.name : "",
          id:  _.hasIn(element, "id") ? element.id : "",
          Last_Reading :  _.hasIn(element, "_ts") ? moment(element._ts).valueOf() : "", 
        });
      }
    });
    return tempDevice;
  }

  exportAsXLSX():void {
    this.excelService.exportAsExcelFile(this.plantHierarchy, 'Site Hierarchy');
  }

  createDevice(){
    this.router.navigate(['planthierarachy', 'create', this.plantId]);
  }

  anchorPressed(event) {
    this.router.navigate(['planthierarachy' , "view" , event.data.id , this.plantId]);
  }

  fileUpload(evt){
    var fileInput = document.getElementById('file');
    var filePath = fileInput['value'];
    var allowedExtensions = /(\.xlsx)$/i;
    if(!allowedExtensions.exec(filePath)){
        this.notificationMsg.showWarning("Please upload file having extensions .xlsx");
        return false;
    } else {
      this.loadingBar = true;
      const formData = evt.target.files[0]; // FileList object
      this.plantService.getUploadPlantHierarchy(this.plantId, formData).subscribe(data => {
        this.notificationMsg.showSucess("File Upload Successfully");
        this.getPlantDetails();
        this.loadingBar = false;
      }, error => {
        this.loadingBar = false;
      });
    }
  }

  converttoTreeFormat(plantHierarchy) {
    // Create a format for tree structure
    let finalArray = {
      Buildings: {},
      Departments: {},
      Equipments: {}
    };

    let finalArray1 = [];
    finalArray1.push(plantHierarchy);
    for (var key in plantHierarchy) {
      if(key== "Buildings" && plantHierarchy[key] instanceof Array) {
        finalArray['Buildings'] = this.utils.toMap(plantHierarchy[key],'BuildingName', 'BuildingID');
      }
      if(key== "Departments" && plantHierarchy[key] instanceof Array) {
        finalArray['Departments'] = this.utils.toMap(plantHierarchy[key],'DepartmentName', 'DepartmentID');
      }
      if(key== "Equipments" && plantHierarchy[key] instanceof Array) {
        finalArray['Equipments'] = this.utils.toMap(plantHierarchy[key],'Equipment', 'id');
      }
    }
   this.treeData = finalArray;
  }

  onSync() {
  this.store.select<any>('device').subscribe(state => {
     let deviceConnected =  state.deviceList['data'] instanceof Array ? state.deviceList['data'] : [];
      // let deviceConnected = [{"Device":"TestDevice21","Building":null,"Department":null,"Equipment":null,"Description":null,"Meter":null,"PXG":null,"PXG900_IP":null,"Device_Type":null,"Current_Status":"Not Communicating","id":"55a3e6dc-21f3-351d-4ffa-78992092fed7","plantId":"a957a232-b672-4ce4-95d0-f9d447ae8f6f","Serial_Number":null,"Last_Reading":null},{"Device":"Test123","Building":null,"Department":null,"Equipment":null,"Description":null,"Meter":null,"PXG":null,"PXG900_IP":null,"Device_Type":null,"Current_Status":"Not Communicating","id":"1d9903c4-ee47-4806-8ceb-8082f8463f09","plantId":"a957a232-b672-4ce4-95d0-f9d447ae8f6f","Serial_Number":null,"Last_Reading":null},{"Device":"RAN","Building":null,"Department":null,"Equipment":null,"Description":null,"Meter":null,"PXG":null,"PXG900_IP":null,"Device_Type":null,"Current_Status":"Not Communicating","id":"e7fd0ea4-9649-4ab6-9c47-3796cfd96a52","plantId":"a957a232-b672-4ce4-95d0-f9d447ae8f6f","Serial_Number":null,"Last_Reading":null},{"Device":"RAN","Building":null,"Department":null,"Equipment":null,"Description":null,"Meter":null,"PXG":null,"PXG900_IP":null,"Device_Type":null,"Current_Status":"Not Communicating","id":"e7fd0ea4-9649-4ab6-9c47-3796cfd96a51","plantId":"a957a232-b672-4ce4-95d0-f9d447ae8f6f","Serial_Number":null,"Last_Reading":null},{"Device":"TestDevice21","Building":null,"Department":null,"Equipment":null,"Description":null,"Meter":null,"PXG":null,"PXG900_IP":null,"Device_Type":null,"Current_Status":"Not Communicating","id":"4fcd349a-284a-5616-9af6-9e899a404909","plantId":"a957a232-b672-4ce4-95d0-f9d447ae8f6f","Serial_Number":null,"Last_Reading":null},{"Device":"TEST Devoce","Building":"Build-1","Department":"Depart-1","Equipment":null,"Description":null,"Meter":null,"PXG":null,"PXG900_IP":null,"Device_Type":null,"Current_Status":"Not Communicating","id":"d6b6e703-07cf-4f32-a36b-a151158694c4","plantId":"a957a232-b672-4ce4-95d0-f9d447ae8f6f","Serial_Number":"8951663132","Last_Reading":null}];
      this.plantHierarchy = this.convertTreeToTable(deviceConnected);
     // this.plantHierarchy = _.concat(this.plantHierarchySource, connectedDevice);
      this.loadingBar = state.deviceList.loading;
  });
}

getPlantDetails(){
    this.plantHierarchy = [];
    this.store.select<any>('plant').subscribe(state => {
      // this.plantHierarchy = state.data;
      let plantHierarchy =  state.data['Devices'] instanceof Array ? state.data['Devices'] : [];
      this.plantName = state.data.PlantName;
      this.loadingBar = state.loading;
      this.plantHierarchy = this.plantHierarchySource = this.convertTreeToTable(plantHierarchy);
       if(this.utils.validateURL(Roles.siteHierarchy.view)){
        this.displayOperations = true;
       }
    });
}

reloadDevice() {
    if(this.plantId == "7b5a783d-61d7-46b4-ae07-2371ff1a45c3") {
      this.notificationMsg.showWarning("Default site can't be sync");
    } else {
      this.store.dispatch(new fromStore.LoadDeviceList(this.plantId));
      this.onSync();
    }
}



  ngOnInit() {
    this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.store.dispatch(new fromStore.ResetDeviceDetails());
    this.getPlantDetails();
  }
}