import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanthierarchyComponent } from './planthierarchy.component';

describe('PlanthierarchyComponent', () => {
  let component: PlanthierarchyComponent;
  let fixture: ComponentFixture<PlanthierarchyComponent>;
  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });

});
