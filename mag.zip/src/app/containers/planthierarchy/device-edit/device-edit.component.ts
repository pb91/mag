import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { DeviceService } from '@appServices/device.service';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { UtilityService } from '../../../shared/utility.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Roles  } from '../../../shared/roles';
import { DialogboxComponent } from '@appComponents/dialogbox/dialogbox.component';
import { MatDialog } from '@angular/material';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';
import * as moment from 'moment';
// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../../globalStore';

@Component({
  selector: 'app-device-edit',
  templateUrl: './device-edit.component.html',
  styleUrls: ['./device-edit.component.scss']
})
export class DeviceEditComponent implements OnInit {
  pageTitle: string = "Device Details";
  titleAlert: string = 'This field is mandatory';
  formTitle: string;
  formHeader:string;
  formGroup: FormGroup;
  subscription: Subscription;
  loadingFlag: boolean;
  deviceId: string;
  pageDetails: string;
  connnectionString: string;
  editFlag: boolean = false;
  appearance: string;
  viewFlag: boolean = false;
  configuration : any;
  deviceDetails : any;
  sites: [];
  deviceData: any;
  disableSaveButton : boolean = false;
  departmentData: [];
  buildingData: [];
  modelData: any;
  serialPlaceHolder: string = "Select Model";
  guIDPlaceHolder: string = "";
  plantId: string;
  plantName: string;
  deviceName: string;
  deleteOptionEnable : any;
  deleteOptionFlag:Boolean = false;

  constructor(private deviceService: DeviceService,
    public notificationMsg: ToastComponent,
    public dialog: MatDialog, 
    private utils: UtilityService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private store: Store<fromStore.ContainerState>) {
    this.pageDetails = this.route.snapshot.params.operation;
    this.deviceId = this.route.snapshot.params.deviceId;
    this.plantId = this.route.snapshot.params.plantId;

    // Below array is to display dropdown.
    this.modelData = [
    { id : "PXM3000",  name : "PXM3000" },
    { id : "PXG900",  name : "PXG900" },
    { id : "PXG950-4G",  name : "PXG950-4G" },
    { id : "PXDBP",  name : "PXDBP" },
    { id : "PXDBL",  name : "PXDBL" }];

    // Delete option provided only for below PXG
    this.deleteOptionEnable = ["PXIG", "PXG900"];
    // Once save submit disable the flag.
    this.disableSaveButton = false;
    if (this.pageDetails === "view") {
      this.loadingFlag = true;
      this.configuration = {
        filters: {
          column: true,
          sort: true,
          search: true,
          groupBy: true,
          filter: true
        },
        others: {
          dateFormat: ''
        },
        columnFilterConditions: [
          { value: 'contains', label: 'Contains', search: true }
        ],
        columns: [
          {
            column: 'tag',
            visibility: true,
            groupBy: true,
            sort: true,
            filter: true,
            groupByState: true,
            isBtn: false,
            BtnCSS: ''
          },
          {
            column: 'name',
            visibility: true,
            groupBy: true,
            sort: true,
            filter: true,
            groupByState: false,
            isBtn: false,
            BtnCSS: ''
          },
          {
            column: 'value',
            visibility: true,
            groupBy: true,
            sort: true,
            filter: true,
            groupByState: true,
            isBtn: false,
            BtnCSS: ''
          },
          {
            column: 'unit',
            visibility: true,
            groupBy: true,
            sort: true,
            filter: true,
            groupByState: false,
            isBtn: false,
            BtnCSS: ''
          },
          {
            column: 'time',
            visibility: true,
            isDate: true,
            isAction: false,
            groupBy: false,
            groupByState: false,
            sort: false,
            BtnCSS: ''
          }
        ]
      };
      this.formTitle = "Last Reading Device Details";
      this.store.dispatch(new fromStore.LoadDeviceDetails(this.deviceId, this.plantId));
      this.viewFlag = true;
    } else if (this.pageDetails == "create") {
     this.getPlantDetails();
     this.createForm();
     this.viewFlag = false;
     this.formHeader = "Add a New Device";
    }

    // To Get the last reading details for the specific device.
    this.subscription = this.store.select<any>('device').subscribe(state => {
      if (this.pageDetails.trim() === "view") {
        this.loadingFlag = state.deviceDetails.loading;
        let deviceData = state.deviceDetails.data['deviceData'];
        let hierarchicalDeviceData = state.deviceDetails.data['hierarchicaldevicedata'];
        this.deviceName = _.hasIn(deviceData, "name") ? deviceData['name'] : "";

        let deviceDataJson = {};
        if(_.size(deviceData) > 0) {
          deviceDataJson = { "Name": this.deviceName,
          "Vendor": deviceData.vendor ? deviceData['vendor'] : "",
          "Family": deviceData.family ? deviceData['family'] : "",
          "Cloud Enabled": deviceData.cloud_enabled ? "True" : "False",
          "Device Id": deviceData.id ? deviceData['id'] : ""
        }; 
      }

        let hierarchyData = {}
        if(_.size(hierarchicalDeviceData) > 0) {
        hierarchyData = {
          "MAC": hierarchicalDeviceData.mac ? hierarchicalDeviceData['mac_address'] : "",
          "Serial": hierarchicalDeviceData.serial ? hierarchicalDeviceData['serial'] : "",
          "Model": hierarchicalDeviceData.model ? hierarchicalDeviceData['model'] : "",
          "Meter" : hierarchicalDeviceData.Meter ? hierarchicalDeviceData['Meter'] : "",
          "Building": hierarchicalDeviceData.Building ? hierarchicalDeviceData['Building'] : "",
          "Department": hierarchicalDeviceData.Department ? hierarchicalDeviceData['Department'] : "",
          "Equipment": hierarchicalDeviceData.Equipment ? hierarchicalDeviceData['Equipment'] : "",
          "PXG900IP Address": hierarchicalDeviceData.PXG900_IP_Address ? hierarchicalDeviceData['PXG900_IP_Address'] : "",
          "Device Type": hierarchicalDeviceData.Device_Type ? hierarchicalDeviceData['Device_Type'] : "",
          "PXG": hierarchicalDeviceData.PXG ? hierarchicalDeviceData['PXG'] : "",
          "IOT Hub String" : hierarchicalDeviceData.IOTHubString ? hierarchicalDeviceData['IOTHubString'] : "",
        };
      }
        if(_.size(deviceDataJson) > 0 || _.size(hierarchyData) > 0 ) {
        this.deviceData = _.merge(deviceDataJson, hierarchyData);

        if(this.utils.validateURL(Roles.DeviceList.addupdate)) {
        this.deleteOptionFlag = this.deleteFlagEnableCheck(this.deviceData);
        }
        
        } else {
          this.deviceData = [];
        }
        let tempDevice = [];
        state.deviceDetails.data['latestData'] && state.deviceDetails.data['latestData'].forEach(element => {
          if (element) {
            tempDevice.push({
              tag: _.hasIn(element, "tag") ? element.tag : "",
              name: _.hasIn(element, "name") ? element.name : "",
              value: _.hasIn(element, "value") ? element.value : "",
              unit: _.hasIn(element, "unit") ? element.unit : "",
              time: _.hasIn(element, "time") ?  (element.time != 'null' && element.time != "" && element.time != null) ?  moment.unix(element.time) : "" :  ""
            });
          }
        });
        if(_.size(tempDevice) > 0 ) {
          this.deviceDetails = tempDevice;
        }

      }
    });
  }

  // To get the plant details for department & building dropdown.
  getPlantDetails() {
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.store.select<any>('plant').subscribe(state => {
      this.loadingFlag = state.loading;
      this.departmentData = (state.data.Departments == null || _.size(state.data.Departments) == 0) ? [] : state.data.Departments;
      this.buildingData = (state.data.Buildings == null || _.size(state.data.Buildings) == 0) ? [] : state.data.Buildings;

    });
  }

  // View screen, Checking condition to enable/disable the delete option
  deleteFlagEnableCheck(deviceDataJson: object) {
    if(_.indexOf(this.deleteOptionEnable, deviceDataJson['Model']) !== -1 || _.indexOf(this.deleteOptionEnable, deviceDataJson['Device Type']) !== -1) {
      return true;
    } 
    return false;
  }

  // On changing the model value in dropdown, change the placeholder in GUID & SERIAL field.
  onModelChange(event:object) {
      this.displayHint(event['value']);
  }

  displayHint(modelSelection: string) {
    if(modelSelection === "PXG900" || modelSelection === "PXG950-4G") {
      this.serialPlaceHolder = "Device WebUI > Edit > [PXG Device] > Choose an Action > Serial Number || Device Physical Label > MAC Address 1";
    } else if(modelSelection === "PXDBP" || modelSelection === "PXDBL") {
      this.serialPlaceHolder = "Device WebUI > Settings > Network > MAC Address || Device Physical Label > MAC Address 1";
    } else if(modelSelection === "PXM3000") {
      this.serialPlaceHolder = "Device WebUI > Settings > General > System > Hardware > System Hardware > Power Xpert Meter 3000 Gateway Card Information > Serial Number || Device Physical Label > Serial Number";
    }

    // To Generate GUID
    if(modelSelection === "PXG900" || modelSelection === "PXG950-4G" || modelSelection === "PXDBP" || modelSelection === "PXDBL") {
      this.guIDPlaceHolder = "Device WebUI > Settings > Network Access > Connect to Eaton Hosted Service > Device GUID";
    } else if (modelSelection === "PXM3000") {
      this.guIDPlaceHolder = "Device WebUI > Settings > Comms > Connect to EATON’s Hosted Service > Device GUID";
    }
  }

  createForm() {
 //  console.log("create form");
    this.formGroup = this.formBuilder.group({
      'name' :  [null, Validators.required],
      'model' :  [null, Validators.required],
      'building' :  [""],
      'department' :  [""],
      'serialnumber' :  [null, Validators.required],
      'guid' :  [null, Validators.required],
    });
  }

  editDevice() {
    this.router.navigate(['deviceupdate', this.deviceId, this.plantId]);
  }

  deletePlantById(plantId:string, deviceId:string){
    this.loadingFlag = true;
    this.deviceService.deleteDeviceById(plantId, deviceId).subscribe(data => {
      this.notificationMsg.showSucess(this.utils.displayMessage("Device","delete"));
      this.back();
    }, error => {
      this.loadingFlag = false;
    });
  }

  deleteDevice() {
    const dialogRef = this.dialog.open(DialogboxComponent, {
      width: '300px',
      height: '120px',
      data: `Do you confirm the deletion ${this.deviceName}?`
    });

    dialogRef.afterClosed().subscribe(result => {
      if(this.plantId === "7b5a783d-61d7-46b4-ae07-2371ff1a45c3") {
        this.notificationMsg.showWarning("Default Site Can't Be Deleted");
      } else {
        if(result) {
          this.deletePlantById(this.plantId, this.deviceId);
        }
      }
    });
  }

  back() {
    this.router.navigate(['planthierarachy', this.plantId]);
  }

  updateFormData() {
    this.formGroup.controls['name'].setValue(this.deviceData['Name']);
     this.formGroup.controls['model'].setValue(this.deviceData['PXG']);
    this.formGroup.controls['building'].setValue(this.deviceData['Building']);
    this.formGroup.controls['department'].setValue(this.deviceData['Department']);
    this.formGroup.controls['serialnumber'].setValue(this.deviceData['Serial']);
    this.formGroup.controls['guid'].setValue(this.deviceData['Device Id']);
  }

  // Default set value for Model and update the place holder.
  ngAfterContentInit() {
    if(this.pageDetails == 'create') {
      this.formGroup.controls['model'].setValue("PXG900");
      this.displayHint("PXG900");
    }
  }

  ngOnInit() {
    if(this.plantId) {
      this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
      this.store.dispatch(new fromStore.LoadPlant(this.plantId));
      this.store.select<any>('plant').subscribe(state => {
        this.plantName = state.data.PlantName;
      });
    } else {
      this.store.dispatch(new fromStore.ResetPreference());
    }
  }

  onSuccessCreateEdit() {
    this.loadingFlag = false;
    this.disableSaveButton = false;
    this.router.navigate(['planthierarachy', this.plantId]);
  }

  createUpdatePlant(plantObject: object, plantId: string) {
    this.loadingFlag = true
      this.deviceService.createUpdateDevice(plantObject, plantId).subscribe(data => {
        this.disableSaveButton = true;
        this.connnectionString = _.hasIn(data,"connectionstring") ? data['connectionstring'] : '';
        this.notificationMsg.showSucess(this.utils.displayMessage("Device", "create"));
       // this.onSuccessCreateEdit();
        this.loadingFlag = false;
      }, error => {
        this.loadingFlag = false;
      });

  }

  onSubmit(postObject: object) {
   this.createUpdatePlant(postObject, this.plantId);
  }
}