import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceUpdateComponent } from './device-update.component';

describe('DeviceUpdateComponent', () => {
  let component: DeviceUpdateComponent;
  let fixture: ComponentFixture<DeviceUpdateComponent>;

  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });

});
