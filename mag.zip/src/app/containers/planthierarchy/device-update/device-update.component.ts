import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DeviceService } from '@appServices/device.service';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { UtilityService } from '../../../shared/utility.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';
// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../../globalStore';

@Component({
  selector: 'app-device-update',
  templateUrl: './device-update.component.html',
  styleUrls: ['./device-update.component.scss']
})
export class DeviceUpdateComponent implements OnInit {
  pageTitle: string = "Device Details";
  titleAlert: string = 'This field is mandatory';
  formTitle: string;
  formGroup: FormGroup;
  subscription: Subscription;
  loadingFlag: boolean;
  deviceId: string;
  deviceDetails : [];
  deviceData: any;
  departmentData: [];
  buildingData: [];
  modelData: any;
  plantId: string;
  plantName: string;
  deviceName: string;
  deleteOptionFlag:Boolean = false;
  editObject: any;

  constructor(private deviceService: DeviceService,
    public notificationMsg: ToastComponent,
    private utils: UtilityService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private store: Store<fromStore.ContainerState>, ) {
    this.deviceId = this.route.snapshot.params.deviceId;
    this.plantId = this.route.snapshot.params.plantId;

    // To view data in from setting pre-defined value as null.
    this.editObject = {
      "model": "",
      "serialnumber": "",
      "guid": ""
    };
    this.store.dispatch(new fromStore.LoadDeviceDetails(this.deviceId, this.plantId));
    
    this.getPlantDetails();
    this.createFormEdit();
  }

  getLastReadingDetails() {
        // To Get the last reading details for the specific device.
        this.subscription = this.store.select<any>('device').subscribe(state => {
          this.loadingFlag = state.deviceDetails.loading;
          let deviceData = state.deviceDetails.data['deviceData'];
          this.deviceDetails = state.deviceDetails.data['latestData'];
          let hierarchicalDeviceData = state.deviceDetails.data['hierarchicaldevicedata'];
          let deviceDataJson = {};
          this.deviceName = _.hasIn(deviceData, "name") ? deviceData['name'] : "";
          if(_.size(deviceData) > 0) {
            deviceDataJson = { "Name": this.deviceName,
            "Vendor": deviceData.vendor ? deviceData['vendor'] : "",
            "Family": deviceData.family ? deviceData['family'] : "",
            "Cloud Enabled": deviceData.cloud_enabled ? "True" : "False",
            "Device Id": deviceData.id ? deviceData['id'] : ""
          }; 
        }
  
          let hierarchyData = {}
          if(_.size(hierarchicalDeviceData) > 0) {
          hierarchyData = {
            "MAC": hierarchicalDeviceData.mac ? hierarchicalDeviceData['mac_address'] : "",
            "Serial": hierarchicalDeviceData.serial ? hierarchicalDeviceData['serial'] : "",
            "Model": hierarchicalDeviceData.model ? hierarchicalDeviceData['model'] : "",
            "Meter" : hierarchicalDeviceData.Meter ? hierarchicalDeviceData['Meter'] : "",
            "Building": hierarchicalDeviceData.Building ? hierarchicalDeviceData['Building'] : "",
            "Department": hierarchicalDeviceData.Department ? hierarchicalDeviceData['Department'] : "",
            "Equipment": hierarchicalDeviceData.Equipment ? hierarchicalDeviceData['Equipment'] : "",
            "PXG900IP Address": hierarchicalDeviceData.PXG900_IP_Address ? hierarchicalDeviceData['PXG900_IP_Address'] : "",
            "Device Type": hierarchicalDeviceData.Device_Type ? hierarchicalDeviceData['Device_Type'] : "",
            "PXG": hierarchicalDeviceData.PXG ? hierarchicalDeviceData['PXG'] : "",
            "IOT Hub String" : hierarchicalDeviceData.IOTHubString ? hierarchicalDeviceData['IOTHubString'] : "",
          };
        }
  
        if (_.size(deviceDataJson) > 0 || _.size(hierarchyData) > 0) {
          this.deviceData = _.merge(deviceDataJson, hierarchyData);
          this.editObject = { 
            "model": this.deviceData['Model'] ? this.deviceData['Model'] : "",
            "serialnumber": this.deviceData['Serial'] ? this.deviceData['Serial'] : "",
            "guid": this.deviceData['Device Id'] ? this.deviceData['Device Id'] : ""
          }
          this.updateFormData();
        } else {
          this.deviceData = [];
        }
        
        
  
      });
  }


  // To get building & department dropdown.
  getPlantDetails() {
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.store.select<any>('plant').subscribe(state => {
      this.loadingFlag = state.loading;
      this.departmentData = (state.data.Departments == null || _.size(state.data.Departments) == 0) ? [] : state.data.Departments;
      this.buildingData = (state.data.Buildings == null || _.size(state.data.Buildings) == 0) ? [] : state.data.Buildings;
      state.loaded && this.getLastReadingDetails();
    });
  }

  createFormEdit() {
    this.formGroup = this.formBuilder.group({
      'name' :  [null, Validators.required],
      'building' :  [null],
      'department' :  [null]
    });
  }

  back() {
    this.router.navigate(['planthierarachy', this.plantId]);
  }

  updateFormData() {
    this.formGroup.controls['name'].setValue(this.deviceData['Name']);
    this.formGroup.controls['building'].setValue(this.deviceData['Building']);
    this.formGroup.controls['department'].setValue(this.deviceData['Department']);
}

  ngOnInit() {
    if(this.plantId) {
      this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
      this.store.dispatch(new fromStore.LoadPlant(this.plantId));
      this.store.select<any>('plant').subscribe(state => {
        this.plantName = state.data.PlantName;
      });
    } else {
      this.store.dispatch(new fromStore.ResetPreference());
    }
  }

  onSuccessCreateEdit() {
    this.loadingFlag = false;
    this.router.navigate(['planthierarachy', this.plantId]);
  }

  createUpdatePlant(plantObject: object, plantId: string) {
    this.loadingFlag = true 
      let requestPayload = {
        name: plantObject['name'], 
        building: plantObject['building'],
        department: plantObject['department'],
        guid: this.deviceData['Device Id'],
        model: this.deviceData['Model'],
        serialnumber:  this.deviceData['Serial']
      };

      this.deviceService.updateDevice(requestPayload, plantId).subscribe(data => {
        this.notificationMsg.showSucess(this.utils.displayMessage("Device", "edit"));
        this.onSuccessCreateEdit();
      }, error => {
        this.loadingFlag = false;
      });
  }

  onSubmit(postObject: object) {
   this.createUpdatePlant(postObject, this.plantId);
  }
}
