import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {FormBuilder, FormGroup, Validators, AbstractControl} from '@angular/forms';
import { first } from 'rxjs/operators';

import { AuthenticationService } from '@appServices/authentication.service';
import { ToastComponent } from '@appComponents/toast/toast.component';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.scss']
})
export class ChangepasswordComponent implements OnInit {
  public pageTitle: string;
  formGroup:FormGroup;
  loadingFlag: boolean = false;
  titleAlert: string = 'This field is mandatory';
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public notificationMsg: ToastComponent,
    private authenticationService: AuthenticationService) {
    this.pageTitle = this.route.snapshot.data.title;
   }

   ngOnInit() {
    this.formGroup = this.formBuilder.group({
      oldpassword : ["", Validators.required],
      password: ['', Validators.compose([Validators.required, , this.checkPassword])],
      confirmPassword: ['', Validators.compose([Validators.required])]
  });

    this.formGroup.validator = this.matchingPasswords;
}


matchingPasswords(AC: AbstractControl) {
  if (AC.get('password') && AC.get('confirmPassword')) {
    const password = AC.get('password').value;
    const confirmPassword = AC.get('confirmPassword').value;
    if (password !== confirmPassword) {
      AC.get('confirmPassword').setErrors({matchingPasswords: true});
    } else {
      return null;
    }
  }
}

checkPassword(control) {
  let enteredPassword = control.value
  let passwordCheck = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/;
  return (!passwordCheck.test(enteredPassword) && enteredPassword) ? { 'requirements': true } : null;
}


getErrorPassword() {
  return this.formGroup.get('password').hasError('required') ? 'Field is required (at least eight characters, one uppercase letter, one lowercase letter and one number)' :
    this.formGroup.get('password').hasError('requirements') ? 'Password needs to be at least eight characters, one lowercase letter uppercase letter and one number' : '';
}

onLogoutClick() {      
  this.authenticationService.logout().subscribe(state => {
    this.loadingFlag = false;
    this.router.navigateByUrl('sign-in');
  }, error => {
    this.loadingFlag = false;
  });   
}


onSubmit(post:any) {
  if(this.formGroup.valid){
    this.loadingFlag = true;
    let object = { "current_password": post['oldpassword'], "new_password": post['password'] }
    this.authenticationService.changePassword(object)
    .pipe(first())
    .subscribe(data => {
    // Once user changed password, New token need to call so calling login again with new password.  
    this.onLogoutClick();
    this.notificationMsg.showSucess("Password Changed Successfully");
    }, error => {
    this.loadingFlag = false;
    });
  }
}
}
