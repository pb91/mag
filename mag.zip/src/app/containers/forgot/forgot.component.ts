import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup, Validators, AbstractControl} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';

// Service 
import { AuthenticationService } from '@appServices/authentication.service';

// Component
import { ToastComponent } from '@appComponents/toast/toast.component';
import { BooleanLiteral } from '@babel/types';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent implements OnInit {
  emailForm:FormGroup;
  verifyForm:FormGroup;
  passwordForm:FormGroup;
  loading: boolean = false;
  errorMessage: string;
  emailId: string;
  resetFlag: boolean;
  verifyaccount:boolean = false;
  titleAlert: string = 'This field is mandatory';
  passwordScreen: boolean = false;
  pageTitle: any;
  verifyCodeScreen: boolean = false;
  constructor(private fb:FormBuilder, 
    private route: ActivatedRoute,
    public notificationMsg: ToastComponent,
    private authenticationService: AuthenticationService,
     private router:Router) { 
      this.pageTitle = this.route.snapshot.data;

      if(this.pageTitle.flag == "verifyaccount") {
        // For site/user creating user have to give code set his personal infomation. So, Adding this boolean.
        this.verifyaccount = true;
        this.emailId = this.route.snapshot.params.emailId;
        this.initVerificationCode();
      } else {
      // If reset flag is true then, forgot password screen.
      this.resetFlag = (this.pageTitle.flag ===  "reset") ? true : false;
      }

      if (this.authenticationService.currentUserValue) {
        this.router.navigate(['/dashboard']);
      }
  }

  ngOnInit() {
    this.emailForm = this.fb.group({
      email: ['', Validators.compose([Validators.required, Validators.email])]
    });
  }

  forgotPassword() {
    this.authenticationService.resetPassword(this.emailForm.controls.email.value)
      .pipe(first())
      .subscribe(data => {
        this.loading = false;
        this.notificationMsg.showSucess("Password Reset Email Sent Successfully");
      }, error => {
        this.loading = false;
        this.errorMessage = error.error.message
      });
  }

  checkPassword(control) {
    let enteredPassword = control.value
    let passwordCheck = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/;
    return (!passwordCheck.test(enteredPassword) && enteredPassword) ? { 'requirements': true } : null;
  }

  getErrorPassword() {
    return this.passwordForm.get('password').hasError('required') ? 'Password needs to be at least eight characters. Password should contain Uppercase character, Lowercase character, Number (0-9) or Special characters.' :
      this.passwordForm.get('password').hasError('requirements') ? 'Password needs to be at least eight characters, one lowercase letter uppercase letter and one number' : '';
  }

  matchingPasswords(AC: AbstractControl) {
    if (AC.get('password') && AC.get('confirmPassword')) {
      const password = AC.get('password').value;
      const confirmPassword = AC.get('confirmPassword').value;
      if (password !== confirmPassword) {
        AC.get('confirmPassword').setErrors({matchingPasswords: true});
      } else {
        return null;
      }
    }
  }

   // Block Start is for password screen
  initpasswordScreen() {
    this.passwordScreen = true;
    this.verifyaccount = false;
    this.verifyCodeScreen = false;
    this.passwordForm = this.fb.group({
      first_name: [null],
      display_name: [null, Validators.required],
      last_name: [null],
      company_name: [null],
      company_address: [null],
      job_title: [null],
      department: [null],
      phone_number: [null],
      password: ['', Validators.compose([Validators.required, , this.checkPassword])],
      confirmPassword: ['', Validators.compose([Validators.required])]
    });

    this.passwordForm.validator = this.matchingPasswords;
  }

  createPassword() {
    if(this.passwordForm.valid){
      this.loading = true;
      let formData = this.passwordForm.value;
      formData.email_id = this.emailForm.controls.email.value || this.emailId;
      this.authenticationService.setPassword(formData)
      .pipe(first())
      .subscribe(data => {
       this.loading = false;
       this.backtologin();
        this.notificationMsg.showSucess("Account registration done Successfully");
      }, error => {
        this.loading = false;
        this.errorMessage = error.error.message
      });
    }
  }
  // Block End is for password screen

  // Block Start is for verification screen
  backtoRegisterScreen() {
    this.verifyCodeScreen = false;
    this.passwordScreen = false;
  }

  initVerificationCode() {
    this.verifyCodeScreen = true;
    this.verifyForm = this.fb.group({
        verificationcode : ["", Validators.required]
    });
  
  }

  submitVerifyCode() {
    if(this.verifyForm.valid){
      this.loading = true;
      let emailId = this.emailForm.controls.email.value || this.emailId;
      this.authenticationService.registerVerifyCode(this.verifyForm.controls.verificationcode.value, emailId)
      .subscribe(data => {
        if(data['status'] ===  201) {
          this.loading = false;
          this.initpasswordScreen();
          this.notificationMsg.showSucess("Verified Email Address Successfully");
        } else {
          this.loading = false;
          this.notificationMsg.showWarning("User already registered");
        }
      }, error => {
        this.loading = false;
        this.errorMessage = error.error.message
      });
    }
  }
// Block End is for verification screen

  // Block for register a new user
  registerUser() {    
    this.authenticationService.registerUser(this.emailForm.controls.email.value)
      .pipe(first())
      .subscribe(data => {
        this.loading = false;
        this.initVerificationCode();
        this.notificationMsg.showSucess("User Register Email Sent Successfully");
      }, error => {
        this.loading = false;
        //  this.errorMessage = error.error.message
      });
  }

  sendResetEmail(){
    this.errorMessage = "";
    if(this.emailForm.valid){
      this.loading = true;
      if(this.resetFlag) {
        this.forgotPassword();
      } else {
        this.registerUser();
      }
    }
  }

  backtologin(){
    this.router.navigate(['/sign-in']);
  }



}