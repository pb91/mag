import {Component, OnInit} from '@angular/core';
import {PlantService} from '@appServices/plant.service';
import {ActivatedRoute} from '@angular/router';
import { Observable } from 'rxjs';

import { UtilityService  } from '../../shared/utility.service';

import * as _ from 'lodash';
import * as moment from 'moment';

import { Store } from '@ngrx/store';
import * as fromStore from '../../globalStore';


@Component({selector: 'app-plantsummary', 
templateUrl: './plantsummary.component.html', 
styleUrls: ['./plantsummary.component.scss']})

export class PlantsummaryComponent implements OnInit {

  // TODO: need to declart in constant file.
  units: string = 'kWh';
  public observable: Observable<any>;

  // Declartion for plant Hierarchy
  public departmentData = [];
  public buildingsData = [];

  // Route Param Declartion   
  public plantId : string;
  public pageTitle : string;
  public plantName : string;

  // Declartion for from and to date
  public fromDate;
  public toDate;
  public selectedId;
  public defaultValue: object;
//  public loadedFlag : boolean = false;

 // Declartion for plant Hierarchy
 public getSelectedTreeObj;
 public plantHierarchy;
 public treeData = {};

  // Declaration for device status pie chart
  public costAndConspTitle: string = '';
  public costAndConsSeries : object;
  public costAndConsLoading : boolean;

  // Declaration for device consumption building wise - pie chart
  public plantConsumption : string = '';
  public plantConsumptionSeriesData : object;
  public loadingBarBuildConsumption: boolean;

  // Declaration for device avilability and utilization
  public utilizationTitle: string = '';
  public utilizationSeries: object;
  public utilizationLoading: boolean;
  
  // Trend chart for building wise consumption.
  public loadingBarTrend: boolean;
  
  // Declaration for engery consumption 
  public energyConsumptionChartTitle: string = '';
  public energyConsumptionChartSubTitle: string = `Daily ${this.units}`;
  public energyConsumptionyAxisText: string = `Values ${this.units}`;
  public energyConsumptionTrendsSeriesData: object;
  public energyConsumptionunit : string;

  // Declaration for engery consumption 
  public loadingPattern: boolean;
  public loadPatternChartTitle: string = '';
  public loadPatternSeriesData: object;
  public loadPatternunit : string;

  //Declaration for Co2 emmision
  public carbonEmmision : string = '';
  public carbonEmmisionSeriesData : object;
  public loadingcarbonEmmision: boolean;

  // Disable flag for intervals.
  public intervalOptions: object = {
    minute : false,
    daily: true,
    hourly : true,
    weekly : true,
    monthly : true
  };
  

  public interval: string = 'hourly';
  public intervalCC: string = 'hourly';
  public intLoadPattern: string = 'hourly';

  public trait: string = 'building';
  public PlantdetailSubscription : any;
  public PlantSummarySubscription : any;

  public dashCard = [
    {
      colorDark: '#42A5F5',
      colorLight: '#64B5F6',
      number: '0',
      title: `CONSUMPTION`,
      unit: ``,
      icon: 'offline_bolt'
    }, {
      colorDark: '#5C6BC0',
      colorLight: '#7986CB',
      number: 0,
      unit: ``,
      title: 'IDLING CONSUMPTION',
      icon: 'offline_bolt'
    },
    {
      colorDark: "rgb(245, 170, 170)",
      colorLight: "rgb(254, 205, 205)",
      number: 0,
      unit: ``,
      title: 'ENERGY COST',
      icon: 'attach_money'
    },
    {
      colorDark: "#66BB6A",
      colorLight: "#81C784",
      number: 0,
      unit: ``,
      title: 'SAVINGS',
      icon: 'attach_money'
    }
  ]; 
  
  // Sidebar 
  public toggle : any;


  constructor(private store: Store<fromStore.ContainerState>, 
    private utils: UtilityService,
    private plantService : PlantService, private route : ActivatedRoute) {
    this.pageTitle = this.route.snapshot.data.title
    this.plantId = this.route.snapshot.params.id;
    this.plantName = this.route.snapshot.params.name;
  }

  apiCall(plantId, trait, tag, from, to, id, interval) {
    // this.store.dispatch(new fromStore.LoadPlantEnergyCost(plantId, trait, tag, from, to, id, interval));
    // this.store.dispatch(new fromStore.LoadPlantEnergyIdling(plantId, trait, tag, from, to, id, interval));
    // this.store.dispatch(new fromStore.LoadPlantEnergySaving(plantId, trait, tag, from, to, id, interval));

    this.store.dispatch(new fromStore.LoadPlantCunsupmtion(plantId, trait, "energyconsumed", from, to, id, interval));
    this.store.dispatch(new fromStore.LoadPlantCo2Emission(plantId, trait, "carbonFootPrint", from, to, id, interval));
    this.store.dispatch(new fromStore.LoadPlantEngyConsTrend(plantId, trait, "energyconsumed", from, to, id, interval));
    this.store.dispatch(new fromStore.LoadPlantPattern(plantId, trait, "powerFactor", from, to, id, interval));
    this.store.dispatch(new fromStore.LoadCostConsum(plantId, trait, tag, from, to, id, interval));
  }

  setInterval(interval: string, page: string) {
    if (page === "lineChart" && interval != this.interval) {
      this.interval = interval;
      this.store.dispatch(new fromStore.LoadPlantEngyConsTrend(this.plantId, this.trait, "energyconsumed", this.fromDate, this.toDate, this.selectedId, interval));
    }

    if (page === "costAndCons" && interval != this.intervalCC) {
      this.intervalCC = interval;
      this.store.dispatch(new fromStore.LoadCostConsum(this.plantId, this.trait, null, this.fromDate, this.toDate, this.selectedId, interval));
    }

    if (page === "loadPattern" && interval != this.intLoadPattern) {
      this.intLoadPattern = interval;
      this.store.dispatch(new fromStore.LoadPlantPattern(this.plantId, this.trait, "powerFactor", this.fromDate, this.toDate, this.selectedId, interval));
    }
  }

  // Get the selected daterange picker value and call API.
  getSelectedvalue(range) {
    this.fromDate = range.startDate;
    this.toDate = range.endDate;
    let interval = this.getIntervalDetails();
    if(this.selectedId){
      this.apiCall(this.plantId, this.trait, null, this.fromDate, this.toDate, this.selectedId, interval);
      this.getPlantWidget(this.plantId, 'equipment', "NA", this.fromDate, this.toDate, this.selectedId, this.interval);
    }
  }

  getIntervalDetails() {
    let days = this.utils.daysDifference(this.fromDate, this.toDate);
    this.intervalOptions = this.utils.getInteralOptions(days);
    let interval = this.utils.findKey(this.intervalOptions);
    this.intLoadPattern = this.intervalCC = this.interval = interval;
    return interval;
  }

  // Get the selected value from dropdown and converting array to string, calling all api.
  getOnChange(buildingId: Array<any>) {
    if (buildingId && buildingId.includes(0)) {
      buildingId.splice(buildingId.indexOf(0), 1)
    }
    if (this.selectedId !== _.map(buildingId).join(',') && buildingId && buildingId.length) {
      this.selectedId = _.map(buildingId).join(',');
      let interval = this.getIntervalDetails();
      this.apiCall(this.plantId, this.trait, null, this.fromDate, this.toDate, this.selectedId, interval);
      this.getPlantWidget(this.plantId, 'equipment', "NA", this.fromDate, this.toDate, this.selectedId, this.interval);
    }
  }

  displayCostandCosum(costConsmData){
    this.costAndConsLoading = costConsmData.loading;
    this.costAndConsSeries =costConsmData.data;
    let chartTitle = this.utils.displayChartTitle('energyCostConsumption');
    this.costAndConspTitle = chartTitle['title'];
  }

  displayPlantCo2Emission(co2Emission:any) {
    const summaryTag = co2Emission.data.summaryTag;
    this.carbonEmmisionSeriesData = summaryTag && summaryTag.value;
    let chartTitle = this.utils.displayChartTitle('carbonFootprint');
    this.carbonEmmision = chartTitle['title'];
    this.loadingcarbonEmmision = co2Emission.loading;
  }

  displayPlantConsTrend(engyConsTrend) {
     this.loadingBarTrend = engyConsTrend.loading;
     const summaryTag = engyConsTrend.data.summaryTag;
     let chartTitle = this.utils.displayChartTitle('energyConsumption');
     this.energyConsumptionChartTitle = chartTitle['title'];
     this.energyConsumptionunit = chartTitle['units'];
     this.energyConsumptionTrendsSeriesData = summaryTag && summaryTag.value;
  }

  displayEnergyConsumption(consumption){
    const summaryTag = consumption.data.summaryTag;
    let unit =  summaryTag && summaryTag.unit;
    let consumptionValue = summaryTag && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;

    let convertedValue = this.utils.calcMegaWatt(consumptionValue, unit);
    //  this.dashCard[0].unit = convertedValue.units;
    //  this.dashCard[0].number = convertedValue.consumption;
    let chartTitle = this.utils.displayChartTitle('energyConsumption');
    this.plantConsumption = chartTitle['title'];
    this.plantConsumptionSeriesData = summaryTag && summaryTag.value;
    this.loadingBarBuildConsumption = consumption.loading;
  }
  displayEnergyCost(energyCost){
    const summaryTag = energyCost.data.summaryTag;
  //  this.dashCard[1].number = summaryTag && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
  //  this.dashCard[1].unit =  summaryTag && summaryTag.unit;
  }
  displayEnergyIdling(energyIdling){
    const summaryTag = energyIdling.data.summaryTag;
   // this.dashCard[2].number = summaryTag && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
  //  this.dashCard[2].unit =  summaryTag && summaryTag.unit;
  }
  displayEnergySaving(energySaving){
    const summaryTag = energySaving.data.summaryTag;
  //  this.dashCard[3].number = summaryTag && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
 //   this.dashCard[3].unit =  summaryTag && summaryTag.unit;
  }
  displayLoadPattern(plantPattern){
    this.loadingPattern = plantPattern.loading;  
    const summaryTag = plantPattern.data.summaryTag;

    let chartTitle = this.utils.displayChartTitle('loadPattern');
    this.loadPatternChartTitle = chartTitle['title'];
    this.loadPatternunit = chartTitle['units'];
    
    this.loadPatternSeriesData = summaryTag && summaryTag.value;
    
  }

  getPlantWidget(plantId: string, trait: string, tag: string, from: string, to: string, id: string, interval: string){
    this.plantService.getPlantTelemetry(plantId, trait, "NA", from, to, id, interval).subscribe(data => {

     // let convertedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, "kWh");

      // this.dashCard[0].unit = "KWh";
      this.dashCard[0].unit = "kWh";
      this.dashCard[0].number = this.utils.roundNumber(data.totalEnergyConsumed, 2);

      this.dashCard[2].unit = '$'
      this.dashCard[2].number = this.utils.roundNumber( data.totalEnergyCost, 2);

      this.dashCard[1].unit = "kWh";
      this.dashCard[1].number = this.utils.roundNumber(data.totalIdlingconsumption, 2);

      this.dashCard[3].unit = "$";
      this.dashCard[3].number = this.utils.roundNumber(data.totalSaving, 2);

    }, error => {
    //  console.log(error);
    });
  }

  ngOnInit() {

    

    this.defaultValue = this.utils.getDefaultDate();
    let defaultDate = this.utils.getDateRange();
    this.fromDate = defaultDate.fromDate;
    this.toDate = defaultDate.toDate;
    
    let loadedFlag = false;
    this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));

    this.PlantdetailSubscription =  this.store.select<any>('plant').subscribe(state => {

      this.plantName = state.data.PlantName;
      this.buildingsData = state.data.Buildings instanceof Array ? this.utils.formatDataDropDown(state.data.Buildings, {
        BuildingID: 'id',
        BuildingName: 'name'
      }) : [];

      // First API call  
      if(_.size(this.buildingsData) > 0 && !loadedFlag) {
        loadedFlag = true;
        this.selectedId = _.hasIn(this.buildingsData[0], 'id') ? _.map(this.buildingsData.map((obj)=>obj.id)).join(',') : '' ;
        let days = this.utils.daysDifference(this.fromDate, this.toDate);
        this.intervalOptions = this.utils.getInteralOptions(days);
        this.interval = this.utils.findKey(this.intervalOptions);
        this.getPlantWidget(this.plantId, 'equipment', "NA", this.fromDate, this.toDate, this.selectedId, this.interval);
        this.apiCall(this.plantId,  this.trait, null, this.fromDate, this.toDate, this.selectedId, this.interval);
      }

    });

    this.PlantSummarySubscription = this.store.select<any>('plantsummary').subscribe(state => {
      this.displayCostandCosum(state.costConsmData);
      this.displayPlantCo2Emission(state.co2Emission);
      this.displayEnergyConsumption(state.consumption);
      this.displayEnergyCost(state.energyCost);
      //this.displayEnergyIdling(state.energyIdling);
      // this.displayEnergySaving(state.energySaving);
      this.displayPlantConsTrend(state.engyConsTrend);
      this.displayLoadPattern(state.plantPattern);
    });
  }

  ngOnDestroy(){
    this.PlantdetailSubscription.unsubscribe();
    this.PlantSummarySubscription.unsubscribe();

    this.selectedId = '';
    this.buildingsData = [];
  }
}