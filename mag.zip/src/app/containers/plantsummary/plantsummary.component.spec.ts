import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlantsummaryComponent } from './plantsummary.component';

describe('PlantsummaryComponent', () => {
  let component: PlantsummaryComponent;
  let fixture: ComponentFixture<PlantsummaryComponent>;

  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });

});
