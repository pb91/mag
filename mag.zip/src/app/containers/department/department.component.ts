import {Component, OnInit} from '@angular/core';
import {PlantService} from '@appServices/plant.service';
import {ActivatedRoute} from '@angular/router';
// import { Hero } from '@appModels/hero';
import { Observable } from 'rxjs';

import * as _ from 'lodash';
import * as moment from 'moment';

import { Store } from '@ngrx/store';
import * as fromStore from '../../globalStore';
import { LOAD_GET_PLANT } from 'app/globalStore/actions/plantsummary.actions';
import { UniqueSelectionDispatcher } from '@angular/cdk/collections';
import { CATCH_ERROR_VAR } from '@angular/compiler/src/output/abstract_emitter';

import { UtilityService  } from '../../shared/utility.service';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.scss']
})
export class DepartmentComponent implements OnInit {

  //TODO: need to declart in constant file.
  units: string = 'kW';
  dollarSymbol: string = '$';
  toggle  : any;

  public observable: Observable<any>;

  public plantId : string;
  public treeData = {};
  public departmentData = [];
  public equipmentsData = [];
  public buildingsData = [];
  public fromDate;
  public toDate;

  public displaydata;
  public plantHierarchy;

  public pageTitle : string;
  public plantName : string;
  public defaultValue: object;
 // public loadedFlag : boolean =  false;

  // Declaration for device status pie chart
  public costAndConspChartTitle: string = ``;
  public costAndConsSeries : object;
  public costAndConsLoading : boolean;

  // Declaration for device consumption building wise - pie chart
  public energyConsumptionChartTitle : string = ``;
  public energyConsumptionSeriesData : object;
  public energyConsumptionLoadingBar: boolean;
  
  // Trend chart for building wise consumption.
  public trendLoadingBar: boolean;
  public trendSeriesData: object;
  public trendChartTitle:string = '';
  public trendYaxisText: string = `Values ${this.units}`;
  public trendunit: string ;

  //Declaration for Co2 emmision
  public carbonEmmision : string = ``;
  public carbonEmmisionSeriesData : object;
  public loadingcarbonEmmision: boolean;

  // Declaration for device avilability and utilization
  public utilizationTitle: string = '';
  public utilizationSeries: object;
  public utilizationLoading: boolean;

  public selectedId: string;
  public trait: string = 'department';
  public intervalOptions: object = {
    minute : false,
    daily: true,
    hourly : true,
    weekly : true,
    monthly : true
  };
  public interval: string = 'hourly';
  public intervalCC: string = 'hourly';

  public PlantdetailSubscription;
  public DepartmentSummarySubscription;

  public dashCard = [
    {
      colorDark: '#42A5F5',
      colorLight: '#64B5F6',
      number: '0',
      title: `CONSUMPTION`,
      unit: ``,
      icon: 'offline_bolt'
    }, {
      colorDark: '#5C6BC0',
      colorLight: '#7986CB',
      number: 0,
      unit: ``,
      title: 'IDLING CONSUMPTION',
      icon: 'offline_bolt'
    },
    {
      colorDark: "rgb(245, 170, 170)",
      colorLight: "rgb(254, 205, 205)",
      number: 0,
      unit: ``,
      title: 'ENERGY COST',
      icon: 'attach_money'
    },
    {
      colorDark: "#66BB6A",
      colorLight: "#81C784",
      number: 0,
      unit: ``,
      title: 'SAVINGS',
      icon: 'attach_money'
    }
  ]; 
  
  constructor(private store: Store<fromStore.ContainerState>, 
    private utils: UtilityService,
    private plantService : PlantService, private route : ActivatedRoute) {
    this.pageTitle = this.route.snapshot.data.title
    this.plantId = this.route.snapshot.params.id;
    this.plantName = this.route.snapshot.params.name;
  }

 apiCall(plantId: string, trait: string, tag: string, from: string, to: string, id: string, interval: string) {

    // Widget API
    // this.store.dispatch(new fromStore.LoadDeptCost(plantId, trait, tag, from, to, id, 'minute'));

    // Energy Consumption data by equipment wise & widget.
     this.store.dispatch(new fromStore.LoadDeptEngConsum(plantId, trait, "energyconsumed", from, to, id, 'hourly'));

    // this.store.dispatch(new fromStore.LoadDeptIdle(plantId, trait, tag, from, to, id, 'minute'));

    // Energy Consumption trendz.
    this.store.dispatch(new fromStore.LoadDeptEngConsumTrend(plantId, trait, "energyconsumed", from, to, id, interval));

    // Energy Consumption and cost.
    this.store.dispatch(new fromStore.LoadDeptCostConsum(plantId, trait, tag, from, to, id, interval));

    // Cost of Energy saving
    // this.store.dispatch(new fromStore.LoadDeptSave(plantId, trait, tag, from, to, id, interval));

    // CO2 emission 
    this.store.dispatch(new fromStore.LoadDeptCo2(plantId, trait, "carbonFootPrint", from, to, id, 'hourly'));

    // Utilization and Availablity 
    // this.store.dispatch(new fromStore.LoadDeptAvaUtilization(plantId, trait, "utilization", from, to, id, interval));
}

  // Get the selected daterange picker value.
  getSelectedvalue(range: any) {
    this.fromDate = range.startDate;
    this.toDate = range.endDate;
    let interval = this.getIntervalDetails();
    if(this.selectedId){
      this.getDepartmentWidget(this.plantId, 'equipment', "NA", this.fromDate, this.toDate, this.selectedId, this.interval);
      this.apiCall(this.plantId, this.trait, null, this.fromDate, this.toDate, this.selectedId, interval);
    }
  }

  getIntervalDetails() {
    let days = this.utils.daysDifference(this.fromDate, this.toDate);
    this.intervalOptions = this.utils.getInteralOptions(days);
    let interval = this.utils.findKey(this.intervalOptions);
    this.interval = this.intervalCC = interval;
    return interval;
  }

  getOnChange(departmentId: Array<any>) {
    if( departmentId && departmentId.includes(0)){
      departmentId.splice(departmentId.indexOf(0) , 1)
    }
    if( this.selectedId !==  _.map(departmentId).join(',') &&  departmentId && departmentId.length){
      this.selectedId = _.map(departmentId).join(',');
      let interval = this.getIntervalDetails();
      this.apiCall(this.plantId, this.trait, null , this.fromDate, this.toDate, this.selectedId, interval);
      this.getDepartmentWidget(this.plantId, 'equipment', "NA", this.fromDate, this.toDate, this.selectedId, this.interval);
    }
  }

  displayConsumption(consumData: any){
    this.energyConsumptionLoadingBar = consumData.loading;
    const summaryTag = consumData.data.summaryTag;
    
    // let consumptionValue = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    // let unit =  summaryTag && summaryTag.unit && summaryTag.unit;

    // let convertedValue = this.utils.calcMegaWatt(consumptionValue, unit);
    // this.dashCard[0].unit = convertedValue.units;
    // this.dashCard[0].number = convertedValue.consumption;

    this.energyConsumptionSeriesData = summaryTag && summaryTag.value  

    let chartTitle = this.utils.displayChartTitle('energyConsumption');
    this.energyConsumptionChartTitle = chartTitle['title'];

   // this.energyConsumptionChartTitle = summaryTag ? `${summaryTag.kpiTitle} (${summaryTag.unit})` : '';
  }

  displayCostConsumption(costConsumData: any){
    this.costAndConsLoading = costConsumData.loading;
    this.costAndConsSeries = costConsumData.data;

    let chartTitle = this.utils.displayChartTitle('energyCostConsumption');
    this.costAndConspChartTitle = chartTitle['title'];

  }

  displayConsumptionTrend(consumTrendData: any){
    const summaryTag = consumTrendData.data.summaryTag;
    this.trendLoadingBar = consumTrendData.loading;
    this.trendSeriesData = summaryTag && summaryTag.value instanceof Array && summaryTag.value;

    let chartTitle = this.utils.displayChartTitle('energyConsumption');
    this.trendChartTitle = chartTitle['title'];
    this.trendunit = chartTitle['units'];

  }

  displaycallCo2Emission(co2Data:any){
    this.loadingcarbonEmmision = co2Data.loading;    
    const summaryTag = co2Data.data.summaryTag;
    this.carbonEmmisionSeriesData = summaryTag && summaryTag.value;
    let chartTitle = this.utils.displayChartTitle('carbonFootprint');
    this.carbonEmmision = chartTitle['title'];
  }

  displayUtility(avaUtilizationData: any) {
    this.utilizationLoading = avaUtilizationData.loading;
    const summaryTag = avaUtilizationData.data.summaryTag;
    this.utilizationSeries = avaUtilizationData.data;
    let chartTitle = this.utils.displayChartTitle('utilization');
    this.utilizationTitle = chartTitle['title'];

  }

  displayCost(costData: any){
    const summaryTag = costData.data.summaryTag;
    this.dashCard[1].number = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    this.dashCard[1].unit =  summaryTag && summaryTag.unit && summaryTag.unit;
  }

  displayIdle(idleData: any){
    const summaryTag = idleData.data.summaryTag;
    this.dashCard[2].number = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    this.dashCard[2].unit =  summaryTag && summaryTag.unit && summaryTag.unit;
  }

  displaySave(saveData: any){
    const summaryTag = saveData.data.summaryTag;
    this.dashCard[3].number = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    this.dashCard[3].unit =  summaryTag && summaryTag.unit && summaryTag.unit;
  }

  setInterval(interval:string, page:string) {
    if(page === "lineChart" && interval != this.interval) {
      this.interval = interval;
      this.store.dispatch(new fromStore.LoadDeptEngConsumTrend(this.plantId, this.trait,  "energyconsumed", this.fromDate, this.toDate, this.selectedId, interval));
    }
    if(page === "costAndCons" && interval != this.intervalCC) {
      this.intervalCC = interval;
      this.store.dispatch(new fromStore.LoadDeptCostConsum(this.plantId, this.trait, null, this.fromDate, this.toDate, this.selectedId, interval));
    }
  }

  getDepartmentWidget(plantId: string, trait: string, tag: string, from: string, to: string, id: string, interval: string){
    this.plantService.getDepartmentTelemetry(plantId, trait, "NA", from, to, id, interval).subscribe(data => {

      // let convertedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, "KWh");
      this.dashCard[0].unit = "kWh";
      this.dashCard[0].number = this.utils.roundNumber(data.totalEnergyConsumed, 2);

      this.dashCard[2].unit = '$'
      this.dashCard[2].number = this.utils.roundNumber( data.totalEnergyCost, 2);

      this.dashCard[1].unit = "kWh";
      this.dashCard[1].number = this.utils.roundNumber(data.totalIdlingconsumption, 2);

      this.dashCard[3].unit = "$";
      this.dashCard[3].number = this.utils.roundNumber(data.totalSaving, 2);

    }, error => {
      console.log(error);
    });
  }

  ngOnInit() {
    
    this.defaultValue = this.utils.getDefaultDate();
    let defaultDate = this.utils.getDateRange();
    this.fromDate = defaultDate.fromDate;
    this.toDate = defaultDate.toDate;
    let loadedFlag = false;

    this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.PlantdetailSubscription =  this.store.select<any>('plant').subscribe(state => {
      this.plantHierarchy = state.data;
      this.plantName = state.data.PlantName;
      this.departmentData = state.data.Departments instanceof Array ? this.utils.formatDataDropDown(state.data.Departments, {
        DepartmentID: 'id',
        DepartmentName: 'name'
      }) : [];

      // First API call  
      if(_.size(this.departmentData) > 0 && !loadedFlag) {
        loadedFlag = true;
        this.selectedId = _.hasIn(this.departmentData[0], 'id') ? _.map(this.departmentData.map((obj)=>obj.id)).join(',') : '' ;
        let days = this.utils.daysDifference(this.fromDate, this.toDate);
        this.intervalOptions = this.utils.getInteralOptions(days);
        this.interval = this.utils.findKey(this.intervalOptions);
        this.getDepartmentWidget(this.plantId, 'equipment', "NA", this.fromDate, this.toDate, this.selectedId, this.interval);
        this.apiCall(this.plantId,  this.trait, null, this.fromDate, this.toDate, this.selectedId, this.interval);
      }
    });

    this.DepartmentSummarySubscription = this.store.select<any>('departmentsummary').subscribe(state => {

    // Display Energy Consumption
     this.displayConsumption(state.consumData);
    // this.displayCost(state.costData);
    // this.displayIdle(state.idleData);
    // this.displaySave(state.saveData);

    // Energy Cost and Energy Consumption.
    this.displayCostConsumption(state.costConsumData);

    // Display Consumption Trend.
    this.displayConsumptionTrend(state.consumTrendData);

    // Display Consumption Trend.
    this.displaycallCo2Emission(state.co2Data);

    // Display Availiability and Utilization.
   // this.displayUtility(state.avaUtilizationData);

    });

  }

  ngOnDestroy(){
    this.PlantdetailSubscription.unsubscribe();
    this.DepartmentSummarySubscription.unsubscribe();

    this.selectedId = '';
    this.departmentData = [];
  }
  
}