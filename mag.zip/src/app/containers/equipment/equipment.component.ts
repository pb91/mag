import {Component, OnInit} from '@angular/core';

import {PlantService} from '@appServices/plant.service';

import { Router, ActivatedRoute } from '@angular/router';
import { UtilityService  } from '../../shared/utility.service';
import { equipmentMetaData  } from '../../models/plantSummary/plant.model';

import { Store } from '@ngrx/store';
import * as fromStore from '../../globalStore';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
  selector: 'app-equipment',
  templateUrl: './equipment.component.html',
  styleUrls: ['./equipment.component.scss']
})

export class EquipmentComponent implements OnInit {

  //TODO: need to declart in constant file.
  units: string = 'kW';
  dollarSymbol: string = '$';
  toggle : any;


  public equipmentArray = [];
  public metaData: equipmentMetaData = {
    Device_Type: '',
    Meter:  '',
    Current_Status:  '',
    Building:  '',
    Department: '',
    PXG900_IP_Address : ''
};

  public departmentData = [];
  public buildingsData = [];
  public equipmentsData = [];
  public fromDate: string;
  public toDate: string;
  public equipmentName:string;
  public intervalOptions: object = {
    minute : false,
    daily: true,
    hourly : true,
    weekly : true,
    monthly : true
  };


  public costConsuminterval: string = 'hourly';
  public powFactorinterval: string = 'hourly';
  public peakDemandinterval: string = 'hourly';
  public interval: string = 'hourly';
  
  public trait: string = "equipment";

  // Declaration for consumption and cost stacked chart
  public deviceCostAndConspTitle: string = '';
  public deviceCostAndConsSeries : object;
  public deviceCostAndConsLoading : boolean;

  // Declaration for device consumption building wise - pie chart
  public equipmentConsumption : string = ``;
  public equipmentConsumptionSeriesData : object;
  public loadingequipmentConsumption: boolean;
  
  // Trend chart for building wise consumption
  public loadingBarTrend: boolean;
  public energyConsumptionyAxisText: string = `Values ${this.units}`;
  public energyConsumptionTrendsSeriesData: object;
  public energyConsumptionTrendsUnit:string ;
  public energyConsumptionTrendsTitle:string = '';

  // Peak demand chart declaration.
  public peakDemandLoadingBar: boolean;
  public peakDemandSeriesData: object;
  public peakTitle : string = '';

 // Power Factor chart declaration   
  public powerFactorSeries: object;
  public powerFactorUnit: string;
  public powerFactorLoading: boolean;
  public powerFactorTitle: string = '';
 
  // Peak demand chart declaration.
  public deviceStautsChartTitle: string =  `Device Status`;
  public deviceStatusLoadingBar: boolean;
  public deviceStautsSeriesName: string = "";
  public deviceStatusSeriesData : object;

  //Declaration for Co2 emmision
  public carbonEmmision : string = ``;
  public carbonEmmisionSeriesData : object;
  public loadingcarbonEmmision: boolean;

  // Declaration for device avilability and utilization
  public utilizationTitle: string = '';
  public utilizationSeries: object;
  public utilizationLoading: boolean;
  public  filterEquip : any;


  public plantId : string;
  public deviceId : string;
  public deviceName : string;

  public dashCard = [
    {
      colorDark: '#42A5F5',
      colorLight: '#64B5F6',
      number: '0',
      title: `CONSUMPTION`,
      unit: ``,
      icon: 'offline_bolt'
    }, {
      colorDark: '#5C6BC0',
      colorLight: '#7986CB',
      number: 0,
      unit: ``,
      title: 'IDLING CONSUMPTION',
      icon: 'offline_bolt'
    },
    {
      colorDark: "rgb(245, 170, 170)",
      colorLight: "rgb(254, 205, 205)",
      number: 0,
      unit: ``,
      title: 'ENERGY COST',
      icon: 'attach_money'
    },
    {
      colorDark: "#66BB6A",
      colorLight: "#81C784",
      number: 0,
      unit: ``,
      title: 'SAVINGS',
      icon: 'attach_money'
    },
    {
      colorDark: '#A5AB72',
      colorLight: '#CCD0AE',
      number: 0,
      unit: ``,
      title: 'CO2',
      icon: 'cloud'
    }
  ]; 

  public pageTitle : string;
  public building : number;
  public department : number;
  public plantName : string;
  public defaultValue: object;
  public equipmentId: string;

  constructor(private store: Store<fromStore.ContainerState>, private utils: UtilityService,
    private plantService: PlantService, private route: ActivatedRoute ,  private router: Router,) {
    this.pageTitle = this.route.snapshot.data.title

    this.intervalOptions = this.utils.getInteralOptions(null);
    this.deviceId = this.route.snapshot.params.deviceId;
    this.plantId = this.route.snapshot.params.plantId;
    this.deviceName = this.route.snapshot.params.deviceName;
  }

  getEquipmentWidget(plantId: string, trait: string, tag: string, from: string, to: string, id: string, interval: string){
    this.plantService.getEquipmentTelemetry(plantId, trait, "NA", from, to, id, interval).subscribe(data => {
      
      // let consumedValue = this.utils.calcMegaWatt(data.totalEnergyConsumed, 'kWh');
      this.dashCard[0].unit = "kWh";
      this.dashCard[0].number = this.utils.roundNumber(data.totalEnergyConsumed, 2);

      this.dashCard[2].unit = '$'
      this.dashCard[2].number = this.utils.roundNumber(data.totalEnergyCost, 2);

      this.dashCard[1].unit = "kWh";
      this.dashCard[1].number = this.utils.roundNumber(data.totalIdlingconsumption, 2);

      this.dashCard[3].unit = "$";
      this.dashCard[3].number = this.utils.roundNumber(data.totalSaving, 2);

      this.dashCard[4].unit = "kg";
      this.dashCard[4].number = this.utils.roundNumber(data.totalCarbonFootPrint, 2);

    }, error => {
      console.log(error);
    });
  }


  apiCall(plantId: string, trait: string, tag: string, from: string, to: string, id: string, interval: string) {

    // Widget API
    // this.store.dispatch(new fromStore.LoadEquipCost(plantId, trait, tag, from, to, id, interval));
    // this.store.dispatch(new fromStore.LoadEquipIdle(plantId, trait, tag, from, to, id, interval));
    // Energy Consumption data by equipment wise & widget.
    // this.store.dispatch(new fromStore.LoadEquipEngConsum(plantId, trait, tag, from, to, id, interval));

    this.store.dispatch(new fromStore.LoadEquipCostConsum(plantId, trait, tag, from, to, id, interval));

    // Power Factor
    this.store.dispatch(new fromStore.LoadEquipPowerFactor(plantId, trait, "powerFactor", from, to, id, interval));

    // Energy Consumption trendz.
     this.store.dispatch(new fromStore.LoadEquipEngConsumTrend(plantId, trait, "energyconsumed", from, to, id, interval));

    // Energy Consumption and cost.
   //  

    // CO2 emission 
    // this.store.dispatch(new fromStore.LoadEquipCo2(plantId, trait, tag, from, to, id, null));

    this.store.dispatch(new fromStore.LoadEquipPeakDemand(plantId, trait, "powerDemand", from, to, id, 'hourly'));

    // Cost of Energy saving
    // this.store.dispatch(new fromStore.LoadEquipSave(plantId, trait, tag, from, to, id, interval));


    //Utilization and Availablity 
    // this.store.dispatch(new fromStore.LoadEquipAvaUtilization(plantId, trait, "utilization", from, to, id, interval));
  }

  getIntervalDetails() {
    let days = this.utils.daysDifference(this.fromDate, this.toDate);
    this.intervalOptions = this.utils.getInteralOptions(days);
    let interval = this.utils.findKey(this.intervalOptions);
    this.costConsuminterval = this.powFactorinterval = this.peakDemandinterval = this.interval = interval;
    return interval;
  }

  // Get the selected daterange picker value.
  getSelectedvalue(range:object) {
    if(this.equipmentId){
      this.fromDate = range['startDate'];
      this.toDate = range['endDate'];
      let interval = this.getIntervalDetails();

      this.getEquipmentWidget(this.plantId, this.equipmentName , "NA", this.fromDate, this.toDate, this.equipmentId, this.interval);
      this.apiCall(this.plantId, this.equipmentName, null, this.fromDate, this.toDate, this.equipmentId, interval);

    }
  }

  setInterval(interval:string, pageDetails: string) {

    if(pageDetails === "costConsuminterval" && interval != this.costConsuminterval) {
      this.costConsuminterval = interval;
      this.store.dispatch(new fromStore.LoadEquipCostConsum(this.plantId, this.equipmentName, null, this.fromDate, this.toDate, this.equipmentId, interval));
    }

    if(pageDetails === "powFactorinterval" && interval != this.powFactorinterval) {
      this.powFactorinterval = interval;
      this.store.dispatch(new fromStore.LoadEquipPowerFactor(this.plantId, this.equipmentName, "powerFactor", this.fromDate, this.toDate, this.equipmentId, interval));
    }

    if(pageDetails === "peakDemandinterval" && interval != this.peakDemandinterval) {
      this.peakDemandinterval = interval;
      this.store.dispatch(new fromStore.LoadEquipPeakDemand(this.plantId, this.equipmentName, "powerDemand", this.fromDate, this.toDate, this.equipmentId, interval));
    }

    if(pageDetails === "interval" && interval != this.interval) {
      this.interval = interval;
      this.store.dispatch(new fromStore.LoadEquipEngConsumTrend(this.plantId, this.equipmentName, "energyconsumed", this.fromDate, this.toDate, this.equipmentId, interval));
    }
  }

  getOnChange(equipment:string) {
    if(this.equipmentId !== equipment && equipment ){
    this.equipmentId = equipment;
    this.metaData = _.find(this.equipmentArray,  (object) => { return object.id == this.equipmentId; });
    this.equipmentName = _.hasIn(this.metaData, "Equipment") ? this.metaData['Equipment'] : "" ;
      let interval = this.getIntervalDetails();
    this.getEquipmentWidget(this.plantId, this.equipmentName, "NA", this.fromDate, this.toDate, this.equipmentId, this.interval);
    this.apiCall(this.plantId, this.equipmentName, null , this.fromDate, this.toDate, this.equipmentId, interval);
    }
  }
  
  displayConsumption(consumData: any){
    this.loadingequipmentConsumption = consumData.loading;
    const summaryTag = consumData.data.summaryTag;
    
    let consumptionValue = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    let unit =  summaryTag && summaryTag.unit && summaryTag.unit;

    // let convertedValue = this.utils.calcMegaWatt(consumptionValue, unit);
    // this.dashCard[0].unit = convertedValue.units;
    // this.dashCard[0].number = convertedValue.consumption;

    this.equipmentConsumptionSeriesData = summaryTag && summaryTag.value  
    this.equipmentConsumption = summaryTag ? `${summaryTag.kpiTitle} (${summaryTag.unit})` : '';
  }

  displayCostConsumption(costConsumData: any){
    this.deviceCostAndConsLoading = costConsumData.loading;
    this.deviceCostAndConsSeries = costConsumData.data;

    let chartTitle = this.utils.displayChartTitle('energyCostConsumption');
    this.deviceCostAndConspTitle = chartTitle['title'];

  }

  displayConsumptionTrend(consumTrendData: any){
    const summaryTag = consumTrendData.data.summaryTag;
    this.loadingBarTrend = consumTrendData.loading;
    // this.energyConsumptionTrendsSeriesData = summaryTag && summaryTag.value instanceof Array && summaryTag.value;
    this.energyConsumptionTrendsSeriesData = this.utils.getSummaryData(summaryTag);

    let chartTitle = this.utils.displayChartTitle('energyConsumption');
    this.energyConsumptionTrendsTitle = chartTitle['title'];
    this.energyConsumptionTrendsUnit = chartTitle['units'];

  }

  displaycallCo2Emission(co2Data:any){
    const summaryTag = co2Data.data.summaryTag;
    // this.dashCard[4].number = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue(summaryTag.value, "value") : 0;
    // this.dashCard[4].unit =  summaryTag && summaryTag.unit && summaryTag.unit;
  }

  displayUtility(avaUtilizationData: any) {
    this.utilizationLoading = avaUtilizationData.loading;
    const summaryTag = avaUtilizationData.data.summaryTag;

    // this.utilizationTitle = summaryTag && `${summaryTag.kpiTitle} (${summaryTag.unit})`;
    this.utilizationSeries = avaUtilizationData.data;

    let chartTitle = this.utils.displayChartTitle('utilization');
    this.utilizationTitle = chartTitle['title'];

  }

  displayCost(costData: any){
    const summaryTag = costData.data.summaryTag;
    // this.dashCard[1].number = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    // this.dashCard[1].unit =  summaryTag && summaryTag.unit && summaryTag.unit;
  }

  displayIdle(idleData: any){
    const summaryTag = idleData.data.summaryTag;
    // this.dashCard[2].number = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    // this.dashCard[2].unit =  summaryTag && summaryTag.unit && summaryTag.unit;
  }

  displaySave(saveData: any){
    const summaryTag = saveData.data.summaryTag;
    // this.dashCard[3].number = summaryTag && summaryTag.value && summaryTag.value instanceof Array ? this.utils.getAggregateValue( summaryTag.value, "value") : 0;
    // this.dashCard[3].unit =  summaryTag && summaryTag.unit && summaryTag.unit;
  }

  displayPowerFactor(powerFactor: any) {
   this.powerFactorLoading = powerFactor.loading
   const summaryTag = powerFactor.data.summaryTag;
   this.powerFactorSeries = this.utils.getSummaryData(summaryTag);
   // this.powerFactorSeries = summaryTag &&  summaryTag.value instanceof Array && summaryTag.value;
   

   let chartTitle = this.utils.displayChartTitle('powerFactor');
   this.powerFactorTitle = chartTitle['title'];
   this.powerFactorUnit = chartTitle['units'];

  }

  displayPeakDemand(peakDemand: any) {
    this.peakDemandLoadingBar = peakDemand.loading
   //  this.peakDemandSeriesData = [];
    let value = [];
    const summaryTag = peakDemand.data.summaryTag;
    value.push(summaryTag);
    value.push({
      kpiName: "PeakDemand",
      kpiTitle: "PeakDemand",
      unit: "unit", value: {
        label : "PeakDemand",
        value:  peakDemand.data.peakPowerDemand
      }});

   // this.peakDemandSeriesData = this.utils.getSummaryData(peakDemand.data);

    this.peakDemandSeriesData = value;
    let chartTitle = this.utils.displayChartTitle('demandChart');
    this.peakTitle = chartTitle['title'];

    

    // _.forEach(this.peakDemandSeriesData, (value, key) => {
    //   const summaryTag = value['summaryTag'];
    //   let title = summaryTag && `${summaryTag['kpiTitle']} (${summaryTag['unit']})`;
    //   if (key == '0') {
    //     this.peakTitle = `${title}`;
    //   } else {
    //     this.peakTitle = `${this.peakTitle} and ${title}`;
    //   }
    // });
  }

  findObject(collection:any, findId: string) {
    return _.find(collection, function(object) { 
      return object['Equipment'] == findId; 
    });
  }

    getDepartmentWidget(plantId: string, trait: string, tag: string, from: string, to: string, id: string, interval: string){
    this.plantService.getDepartmentTelemetry(plantId, trait, "NA", from, to, id, interval).subscribe(data => {

      this.dashCard[0].unit = "kWh";
      this.dashCard[0].number = this.utils.roundNumber(data.totalEnergyConsumed, 2);

      this.dashCard[1].unit = '$'
      this.dashCard[1].number = this.utils.roundNumber( data.totalEnergyCost, 2);

      this.dashCard[2].unit = "kWh";
      this.dashCard[2].number = this.utils.roundNumber(data.totalIdlingconsumption, 2);

      this.dashCard[3].unit = "$";
      this.dashCard[3].number = this.utils.roundNumber(data.totalSaving, 2);

    }, error => {
      console.log(error);
    });
  }

  ngOnInit() {
    this.defaultValue = this.utils.getDefaultDate();
    let defaultDate = this.utils.getDateRange();
    this.fromDate = defaultDate.fromDate;
    this.toDate = defaultDate.toDate;
    let loadedFlag = false;
    this.filterEquip = ['*Multipoint Meter','Digitrip 910', 'Optim1050 Trip Unit',
  'IQ150 Meter',
  'IQ250 Meter',
  'Meter point',
  'DT1150 Trip Unit']
    this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    this.store.dispatch(new fromStore.LoadPlant(this.plantId));
    this.store.select<any>('plant').subscribe(state => {
      this.plantName = state.data.PlantName;
      
      let fillteredObject =  _.filter(state.data.Equipments, (o) => { 
        return _.indexOf(this.filterEquip, o.Device_Type) !== -1; 
      });

      this.equipmentsData = fillteredObject instanceof Array ? this.utils.formatDataDropDown(fillteredObject, {
        id: 'id',
        Equipment: 'name'
      }) : [];


      if(this.equipmentsData.length){
        let idx;
        this.equipmentsData.forEach((obj , index)=>{
        if(obj.name == this.deviceName &&    obj.id == this.deviceId) {
          idx = index;
        }
        })
  
        this.equipmentsData[idx].id = this.equipmentsData[0].id;
        this.equipmentsData[idx].name = this.equipmentsData[0].name;
        this.equipmentsData[0].id =this.deviceId;
        this.equipmentsData[0].name =this.deviceName;
      }
     

      this.equipmentArray = state.data.Equipments instanceof Array ? state.data.Equipments : [];
      // First API call  
      if(_.size(this.equipmentsData) > 0 && !loadedFlag) {
        loadedFlag = true;
        this.equipmentId = _.hasIn(this.equipmentsData[0], 'id') ? this.deviceId: null;
        this.equipmentName = _.hasIn(this.equipmentsData[0], 'name') ? this.deviceName : null;
        this.metaData = this.findObject(this.equipmentArray, this.equipmentsData[0].name);
        let days = this.utils.daysDifference(this.fromDate, this.toDate);
        this.intervalOptions = this.utils.getInteralOptions(days);
        this.interval = this.utils.findKey(this.intervalOptions);
        this.apiCall(this.plantId, this.equipmentName, null, this.fromDate, this.toDate, this.equipmentId, this.interval);
        this.getEquipmentWidget(this.plantId, this.equipmentName, "NA", this.fromDate, this.toDate, this.equipmentId, this.interval);
      }
    });


    this.store.select<any>('equipmentsummary').subscribe(state => {
      // Display Energy Consumption

      // this.displayConsumption(state.consumData);
      // this.displayCost(state.costData);
      // this.displayIdle(state.idleData);
      // this.displaySave(state.saveData);
 
      // Energy Cost and Energy Consumption.
      this.displayCostConsumption(state.costConsumData);

      // Power Factor
       this.displayPowerFactor(state.powerFactor);
  
      // // Display Consumption Trend.
      this.displayConsumptionTrend(state.consumTrendData);
  
      // // Display Consumption Trend.
      // this.displaycallCo2Emission(state.co2Data);
  
      // // Display Availiability and Utilization.
      // this.displayUtility(state.avaUtilizationData);
      
       this.displayPeakDemand(state.peakDemand);
      });      
  }


  back() {
    this.router.navigate(['equipment', this.plantId]);
  }

    detail(){
        this.router.navigate(['equipmentview' ,"view" , this.deviceId , this.plantId , this.deviceName]);
    }
    summary(){
        this.router.navigate(['equipmentsummary' , this.deviceId , this.plantId , this.deviceName]);
    }
    device(){
        this.router.navigate(['equipmentdevicelist', this.deviceId , this.plantId , this.deviceName]);
    }



  ngOnDestroy(){
 
  }
}