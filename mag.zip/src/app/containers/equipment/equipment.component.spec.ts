import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentComponent } from './equipment.component';

describe('EquipmentComponent', () => {
  let component: EquipmentComponent;
  let fixture: ComponentFixture<EquipmentComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
