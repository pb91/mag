import { Component, OnInit } from '@angular/core';
import { UsersService } from '@appServices/users.service';
import {ActivatedRoute, Router} from '@angular/router';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { UtilityService  } from '../../../shared/utility.service';
// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../../globalStore';
import { DialogboxComponent } from '@appComponents/dialogbox/dialogbox.component';
import { MatDialog } from '@angular/material';
import * as _ from 'lodash';

@Component({
  selector: 'app-plant',
  templateUrl: './plant.component.html',
  styleUrls: ['./plant.component.scss']
})
export class PlantComponent implements OnInit {
  plant: any;
  configuration : any= {
    filters: {
      column: true,
      sort: true,
      search: true,
      groupBy: true,
      filter: true
    },
    others: {
      dateFormat: ''
    },
    columnFilterConditions: [
      { value: 'contains', label: 'Contains', search: true }
    ],
    columns: [
      {
        column: 'Name',
        visibility: true,
        isAnchor: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: true,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Email',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Contact',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: true,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Phone',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'Description',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      }
    ]
  };

  public pageTitle : string;
  public loadingBar: boolean;

  constructor(public dialog: MatDialog, private usersService: UsersService, 
    public notificationMsg : ToastComponent,
    private utils: UtilityService,
    private route: ActivatedRoute, private router: Router , private store: Store<fromStore.ContainerState>) {
    this.pageTitle = this.route.snapshot.data.title
   }

  ngOnInit() {
    this.getPlants();
    this.store.dispatch(new fromStore.ResetPreference());
  }

  getPlants() {
    this.store.dispatch(new fromStore.LoadDashboard());
    this.store.select<any>('dashboard').subscribe(state => {
      this.loadingBar = state.loading;
      this.plant = state.data.tableData;
    });
  }

  anchorPressed(event) {
    this.router.navigate(['/usersManagement/plant', 'view', event['data'].PlantID]);
  }

  createPlant(){
    this.router.navigate(['/usersManagement/plant', 'create', '']);
  }

  // editClicked(event:object){
  //   this.router.navigate(['/usersManagement/plant', 'edit', event['data'].PlantID]);
  // }

  // onViewClicked(event:object){
  //   this.router.navigate(['/usersManagement/plant', 'view', event['data'].PlantID]);
  // }

  // deletePlantById(id:string){
  //   this.loadingBar = true;
  //   this.usersService.deletePlantById(id).subscribe(data => {
  //     this.store.dispatch(new fromStore.LoadDashboard());
  //     this.notificationMsg.showSucess(this.utils.displayMessage("Plant","delete"));
  //   }, error => {
  //     this.loadingBar = false;
  //   });
  // }

  // onDeleteClicked(event:object){
  //   let plantId = _.hasIn(event['data'], "PlantID") ? event['data'].PlantID : "";
  //   let plantName = _.hasIn(event['data'], "Name") ? event['data'].Name : "";
  //   const dialogRef = this.dialog.open(DialogboxComponent, {
  //     width: '300px',
  //     height: '120px',
  //     data: `Do you confirm the deletion of ${plantName}?`
  //   });

  //   dialogRef.afterClosed().subscribe(result => {
  //     if(plantId === "7b5a783d-61d7-46b4-ae07-2371ff1a45c3") {
  //       this.notificationMsg.showWarning("Default Site Can't Be Deleted");
  //     } else {
  //     if(result && plantId) {
  //       this.deletePlantById(plantId);
  //     }
  //   }
  //   });

  // }

}