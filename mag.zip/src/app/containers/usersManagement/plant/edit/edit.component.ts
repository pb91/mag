import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { UsersService } from '@appServices/users.service';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { UtilityService } from '../../../../shared/utility.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import {PlantService} from '@appServices/plant.service';
import * as _ from 'lodash';
import * as moment from 'moment';
// Store
import { Store } from '@ngrx/store';
import { DialogboxComponent } from '@appComponents/dialogbox/dialogbox.component';
import { MatDialog } from '@angular/material';
import * as fromStore from '../../../../globalStore';

export interface Roles {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  pageTitle: string = "Site Details";
  formTitle: string;
  plantName : string;
  formGroup: FormGroup;
  selectedPosition: any;
  message: any = {};
  subscription: Subscription;
  titleAlert: string = 'This field is mandatory';
  post: any = '';
  loadingFlag: boolean;
  siteLocation: any;
  plantId: string;
  pageDetails: string;
  editFlag: boolean = false;
  viewFlag: boolean = false;
  activationCode: string;
  activationDate: string;
  createFlag: boolean = false;
  appearance: string = "outline";
  Roles: Roles[] = [
    { value: 'plantAdmin', viewValue: 'Plant Admin' },
    { value: 'plantUser', viewValue: 'Plant User' }
  ];

  Sites: Roles[] = [
    { value: 'Arcibo', viewValue: 'Arcibo' },
    { value: 'Lnt', viewValue: 'Lnt' }
  ];

  selectedPlantDetails: any;

  namesConstant = {
    name: "Name",
    description: "Description",
    // contact: "Contact",
    email: "Email Address",
    phone: "Phone",
    activation_detail : "Device Activation Code",
    created: "Created On",
    created_by: "Created By",
    modified: "Modified On",
    modified_by: "Modified By",
    display_name: "Display Name",
    first_name: "First Name",
    last_name: "Last Name",
    company_name: "Company Name",
    job_title: "Job Title",
    department: "Department",
    profile_description: "Profile Description"
  }

  viewStruct: object = {
    plantDetail: ["name",
      "description",
      // "contact",
      "email",
      "phone",
      "activation_detail",
      "created",
      "created_by",
      "modified",
      "modified_by"],

    userDetails: ["display_name",
      "first_name",
      "last_name",
      "company_name",
      "job_title",
      "department",
      "profile_description"]
  }

  detailsArray = { plantDetail: []};


  constructor(private usersService: UsersService,
    public notificationMsg: ToastComponent,
    private plantService : PlantService,
    public dialog: MatDialog,
    private utils: UtilityService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private store: Store<fromStore.ContainerState>, ) {
    this.pageDetails = this.route.snapshot.params.page;
    this.plantId = this.route.snapshot.params.plantId;
    if (this.pageDetails === "edit") {
      this.editPageDisplay();
      //this.getPlantDetailsById(this.plantId);
    } else if (this.pageDetails === "view") {
      this.loadingFlag = true;
      this.store.dispatch(new fromStore.SelectedPlant(this.plantId));
      this.appearance = "none";
      //this.getPlantDetailsById(this.plantId);
      this.formTitle = "View";
      this.viewFlag = true;
    } else if (this.pageDetails == "create") {
      this.viewFlag = false;
      this.appearance = "outline";
      this.formTitle = "Create";
    }
    this.getPlantDetails();
  }

  expChange(reg){
    console.log("reggg",typeof reg)
    console.log("test called" , reg.replace(/\n/g, " "))

    return reg.replace(/(\\r\\n)|([\r\n])/gmi, '<br/>')
  }

  getPlantDetails() {
  this.subscription = this.store.select<any>('UserManagement').subscribe(state => {
    if(this.pageDetails.trim() === "view"){
      this.createView(state.SelectedPlant.data);
      }else if(this.pageDetails.trim() === "edit"){
        if(state.SelectedPlant.data['PlantDocument']){
          this.setSiteLocation(state.SelectedPlant.data);
        }
        if(state.SelectedPlant.data['UserDetail']){
          this.updateFormData(state.SelectedPlant.data)
        }
      }
      if(! Array.isArray( state.SelectedPlant.data)){
       this.loadingFlag = false;
      }
    });
  }

  editPageDisplay() {
    this.formTitle = "Edit";
    this.pageDetails = "edit";
    this.viewFlag = false;
    this.appearance = "outline";
    this.loadingFlag = true;
    this.store.dispatch(new fromStore.SelectedPlant(this.plantId));
    this.getPlantDetailsById(this.plantId);
  }

  getPlantDetailsById(id: string) {
    this.loadingFlag = true;
    this.usersService.GetPlantById(id).subscribe(data => {
      this.loadingFlag = false;
      this.updateFormData(data);
      this.selectedPlantDetails = data;
      this.selectedPlantDetails['PlantDetail'].modified = moment.utc(this.selectedPlantDetails['PlantDetail'].modified).local().format('llll')
      this.selectedPlantDetails['PlantDetail'].created = moment.utc(this.selectedPlantDetails['PlantDetail'].created).local().format('llll')
    }, error => {
      this.loadingFlag = false;
    });
  }

  getSelectedPosition(event: any){
    this.selectedPosition = event;
  }

  back() {
    this.router.navigate(['/usersManagement/plant']);
  }

  regenerate() {
    if(this.plantId !== "7b5a783d-61d7-46b4-ae07-2371ff1a45c3") {
    this.loadingFlag = true;
    this.plantService.generateCode(this.plantId).subscribe(data => {
      this.notificationMsg.showSucess("Code Generate Successfully");
      this.getPlantDetailsById(this.plantId);
    }, error => {
      console.log("error");
    });
    } else {
      this.notificationMsg.showWarning("Default Site Can't Be changed");
    }
  }

  createView(obj: any) {
    this.detailsArray = { plantDetail: []};
    let plantDetail = this.viewStruct['plantDetail'];
    plantDetail.forEach((element: string) => {
    
      if (obj['PlantDetail'] && obj['PlantDetail'][element] !== undefined) {
        if (element === "created"  || element === "modified") {
          this.detailsArray.plantDetail.push({ 'key': this.namesConstant[element], 'value': obj['PlantDetail'][element] ? moment.utc(obj['PlantDetail'][element]).local().format('llll') : "" })
        } else if (element === "activation_detail") {
          this.detailsArray.plantDetail.push({ 'key': this.namesConstant[element] , 'value': _.size(obj['PlantDetail'][element]) > 0 ? obj['PlantDetail'][element]["activation_code"] : "" });
          this.detailsArray.plantDetail.push({ 'key': "Device Expiration Date" , 'value': _.size(obj['PlantDetail'][element]) > 0 ? 
          moment.utc(obj['PlantDetail'][element]["expiration_date"]).local().format('llll') : "" });
        }else if(element === "description"){
          let newLine = _.cloneDeep(obj['PlantDetail'][element])
          this.detailsArray.plantDetail.push({ 'key': this.namesConstant[element], 'value': obj['PlantDetail'][element] ? newLine.replace(/\\n/g, ' ') : "" })
        } else {
          this.detailsArray.plantDetail.push({ 'key': this.namesConstant[element], 'value': obj['PlantDetail'][element] ? obj['PlantDetail'][element] : "" })
        }
      }
    });
  }

  setSiteLocation(plantObject: object) {
    if(_.hasIn(plantObject, "PlantDocument")) {
      let PlantDocument = plantObject["PlantDocument"];
      this.plantName = PlantDocument['PlantName'];
      if(_.hasIn(PlantDocument.Location, "Longitude") && _.hasIn(PlantDocument.Location, "Latitude")) {
        this.siteLocation = [ PlantDocument.Location['Longitude'], PlantDocument.Location['Latitude']]
      }
    }
  }

  updateFormData(plantObject: object) {
    let plantDetails = plantObject["PlantDetail"];
    
    if(_.hasIn(plantDetails, "activation_detail")) {
      this.activationCode = _.hasIn(plantDetails["activation_detail"], "activation_code") ? plantDetails["activation_detail"].activation_code : "";
      this.activationDate = _.hasIn(plantDetails["activation_detail"], "expiration_date") ? moment.utc(plantDetails["activation_detail"].expiration_date).local().format('llll') : "";
    }
   
    this.formGroup.setValue({
      "name": _.hasIn(plantDetails, "name") ? plantDetails.name : "",
      "description": _.hasIn(plantDetails, "description") ? plantDetails.description.replace(/\\n/g, ' ') : "",
      // "contact": _.hasIn(plantDetails, "contact") ? plantDetails.contact : "",
      "email": _.hasIn(plantDetails, "email") ? plantDetails.email : "",
      "phone": _.hasIn(plantDetails, "phone") ? plantDetails.phone : "",
      "contact": _.hasIn(plantDetails, "contact") ? plantDetails.contact : ""
    });
  }

  ngOnInit() {
    this.createForm();
    this.store.dispatch(new fromStore.ResetPreference());
  }

  createForm() {
    let emailregex: RegExp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
     let phone: RegExp = /^[1-9]\d*$/
    this.formGroup = this.formBuilder.group({
      'name': ["", Validators.required],
      'description': ["", Validators.required],
      'email': ["", [Validators.required, Validators.pattern(emailregex)]],
      'phone': [null,Validators.pattern(phone)],
      'contact': [null]
    });
  }
 
  keyPress(event: any) { 
    const pattern = /[0-9\+\-\ ]/;
   let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  checkInUseEmail(control) {
    // mimic http database access
    let db = [];
    return new Observable(observer => {
      setTimeout(() => {
        let result = (db.indexOf(control.value) !== -1) ? { 'alreadyInUse': true } : null;
        observer.next(result);
        observer.complete();
      }, 4000)
    })
  }

  editPlant() {
    this.router.navigate(['/usersManagement/plant', 'edit', this.plantId]);
    this.editPageDisplay();
  }

  onDeleteClicked(event:object){
    let plantId = this.plantId;
    let plantNameDetails = _.find(this.detailsArray.plantDetail, function(o) { return o.key == "Name"; });
    let plantName = _.hasIn(plantNameDetails, "value") ? plantNameDetails.value : "";
    const dialogRef = this.dialog.open(DialogboxComponent, {
      width: '300px',
      height: '120px',
      data: `Do you confirm the deletion of ${plantName}?`
    });
    dialogRef.afterClosed().subscribe(result => {
      if(plantId === "7b5a783d-61d7-46b4-ae07-2371ff1a45c3") {
        this.notificationMsg.showWarning("Default Site Can't Be Deleted");
      } else {
      if(result && plantId) {
        this.deletePlantById(plantId);
      }
    }
    });
  }

  deletePlantById(id:string){
    this.loadingFlag = true;
    this.usersService.deletePlantById(id).subscribe(data => {
      this.notificationMsg.showSucess(this.utils.displayMessage("Site","delete"));
      this.back();
    }, error => {
      this.loadingFlag = false;
    });
  }

  getErrorEmail() {
    return this.formGroup.get('email').hasError('required') ? 'Field is required' :
      this.formGroup.get('email').hasError('pattern') ? 'Not a valid emailaddress' :
        this.formGroup.get('email').hasError('alreadyInUse') ? 'This emailaddress is already in use' : '';
  }

  createUpdatePlant(plantObject: object, plantId: string) {
    this.loadingFlag = true;

    if(_.size(this.selectedPosition) > 0) {
      plantObject['latitude'] = this.selectedPosition[1];
      plantObject['longitude'] = this.selectedPosition[0];
    }

    this.usersService.createUpdatePlant(plantObject, plantId).subscribe(data => {
      this.loadingFlag = false;
      if (this.pageDetails === "edit") {
        this.notificationMsg.showSucess(this.utils.displayMessage("Site", "edit"));
      }
      if (this.pageDetails === "create") {
        this.notificationMsg.showSucess(this.utils.displayMessage("Site", "create"));
      }
      this.router.navigate(['/usersManagement/plant']);
    }, error => {
      this.loadingFlag = false;
    });
  }

  onSubmit(plantObject: object) {
    this.createUpdatePlant(plantObject, this.plantId);
  }
}