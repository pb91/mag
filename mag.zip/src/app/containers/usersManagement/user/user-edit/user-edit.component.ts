import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { Observable }    from 'rxjs/Observable';
import {ActivatedRoute, Router} from '@angular/router';
import { UsersService } from '@appServices/users.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { UtilityService  } from '../../../../shared/utility.service';
import { environment } from 'environments/environment';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../../../globalStore';
import * as _ from 'lodash';
import { DialogboxComponent } from '@appComponents/dialogbox/dialogbox.component';
export interface Roles {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.scss']
})
export class UserEditComponent implements OnInit {
  public Eula = environment.EULA; 
  loadingFlag : boolean;
  loadingPersonalFlag: boolean;
  subscription : any ;
  pageTitle:string;
  pageHeader:string;
  formGroup: FormGroup;
  role_site : FormArray;
  userFormGroup: FormGroup;
  myFormGroupSubs:Subscription;  
  titleAlert: string = 'This field is mandatory';
  post: any = '';
  selectedId : any ;
  plantId: string;
  displayName: string;
  buttonText: string;
  assignRoles:any;
  // Declartion to display no of site/roles
  displaySites: Array<number> =  [1];
  number_of_books:number[];


  Roles: Roles[] = [];
  Sites: Roles[] = [];
  

  namesConstant =  {
  company_address: 'Company Address',
  company_name: 'Company Name',
  created: 'Created',
  created_by: 'Created By',
  department: 'Department',
  display_name: 'Name',
  email: 'Email',
  first_name: 'First Name',
  job_title: "Job Title",
  last_name: "Last Name",
  modified: 'Modified',
  modified_by: "Modified By",
  phone_number: 'Phone Number',
  role_name : "Role Name",
  site_name : " Site Name"
}

viewStruct : Array<string>= [
  "display_name",
  "first_name",
  "last_name",
  "job_title",
  "role_name",
  "site_name",
  "department",
  "email",
  "phone_number",
  "company_address",
  "company_name",
  "created",
  "created_by",
  "modified",
  "modified_by",
]

detailsArray = [];

showFlag = {
  EDIT : false,
  VIEW : false,
  CREATE : false
}
headerText: string;

  constructor(public dialog: MatDialog, 
    private formBuilder: FormBuilder , private route: ActivatedRoute, private router: Router , private usersService: UsersService , private store: Store<fromStore.ContainerState> ,  public notificationMsg : ToastComponent,   private utils: UtilityService) { 
    this.pageHeader = "User Details";

    this.route.params.subscribe( params =>
      {
        this.pageTitle = params.type, 
        this.selectedId = params.id, 
        this.plantId = params.plantId

        });
    this.pageTitle.trim() === "Edit" ? this.showFlag.EDIT = true : 
    this.pageTitle.trim() === "View" ? this.showFlag.VIEW = true : 
    this.showFlag.CREATE = true;
  }

  ngOnInit() {

    this.Roles = [
      {value: '3feaa021-5d76-3478-b924-7049efb6c5d5', viewValue: 'Plant User'}
    ];

    if(this.utils.validateURL(["PlantAdmin", "GlobalAdmin", "AdopterAdmin"])) {
      this.Roles.push({value: '23ed7d37-ca4e-bc1c-afa9-3304b9feecb8', viewValue: 'Plant Admin'});
    }

    switch (this.pageTitle.trim()) {
      case "Edit":
      this.loadingFlag = true;
      this.getPlants();
      this.store.dispatch(new fromStore.SelectedUser( this.selectedId, this.plantId));
      this.createForm();
      this.createUserForm();
      this.headerText = "Edit";
      this.buttonText = "EDIT"; 
        break;

      case "create":
      case "clone":
      this.getPlants();
      this.createForm();
      if(this.pageTitle === "clone") {
        this.store.dispatch(new fromStore.SelectedUser(this.selectedId, this.plantId));
      }
      
      this.headerText = "Invite";
      this.buttonText = "ADD";


        break;
      case "View":
      this.headerText = "View";
      this.loadingFlag = true;
      this.store.dispatch(new fromStore.SelectedUser( this.selectedId, this.plantId));
     
        break;
      default:      
    }
     this.getUserDetails();
     if(this.plantId) {
      this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    } else {
      this.store.dispatch(new fromStore.ResetPreference());
    }
  //  this.setChangeValidate()
  }


  getUserDetails(){
    this.subscription =  this.store.select<any>('UserManagement').subscribe(state => { 
      if(this.pageTitle.trim() === "View"){        
        this.displayName = _.hasIn(state.SelectedUser.data, "display_name") ? state.SelectedUser.data['display_name'] : "";
        this.createView(state.SelectedUser.data);
         this.loadingFlag = state.SelectedUser.loading;
       } else if(this.pageTitle.trim() === "Edit"){     
        this.fillForm(state.SelectedUser.data);
        this.userGroupForm(state.SelectedUser.data);
         this.loadingFlag = state.SelectedUser.loading;
       } else if (this.pageTitle == "clone") {
        this.fillForm(state.SelectedUser.data);
        this.loadingFlag = state.SelectedUser.loading;
       }
     });
  }

  // Delete 
  // constructRolesObject() {
  //   this.assignRoles = [];
  //   this.Sites.forEach((obj, index) => {
  //     this.assignRoles.push({
  //       siteId: obj['PlantID'],
  //       siteName: obj['Name'],
  //       checkboxSiteUser: `plantUser_${index}`,
  //       checkboxSiteAdmin: `plantAdmin_${index}`,
  //       plantUserId: this.Roles[0].viewValue == "Plant User" ? this.Roles[0].value : "",
  //       plantUserName: this.Roles[0].viewValue == "Plant User" ? this.Roles[0].viewValue : "",
  //       plantAdminId: this.Roles[1].viewValue == "Plant Admin" ? this.Roles[1].value : "",
  //       plantAdminName: this.Roles[1].viewValue == "Plant Admin" ? this.Roles[1].viewValue : ""
  //     });
  //   });
  // }

  userGroupForm(x) {
    this.userFormGroup.controls['display_name'].setValue(_.hasIn(x, 'display_name') ? x.display_name : "");
    this.userFormGroup.controls['first_name'].setValue( _.hasIn(x, 'first_name') ? x.first_name : "" );
    this.userFormGroup.controls['last_name'].setValue(_.hasIn(x, 'last_name') ? x.last_name : "" );
    this.userFormGroup.controls['company_name'].setValue(_.hasIn(x, 'company_name') ? x.company_name : "");
    this.userFormGroup.controls['company_address'].setValue(_.hasIn(x, 'company_address') ? x.company_address : "" );
    this.userFormGroup.controls['job_title'].setValue(_.hasIn(x, 'job_title') ? x.job_title : "" );
    this.userFormGroup.controls['department'].setValue(_.hasIn(x, 'department') ? x.department : "");
    this.userFormGroup.controls['phone_number'].setValue(_.hasIn(x, 'phone_number') ? x.phone_number : "" );   
  }

  fillForm(x){
    let sites = [];
    // For Clone page remove the set value for email
    this.pageTitle === "clone" ? this.formGroup.controls['email'].setValue("") :
    this.formGroup.controls['email'].setValue(_.hasIn(x, 'email') ? x.email : "");

    _.hasIn(x, 'roles') && _.hasIn(x['roles'][0], 'role_id') && this.formGroup.controls['role'].setValue(_.hasIn(x, 'roles') ? x['roles'][0]['role_id'] : "" );
     if(_.hasIn(x, 'roles')){
      x['roles'].forEach((obj , index) => {
        if(obj['site_name'] !== undefined){
          sites.push(obj['site_id'])
        }
      });
      this.formGroup.controls['site_id'].setValue(sites ? sites : "" );
     }else{
     this.formGroup.controls['site_id'].setValue( "" );
     }
  }


  createView(obj: any){
    this.detailsArray = [];
    this.viewStruct.forEach((element : string) => {
      if(obj[element] !== undefined && element !== "role_name" && element !== "site_id"){
       if(element === "created"  ||  element === "modified" ){
        this.detailsArray.push({'key' : this.namesConstant[element] , 'value' : obj[element] ? moment.utc( obj[element]).local().format('llll') : "" })
       } else {
        this.detailsArray.push({'key' : this.namesConstant[element] , 'value' : obj[element] ? obj[element] : "" })
       }
      } else if( element === "role_name" && _.size(obj['roles']) > 0 && obj['roles'] && obj['roles'][0][element] !== undefined  ){
        this.detailsArray.push({'key' : this.namesConstant[element] , 'value' : obj['roles'][0][element] ? obj['roles'][0][element] : "" })
      }else if( element === "site_name" && obj['roles']  ){
        let sites = ""
         obj['roles'].forEach((obj_ , index) => {
           if(obj_[element] !== undefined){
            sites =  sites + obj_[element]
            if(index !== obj['roles'].length -1 ){
              sites = sites + ","
            }
            
           }
         });

        this.detailsArray.push({'key' : this.namesConstant[element] , 'value' : sites ? sites : "" })
      }      
  });
  }

  createUserForm() {
    this.userFormGroup = this.formBuilder.group({
      'first_name': [""],
      'last_name':  [""],
      'company_name' : [""],
      'company_address': [""],
      'job_title' :  [""],
      'department' :  [""],
      'phone_number' :  [""],
      'display_name' : [null, Validators.required],
    });
  }

  createForm() {
    let emailregex: RegExp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    let phone: RegExp = /^[1-9]\d*$/;
    this.formGroup = this.formBuilder.group({
      'email': [null, [Validators.required, Validators.pattern(emailregex)]],
      'role_site' : this.formBuilder.array([ this.createItem() ]),
      'terms' : this.showFlag.EDIT ? [""] : [null, Validators.required]
    });
  }

  // addroles() {
  //   const role = this.formGroup.controls.role_site as FormArray;
  //   console.log("this.formGroup.controls.role_site",this.formGroup.controls.role_site);
  //   // role.push(this.formBuilder.group({
  //   //   'role' : null,
  //   //   'site_id' : null,
  //   // }));
  // }

  addroles(): void {
    this.role_site = this.formGroup.get('role_site') as FormArray;
    this.role_site.push(this.createItem());
  }

  createItem(): FormGroup {
    return this.formBuilder.group({
      'role': '',
      'site_id': ''
    });
  }


  getErrorEmail() {
    return this.formGroup.get('email').hasError('required') ? 'Field is required' :
      this.formGroup.get('email').hasError('pattern') ? 'Not a valid emailaddress' :
        this.formGroup.get('email').hasError('alreadyInUse') ? 'This emailaddress is already in use' : '';
  }

  getPlants() {
    this.store.dispatch(new fromStore.LoadDashboard());
    this.store.select<any>('dashboard').subscribe(state => {
      this.loadingFlag = state.loading;
      this.Sites = state.data.tableData;
    });
  }


  onSubmitUserGroup(post) {
    if (this.userFormGroup.valid) {

      let submitJSON = {
        "email_id"  : this.formGroup.controls.email.value,
        "display_name": post.display_name ? post.display_name : "" ,
        "first_name": post.first_name ? post.first_name : "",
        "last_name": post.last_name ? post.last_name : "",
        "company_name": post.company_name ? post.company_name : "",
        "company_address": post.company_address ? post.company_address : "",
        "job_title": post.job_title ? post.job_title : "",
        "department": post.department ? post.department : "",
        "phone_number": post.phone_number ? post.phone_number : ""
      }
  
      submitJSON['id'] = this.selectedId;
  
      this.loadingPersonalFlag = true
        this.usersService.updateUserPerInfo(submitJSON, this.plantId).subscribe(data => {
          this.loadingPersonalFlag = false;
          this.notificationMsg.showSucess(this.utils.displayMessage("User","edit"));
        }, error => {
          this.loadingPersonalFlag = false;      
        });
      }
  }

  onSubmit(post) {
    if (this.formGroup.valid) {

    this.post = post;
    let roles = post['site_id'].map((site) => {
      return {
        "role_id": post['role'],
        "site_id": site
      }
    })

    let submitJSON = {
      "email": post.email ? post.email : "" ,
      "roles": roles
    }

    if(this.pageTitle.trim() === "Edit"){
      submitJSON['id'] = this.selectedId;
    }

    this.loadingFlag = true
      this.usersService.saveUser(submitJSON, this.plantId).subscribe(data => {
        this.loadingFlag = false;
        if(this.pageTitle.trim() === "Edit") {
          this.notificationMsg.showSucess(this.utils.displayMessage("User","edit"));
        } else {
          this.notificationMsg.showSucess("Invited User successfully");
        }
        this.back();
      }, error => {
        this.loadingFlag = false;      
      });
    }
  }

  editUser() {
    let plantId = this.plantId ? this.plantId : "";
    this.router.navigate(['usersManagement/user/operation' , "Edit" , this.selectedId, plantId ]);
    this.loadingFlag = true;
    this.buttonText = "UPDATE";
    this.headerText = "Edit";
    this.getPlants();
    this.showFlag.VIEW = false;
    this.showFlag.EDIT = true;
    this.createForm();
    this.createUserForm();
    this.store.dispatch(new fromStore.SelectedUser( this.selectedId, this.plantId));
    this.getUserDetails();
  }

  onDeleteClicked(event:any){
    let displayName = this.displayName && this.displayName;
    const dialogRef = this.dialog.open(DialogboxComponent, {
      width: '280px',
      height: '130px',
      data: `Do you confirm the deletion of ${displayName}?`
    });
    dialogRef.afterClosed().subscribe(result => {
      if(result) {
        this.loadingFlag = true;
        let plantId = this.plantId ? this.plantId : "";
        this.usersService.deleteSelectedUser(this.selectedId, plantId).subscribe(data => {
          this.loadingFlag = false;
            this.notificationMsg.showSucess(this.utils.displayMessage("User","delete"));
            this.back();
        }, error => {
          this.loadingFlag = false;
        });
      }
    });
  }

  back() {
    if(this.plantId) {
      this.router.navigate(['/usersManagement/user', this.plantId]);
    } else {
      this.router.navigate(['/usersManagement/user']);
    }
  }

  ngOnDestroy() {    
    this.subscription.unsubscribe();
  }

}
