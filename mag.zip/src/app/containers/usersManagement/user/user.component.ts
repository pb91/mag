import { Component, OnInit, Inject } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Roles  } from '../../../shared/roles';

// Store
import { Store } from '@ngrx/store';
import * as fromStore from '../../../globalStore';
import * as _ from 'lodash';

import {UsersService} from '../../../services/users.service';
import { DialogboxComponent } from '@appComponents/dialogbox/dialogbox.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { UtilityService  } from '../../../shared/utility.service';
import { environment } from 'environments/environment';
import { ExcelService } from '@appServices/excel.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  user: any;
  public excelUserTemplatePath: string = environment.excelUserTemplatePath;
  plant: any;
  loadingFlag : boolean;
  configuration : any= {
    filters: {
      column: true,
      sort: true,
      search: true,
      groupBy: true,
      filter: true
    },
    others: {
      dateFormat: ''
    },
    columnFilterConditions: [
      { value: 'contains', label: 'Contains', search: true }
    ],
    columns: [
      {
        column: 'display_name',
        isAnchor: true,
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: true,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'email',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'job_title',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: true,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'phone_number',
        visibility: true,
        groupBy: true,
        sort: true,
        filter: true,
        groupByState: false,
        isBtn: false,
        BtnCSS: ''
      },
      {
        column: 'clone',
        visibility: true,
        groupBy: false,
        sort: false,
        filter: false,
        groupByState: false,
        isBtn: false,
        isClone: true,
        BtnCSS: ''
      }
    ]
  };

  public pageTitle : string;
  public loadingBar: boolean;
  public plantId: string;

  public displayActivityLogs : boolean = false;

  constructor(
    private excelService: ExcelService,
    public dialog: MatDialog, private route: ActivatedRoute, private router: Router , 
    private store: Store<fromStore.ContainerState> , 
    private UsersService : UsersService ,  public notificationMsg : ToastComponent,   private utils: UtilityService) {
    this.pageTitle = this.route.snapshot.data.title
    this.plantId = this.route.snapshot.params.plantId;
   }

   exportAsXLSX(activityLogs:[]):void {
    this.excelService.exportAsExcelFile(activityLogs, 'Activity Logs');
  }

  getActivityLogs() {
    this.loadingBar = true;
    this.UsersService.getActivityLogs().subscribe(data => {
      this.loadingBar = false;
      console.log(data);
      this.exportAsXLSX(data);
    }, error => {
      this.loadingBar = false;
    });
  }


  ngOnInit() {

    if(this.utils.validateURL(Roles.activityLogs.view)) {
      this.displayActivityLogs = true;
    }

    this.getUsers();
    if(this.plantId) {
      this.store.dispatch(new fromStore.UpdatePreference(this.plantId));
    } else {
      this.store.dispatch(new fromStore.ResetPreference());
    }
  }

  getUsers(){
    let plantId = this.plantId ? this.plantId : null;
    this.store.dispatch(new fromStore.LoadUsers(plantId));
    this.store.select<any>('UserManagement').subscribe(state => {
      this.loadingBar = state.User.loading;
      if(_.hasIn(state, "User")){
        this.user = _.sortBy(state.User.data, [function (o) { return o.display_name; }]);
      }
    });
  }

  fileUpload(evt){
    var fileInput = document.getElementById('file');
    var filePath = fileInput['value'];
    var allowedExtensions = /(\.xlsx)$/i;
    if(!allowedExtensions.exec(filePath)){
        this.notificationMsg.showWarning("Please upload file having extensions .xlsx");
        return false;
    } else {
      this.loadingBar = true;
      const formData = evt.target.files[0]; // FileList object
    }
  }

  uploadUser(formData){
    this.UsersService.uploadBlukUser(this.plantId, formData).subscribe(data => {
      this.notificationMsg.showSucess("File Upload Successfully");
      this.loadingBar = false;
    }, error => {
      this.loadingBar = false;
    });
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(UserUploadDialog);
    dialogRef.afterClosed().subscribe(result => {
      
    });
  }

  onUploadPlant(){
    const dialogRef = this.dialog.open(UserUploadDialog, {
      data : this.plantId ? this.plantId : null
    });
    dialogRef.afterClosed().subscribe(result => {
     // console.log("");
    });
  }

  createUser(){
    let plantId = this.plantId ? this.plantId : "";
    this.router.navigate(['usersManagement/user/operation', "create", '' , plantId]);
  }

  anchorPressed(event:any){
    let plantId = this.plantId ? this.plantId : "";
    this.router.navigate(['usersManagement/user/operation' , "View" , event.data.id, plantId]);
  }

   clonePressed(event:any){
    if(event.colname && _.hasIn(event.colname, "id")) {
      let plantId = this.plantId ? this.plantId : "";
      this.router.navigate(['usersManagement/user/operation', "clone", event.colname['id'],  plantId]);
    }
    
   
  }

}


@Component({
  selector: 'user-upload-dialog',
  templateUrl: 'user-upload-dialog.html',
})
export class UserUploadDialog {
  loadingFlag: boolean;
  sites: any;
  formGroup: FormGroup;
  formData: any
  selectedSiteId: string;
  plantId: string;
  titleAlert: string = 'This field is mandatory';
  
  constructor(
    @Inject(MAT_DIALOG_DATA) public message: string, 
    public dialog: MatDialog,
    public notificationMsg: ToastComponent,
    private UsersService : UsersService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<UserUploadDialog>,
    private store: Store<fromStore.ContainerState>,
    private route: ActivatedRoute,
    private router: Router,
  ) {
    dialogRef.disableClose = true;
  }

    cancelLogout(): void {
      this.dialogRef.close();
    }

    ngOnInit() {
      this.formData = null;
      // If we have site id plant selection is not required.
      this.message ? this.cerateUploadForm() : this.createForm();
      !this.message && this.getPlants();
    }

    getUsers(){
    let plantId = this.plantId ? this.plantId : null;
    this.store.dispatch(new fromStore.LoadUsers(this.message));
    this.store.select<any>('UserManagement').subscribe(state => {
    });
  }

    createForm() {
      this.formGroup = this.formBuilder.group({
        'site_id': ["", Validators.required],
        'excelFile': ["", [Validators.required] ], 
      });
    }

    cerateUploadForm() {
      this.formGroup = this.formBuilder.group({
        'excelFile': ["", [Validators.required] ], 
      });
    }

    getPlants() {
      this.store.dispatch(new fromStore.LoadDashboard());
      this.store.select<any>('dashboard').subscribe(state => {
        this.sites = state.data.tableData;
        this.loadingFlag = state.loading;
      });
    }

    fileValidation(formData){
      var filePath = formData.name;
      var allowedExtensions = /(\.xlsx)$/i;
      if(!allowedExtensions.exec(filePath)){
          this.notificationMsg.showWarning("Please upload file having extensions .xlsx");
          return false;
      }
      return true;
    }

    fileUpload(evt){
      this.formData = evt.target.files[0];
    }

    save() {    
        let name = this.fileValidation(this.formData);
        if(name) {
            let plantId = this.message ? this.message : this.selectedSiteId;
            this.loadingFlag = true;
            this.UsersService.uploadBlukUser(plantId, this.formData).subscribe(state => {
            this.loadingFlag = false;
            this.notificationMsg.showSucess("Uploaded Successfully");            
            this.getUsers();
            this.dialogRef.close();
            }, error => {
            this.loadingFlag = false;
            this.dialogRef.close();
            });   
        }
    }
}