export interface AlarmsList {
    Plant : String;
    Building: String;
    Departments: String;
    Status: String;
    Created: Number;
    Modified: Number;
    Description: String;
    Severity: String;
}

export interface Alarms {
    AlarmsData: AlarmsList[]
}