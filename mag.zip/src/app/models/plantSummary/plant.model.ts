export interface DepartmentTable {
    departments: Department[];
}

export interface Department {
    id: String;
    name: String;
}

export interface BuildingsTable {
    buildings: Buildings[];
}

export interface Buildings {
    id: String;
    name: String;
}

export interface EquipmentsTable {
    equipment: Equipment[];
}

export interface Equipment {
    id: String;
    name: String;
}

export interface Plant {
    departments?: DepartmentTable[];
    buildings?: BuildingsTable[];
    equipment?: EquipmentsTable[];
}

export interface equipmentMetaData {
    Device_Type?: string;
    Meter?: string;
    Current_Status?: string;
    Building?: string;
    Department?: string;
    PXG900_IP_Address?: string;
}