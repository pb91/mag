import { NavigationContent } from './navigation.model';
import { PreferenceContent } from './preference.model';
export interface CombinedNavigation {
    navigation?: NavigationContent[];
    preference?: PreferenceContent[];
}
