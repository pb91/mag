export interface PreferenceContent {
  type: string;
  title: string;
  icon?: string;
  link?: string;
}


