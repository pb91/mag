export interface NavigationContent {
    type: string;
    title: string;
    icon?: string;
    link?: string;
}
