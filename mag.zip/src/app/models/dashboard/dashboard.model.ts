export interface DashboardTable {
    PlantID: String;
    Name: String;
    Phone: String;
    Contact: String;
    Email: String;
    Building: String;
    Departments: String;
    Description: String;
    Action: String;
}

export interface DashboardKPI {
    colorDark: String;
    colorLight: String;
    number: Number;
    title: String;
    icon: String;
}

export interface Dashboard {
    KPI?: DashboardKPI[];
    tableData?: DashboardTable[];
    mappingData?: MapsData[];
}

export interface MapsData {
    lat: Number;
    lon: Number;
    user: String;
}