export interface Notifications {
    pending?: number;
    recent?: NotificationsList[];
    redirection?: string;
}

export interface DashboardTable {
    Site: String;
    Contact: String;
    Email: String;
    Building: String;
    Departments: String;
    Description: String;
    Action: String;
}

export interface DashboardKPI {
    totalPlant?: Number;
    totalUsers?: Number;
    totalBuilding?: Number;
    totalEquipment?: Number;
}

export interface Dashboard {
    KPI: DashboardKPI;
    tableData: DashboardTable[];
}

export interface NotificationsList {
    id?: number;
    title?: string;
    icon?: string;
    date?: string;
}