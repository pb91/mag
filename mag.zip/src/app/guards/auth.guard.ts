import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '@appServices/authentication.service';
import * as _ from 'lodash';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService
    ) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser = this.authenticationService.currentUserValue;
        if (currentUser) {
            // authorised so return true
            let checkRoles  = localStorage.getItem('userRoles');
            var rolesArray = checkRoles.split(',');
            let presentArray = _.intersection(rolesArray, route.data.roles);
                if (route.data.roles && _.size(presentArray) == 0) {
                    // role not authorised so redirect to home page
                    this.router.navigate(['/unauthorized']);
                    return false;
                }

            return true;
        }

        // not logged in so redirect to login page with the return url
        this.router.navigateByUrl("/sign-in");
        return false;
    }
}