import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displaypreference',
  templateUrl: './displaypreference.component.html',
  styleUrls: ['./displaypreference.component.scss']
})
export class DisplaypreferenceComponent implements OnInit {
  public userPreference;
  constructor() { }
 
  ngOnInit() {

    this.userPreference = [{
      internalName : "cost",
      enternalName : "Display Cost",
     defaultChecked : true
   },
   {
     internalName : "consumption",
     enternalName : "Display Consumption",
    defaultChecked : false
  },
  {
   internalName : "costandconsumption",
   enternalName : "Display Cost & Consumption",
  defaultChecked : true
 }]
  }

}
