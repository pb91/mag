import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaypreferenceComponent } from './displaypreference.component';

describe('DisplaypreferenceComponent', () => {
  let component: DisplaypreferenceComponent;
  let fixture: ComponentFixture<DisplaypreferenceComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
