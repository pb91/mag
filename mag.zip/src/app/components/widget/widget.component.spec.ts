/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject, async } from '@angular/core/testing';
import { WidgetComponent } from './widget.component';

const inputData = [ {
  number: '0',
  title: "widget title",
  unit: '11',
  icon: 'offline_bolt'
} ];

describe('Component: Widget', () => {
    let component: WidgetComponent;
    let fixture: ComponentFixture<WidgetComponent>;
    beforeEach(() => {
      component = new WidgetComponent();
    });

    it('Should be pass Imput Array Object', () => {
      component.dashData = this.inputData;
    });
});