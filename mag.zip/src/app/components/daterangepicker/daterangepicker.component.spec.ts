import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DaterangepickerComponent } from './daterangepicker.component';

describe('DaterangepickerComponent', () => {
  let component: DaterangepickerComponent;
  let fixture: ComponentFixture<DaterangepickerComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});