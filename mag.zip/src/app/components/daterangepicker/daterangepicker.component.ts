import { Component, OnInit, Output, EventEmitter, Input, SimpleChanges } from '@angular/core';
import * as moment from 'moment';
// import { start } from 'repl';

@Component({
  selector: 'app-daterangepicker',
  templateUrl: './daterangepicker.component.html',
  styleUrls: ['./daterangepicker.component.scss']
})
export class DaterangepickerComponent implements OnInit {
  @Input() defaultValue : any;
  tomorrow = moment().endOf('d');

  opens: string;
  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  selected : any;
  showClearButton:boolean;
  maxDate: moment.Moment =  moment().endOf('d');
  minDate: moment.Moment;
  @Output() selectedValue = new EventEmitter();
  // invalidDates: moment.Moment[] = [moment().add(1, 'days')];  
  ranges: any = {
    Today: [moment(), moment()],
    Yesterday: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last Month': [moment().subtract(1, 'month').startOf('month'),
                   moment().subtract(1, 'month').endOf('month')],
    'Last Year': [moment().subtract(1, 'year').startOf('year'),
                   moment().subtract(1, 'year').endOf('year')],
    'Last 24 Hours': [moment().subtract(24, 'hours'),
    moment(new Date())]
  };

  ngOnChanges(changes: SimpleChanges) {
    this.selected = this.defaultValue;
    if (this.selected) {
    var start = new Date(this.defaultValue.startDate);
    start.setHours(0,0,0,0);
    var end = new Date(this.defaultValue.endDate);
    end.setHours(23,59,59,999);

    // console.log(moment.utc(start).valueOf());
    // console.log(moment.utc(end).valueOf());

    this.selectedValue.emit({
      startDate:  moment.utc(start).format(),
      endDate: moment.utc(end).format()
    });
  }

  }

  datesUpdated(range) {
    // First time date picker is sending null, So added condition to avoid.
    if (range.startDate != null && range.endDate != null) {
      var end = new Date(range.endDate);
      end.setHours(23,59,59,999);

      // console.log(moment.utc(range.startDate).valueOf());
      // console.log(moment.utc(end).valueOf());
      

      const startDate = moment.utc(range.startDate).format();
      const endDate = moment.utc(end).format();
      this.selectedValue.emit({ startDate: startDate, endDate: endDate });
    }
  }

  constructor() {
    this.opens = 'right';
    this.showClearButton = false;
    this.alwaysShowCalendars = true;
    this.keepCalendarOpeningWithRange = false;
    this.showRangeLabelOnInput = false;
  }

  rangeClicked(range) {
    console.log('[rangeClicked] range is : ', range);
  }
  
  ngOnInit() {
    this.selected = {startDate: moment().subtract(7, 'days'),
     endDate:  moment(new Date())};
  }
}