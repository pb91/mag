import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { VERSION, MatMenuTrigger } from '@angular/material';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  @Input() json;
  constructor() { }
  version = VERSION;

  data: any[] = [];
  item: any = "";
//  'email', 'address', 'buildings', 'departments',
  displayedColumns: string[] = ['userId', 'contact', 'email', 'buildings','departments', 'Description', 'action'];
  dataSource: any;


  updateTable(){
    this.data = this.json;
  }
 
  ngOnInit(): void {
    this.updateTable();
  }

  isSelected(item: any) {
    return this.item === item;
  }

}
