import { Component, OnInit, Output, EventEmitter, Input, SimpleChanges } from '@angular/core';
import * as mapboxgl from 'mapbox-gl';
// if not using * as, will cause MapboxGeocoder is undefined
import * as MapboxGeocoder from '@mapbox/mapbox-gl-geocoder';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-mapboxgeocoder',
  templateUrl: './mapboxgeocoder.component.html',
  styleUrls: ['./mapboxgeocoder.component.scss']
})
export class MapboxgeocoderComponent implements OnInit {
  storeData: any;
  map: mapboxgl.Map;
  selectedLink: number;
  @Output() selectedPosition = new EventEmitter();
  @Input() dataSource;
  @Input() plantName;
  constructor() { }

  ngOnInit() {
    // mapboxgl.accessToken = environment.mapBoxAccessToken;
    this.map = new mapboxgl.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/light-v9',
      center: [-96.020508, 40.096983], // [lng, lat]
      zoom: 3, // starting zoom
      scrollZoom: true,
    });

    this.map.on('load', (e) => {
      const geocoder = new MapboxGeocoder({
        accessToken: mapboxgl.accessToken,
        localGeocoder: coordinatesGeocoder,
        zoom: 4,
        placeholder: "Try: -40, 170 / Address",
        mapboxgl: mapboxgl
      });
      this.map.addControl(geocoder, 'top-left');
      geocoder.on('result', (ev) => {
       this.createPopUp(ev.result);
       this.flyToStore(ev.result);
      });
    });

   
    var coordinatesGeocoder = function (query) {
      // match anything which looks like a decimal degrees coordinate pair
      var matches = query.match(/^[ ]*(?:Lat: )?(-?\d+\.?\d*)[, ]+(?:Lng: )?(-?\d+\.?\d*)[ ]*$/i);
      if (!matches) {
      return null;
      }
       
      function coordinateFeature(lng, lat) {
      return {
      center: [lng, lat],
      geometry: {
      type: "Point",
      coordinates: [lng, lat]
      },
      place_name: 'Lat: ' + lat + ' Lng: ' + lng, // eslint-disable-line camelcase
      place_type: ['coordinate'], // eslint-disable-line camelcase
      properties: {},
      type: 'Feature'
      };
      }
       
      var coord1 = Number(matches[1]);
      var coord2 = Number(matches[2]);
      var geocodes = [];
       
      if (coord1 < -90 || coord1 > 90) {
      // must be lng, lat
      geocodes.push(coordinateFeature(coord1, coord2));
      }
       
      if (coord2 < -90 || coord2 > 90) {
      // must be lat, lng
      geocodes.push(coordinateFeature(coord2, coord1));
      }
       
      if (geocodes.length === 0) {
      // else could be either lng, lat or lat, lng
      geocodes.push(coordinateFeature(coord1, coord2));
      geocodes.push(coordinateFeature(coord2, coord1));
      }
       
      return geocodes;
      };

  }

  ngOnChanges(changes: SimpleChanges) {

    let marker = this.dataSource &&  {
      center: this.dataSource,
      geometry: {
      type: "Point",
      coordinates: this.dataSource
      },
      place_name: this.plantName, // eslint-disable-line camelcase
      properties: {},
      type: 'Feature'
      };

      marker && this.createPopUp(marker);
      marker && this.flyToStore(marker);

  }


  private roundValue(val) {
    return Math.round(val * 100) / 100;
  }

  flyToStore(currentFeature:any) {
    this.map.flyTo({
      center: currentFeature.geometry.coordinates,
      zoom: 10,
    });
  }

  createPopUp(currentFeature) {
    const popUps = document.getElementsByClassName('mapboxgl-popup');
    // Check if there is already a popup on the map and if so, remove it
    if (popUps[0]) {
      popUps[0].remove();
    }

    this.selectedPosition.emit(currentFeature.geometry.coordinates);
    const popup = new mapboxgl.Popup({ closeOnClick: false })
      .setLngLat(currentFeature.geometry.coordinates)
      .setHTML(
        `<h4>${currentFeature.place_name}</h4>`
      )
      .addTo(this.map);
  }

}
