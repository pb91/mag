import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtmltopdfComponent } from './htmltopdf.component';

describe('HtmltopdfComponent', () => {
  let component: HtmltopdfComponent;
  let fixture: ComponentFixture<HtmltopdfComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
