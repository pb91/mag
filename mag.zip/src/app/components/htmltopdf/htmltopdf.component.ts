import { Component, OnInit, Input, SimpleChanges, Output, ElementRef ,ViewChild,} from '@angular/core';
import {Router} from '@angular/router';
import * as jspdf from 'jspdf';
import * as html2canvas from 'html2canvas';
import { environment } from 'environments/environment';

import * as canvg from 'canvg';

@Component({
  selector: 'app-htmltopdf',
  templateUrl: './htmltopdf.component.html',
  styleUrls: ['./htmltopdf.component.scss']
})
export class HtmltopdfComponent implements OnInit {
  @Input() pageTitle : string;
  constructor(private router : Router,) { }

//  @Input() downloadFlag: boolean = false;

  ngOnChanges(changes: SimpleChanges) {
    //  if(this.downloadFlag) { this.captureScreen(); } 
  }


  isIEBrowser(){
    var ieBrowser;
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // Internet Explorer
    {
    //  console.log('IE Browser');
      ieBrowser = true;
    }
    else  //Other browser
    {
    //  console.log('Other Browser');
      ieBrowser = false;
    }
      return ieBrowser;
  };
  
  captureScreen() {
  
    if (this.isIEBrowser()) { // Check of IE browser 
      this.convertSVG2CANVAS('#pdfPage1');
      this.convertSVG2CANVAS('#pdfPage2')
    }
    var doc;
    var canvasIE = document.createElement('canvas');
    var logo = 'data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAKQAAAA3CAYAAACCR+GsAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAv3SURBVHhe7dxbqB1XGQfwPvnc+iAI4uVNpD4FBKXa+uCLFQ0WJASkD0JAK2pNETGV1kttowarBiSgYNVIC0bireClgqUVkVg00qbUhrSoqabWVDDElurobzvfyepknT1r7Zm9zy5n/vCx95611nf9r8vMnOSSZsKENcIGIa868Ejz6pseXIm8fv/DzWNPPdNarsc3f/VU87KPHs/qHktete/3zUs/crx5y+1/aA789K/No2f+1Vqvx3sPPz7Tl7MzT4z5+PdPt1qej6/e97denWp6+uln2xEvDGwQUvIv2XNsJYKQzz73n9ZyPRAkp3dMUexP/vD0ICIGkDpno0QQ6+y551pNF7D/x3/J9k/FpB3D/1Vig5AKkAtqGaLQQ7BsQu7+2qnmwdPnW2vDcfXBR7N2SuWXJ//ZarqAEkKq6ZCdaCuwckK+6LoHsgmuwTIJ+bGjf27OPfPv1tI4GErI3ASeCDmS2IKGbNewLEJudl4biqGEdMTpYiLkSPKBu/7YWlwcyyDkGH5thqGEvOz63150FpwIOZL85KF/tBb7YevMHcrHJqS70bG36RRDCUncVaeYCDmCuOureQzhrOmRSRdjEvLS/51paybJIhiDkG60UkyEHEGQq+b8iHj86q5eYxKyW+hlYAxCOnunk3kiZCvOMwhhC6mRL/38TPWjlGsOnczeldNDX85OiDOhsbkYQsQy5uOdzTAGIa3kPzj+dKtxIuSGvOSG3w2+Sy6B1cCqwKbk18I2rIhd/1PZ+ZWTbe96IDKCkL6ij0FIkt54TYRsxapixRKoG45SqX2F5fVg2FTQWiBK3wr57V//ve1dDkREZHkIMUnf843HNi3+WIT0+Cfe2kyETEShrT6lon/t2xmrQdhzM1S7tfYREpFqi2XVnZenHbecyPpZQkivbvte38ZiABMhBwhS1tzJWk1fd+vDz9NhxaxBHyGtNjWPehDNSpjTlYpHSN13zyWE5I8zc64tFWdnmAg5QJwFa4pvFeiSqfbBdR8ha+/4bck5PTnpTp4SQsZfFeXaUkFaKOk7EXITUcwaeIXX1XH5Jx6qOof2EbLmCKGojg05PTlxxkwnYCkhTUTbcq49xLZuBZ4IOUCOPHC2tVIGj22QOJW93/nTqIRU0FL06eqKXKbbdgkh421R96iSE8S1defaUpkImRHnrto77DHQR6I4i5WgpPipdGMuPUOCo0SuPRU7iEmba0tlImRGarfrsTDmCunx0LJXSCsjOH/22dI3d6zpykTIjCzyrG8MjHmGLL3DDnEerD1DBiE9s+2z5ZxZ8lfo24KQihxnOne+86T23Dcm+ghZu3LX/DME22mKGkJCia2SFXtbENLs7T5nW0f0ERIBah9F9d0Bk0WfQ6aErD2zbibbhpBbterVoI+QHtbbHmvg+DHvbYqVLUeAWkI6IpSsgH2yLQgpUe4IrQTzRBFqXvd5SG0V8kanT0omRB8hSe3bHxCTP1mTL5OTeGXozclmK24tIeWCzly/GtkWhCwVCa1ZSUu3RFLyb19KCGlFWxRi+83j52YE7XvjU0tI8I/Ncv1qZCJkIm5qalDybjYEkfpIUEJI27aJsGwsQkg7Qa5fjUyEbAURat7O2Oq8bsvpyglf+44DJYQkQ/4mshSLEBKRhtZkImQrdNVs18jV9+ytK33PN0sJWTt5FsEihLQDOKvm+pbKRMhWav+dCkLk9MyTviNBKSFJ7R9u1GIRQsLQxz8TIVupXXEWWQncNM17HlpDSMKHvnPpoliUkM63tTtHKi9oQo71n025U65ZbfQtvbvuyrwbEpOihpCk9m8kS1Hy5sUE68KE84gt179E/MncC5aQnFfAoeIPSGuKGn+4sIjMe/yDkIieG7eZKKJXimO/iULInL1UcoQEMeb6l4gVsvbh/1Zjg5C2OOQYKjUPw0H/nJ4SmbdCWnmRMjeuT8ZeVfjpIXzOVojHPDnwZdE41LTm9eg6YIOQEyasAyZCTlgrTIScsFaYCDlhrTARcsJaYSLkhLXClhDy/PnzzbFjx5pf3Htvc9/99zdnz174X72WgRMnTjSnn3ii/VWPof7G+GW9CQLxpX6xKe7UZrfPZjBW366/Z558ciZ9YINtelK43leHLSHkkSPfba686s3N5z5/oHn3tdc2e/bsucj5MXHb/s82P7vnnvZXPb51+HDzrl27Znred937Zz6XFCaAjMYti5By9+G9NzRHj36vvdLMcvuGK67Y8BMZ+MCXPvzo7rubT336lov83XfjjbO2PrDBn26ODh061Hz54MH2Vx5bQkiBfebW22bfzaQdO3ZUFbgWijGE8B/80PWzZAI/TaaSwgZixVkW6DepTRxgCxn5eerU///QxSKgT8mkQGbShUkZ+uaBP7l67tq9u5fQKyckZ60wiAi2wJ3vvGZ2/c4775rNzK/fccfst7ZIgE8rQCRUm8QTs864IEn0pce1uG6MhEi24oUu7a7pbyVNk9n1V98oTPgA4WsaR6zK2mK7Yl+71TZ0GsMfk1Qbv4jxrvEr7ZfqBtdNGmNBf6uha5E/v9nmh8lFh9/suOa7cXy1YMRq61N+tSF0mk92ET3yxVa0h11+yi3f3nr122Z92Ys4jE+xckLGCsMRSUBG3zktgQJwTQCW/XDY99dc/tpZAgUrOZLnU9IE+PZ37Jy133TzzbMVgg5CL7AbxdQeCWSPjhiXElIfiVQUuhTWp6QaF4k3+xFMHGzwhz1FQ2j9xGI3ELei0wXsGueMyhaf+Cg2n/TQjcR0s68f3eBTftgUfxDHZ8Tou7hMJoTkA70xSV7+ilfOYmSHv65HvPyS27379s2IqR3YM04dQJ7FqJ1O1+XFePbD59ghxeZaipUTUnIQi4NE0JImUbHaxKrgE1G0S4xABSShRB/FBGNDh36CBUkmQSAFI/rQa3xsx3yLZAck9o1vunKWRG1RxLBDF90SzzeF4xcoiAKLUx9k4gsEKenhV5ArCICgxgEdfFU8JAC+xhhASLkUt5iQj3/G+q1NLvkZiHa2+ALhr7j45TfwW57oCL+iJvzVz2+frolLvyCrsWxEjuWD/8akWDkhOWYmcYiAJMYqxknfoyhmnGQohBkqYO1BUkkTqO8KLmDXJERSFYp+iQwbkXSfSGwMpAQPmBRRLPro4Euqj/5ILL9jJYboxx99YqLESheE5ydRLGQi4ojigbF0Wym74CN9dIgrCEF/EF6fILT80R250A/UR57lBHnDNr1ii1r5ri+JyeXTOH2Ni0kK8mqsetqFomZB7sDKCckJiUuBcMgHAkESBXFdIJx3XaAKqSACtWJIrO8+9RF0BBlJ8UlHrE6K4ncQEtHAuNQ31/kbxwbwG8n4FcX1HXHZMQYZkExxFIxd12LlALbYFw89YhBzxOE3XfpF/KHbts+HFGzQr2/046v4ws+wCWLyWz85YhfkWA6MiQmnT6yWYmJHzH7rq584+GicWmqjPxDk109OxKd/2A2slJBBokhKgJMxqzgbifDd9h7Jl5Q4+0mSNrqIgCXrC7d/caYL/FYQMNasBvqDJIhjW2GDvjRB2q1IVk426FY8xKFXUV3nk4kQydaunza+WDnCR2TRHuddviiga8bzS39kki/j6UQAfugnh7EVBui49LIXz/wAueQ78tJD5IBuMSILfXLE14AxfGWTv3JgAWCTDmOdG/njt35+R25jAtPLHj/YoZcu7UFen93VfqWE5JAZLJAUUSzOatcPBClx0d9WghSgmIogmfpITCQokiP5Cux6qpcOCYPYpomk0xvQn1/0I04cGcA4pJRUfkswe64hUax6bBkTWxz4bRzEwZ+N8DHs0qNgdJswobu7w4BrQWLwyWd+BvSJPEdeUr/YiRUW8fSlg039gW+IFhOCX2E3amIsXa4bS6fr2tkTh7a0JoGVb9mRsC7MfIXqtqe/c2MFTwLd/kQiutddk0zElDwJl6QutAVJjEnBLr/T6/rl/AlfAul3Y7qxs+taqrsba4qufuj+hq6O7rj0Ox/0nddnXls6vpujbmyBlRNynYCEVkWfVgNJmrC12NaENHtju7bdTth6bGtCTlg/TIScsEZomv8CiNTsNATo0YgAAAAASUVORK5CYII=';
    html2canvas(document.getElementById('pdfPage1'), {
      useCORS: true,
      allowTaint: false,
      logging: true,
    }).then(canvas => {
      // Few necessary setting options
      doc = new jspdf('p', 'mm', 'a4');
      var imgWidth = 210;
      var pageHeight = 295;
      // var pageHeight = 320;  
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var position = 0;
      let imgData;
      if (this.isIEBrowser()) { // Check of IE browser 
        imgData = canvas.toDataURL('image/JPEG');
      }
      else{
        
        imgData = canvas.toDataURL('image/jpeg');
      }
      console.log("imgData",imgData)

      // let imgData = canvas.toDataURL('image/png', 1.0);
      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight, null, 'FAST');
      doc.setFontSize(8);

      var splitTitle = doc.splitTextToSize(environment.pdfCopyRightMsg, 100);
      doc.text(105,281, splitTitle);

      doc.addImage(logo, 'PNG', 5, 275, 45, 13);
    });
    html2canvas(document.getElementById('pdfPage2'), {
      useCORS: true,
      allowTaint: false,
      logging: true,
    }).then(canvas => {
      // Few necessary setting options
      var imgWidth = 210;
      var pageHeight = 295;
      // var pageHeight = 320;  
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var position = 0;
      let imgData = canvas.toDataURL('image/jpeg', 1.0);
      doc.addPage();
      // doc.text(150,285, 'page ' + "Logo");
      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight, null, 'FAST');
      doc.setFontSize(8);
      var splitTitle = doc.splitTextToSize(environment.pdfCopyRightMsg, 100);
      doc.text(105,281, splitTitle);
      doc.addImage(logo, 'PNG', 5, 275, 45, 13);
      var filename = 'download.pdf';
      if(this.pageTitle) {
        filename = this.pageTitle.replace(/\s+/g, '').toLowerCase() + ".pdf";
      }

      doc.save(filename);

      $("#pdfPage1").find('.screenShotTempCanvas').remove();
      $("#pdfPage1").find('.tempHide').show().removeClass('tempHide');
      $("#pdfPage2").find('.screenShotTempCanvas').remove();
      $("#pdfPage2").find('.tempHide').show().removeClass('tempHide');
    });

  }


  convertSVG2CANVAS(ele){
    var svgElements = $(ele).find('svg');
    var self = this;
    //replace all svgs with a temp canvas
    svgElements.each(function() {
      var canvas, xml;

      // canvg doesn't cope very well with em font sizes so find the calculated size in pixels and replace it in the element.
      $.each($(this).find('[style*=em]'), function(index, el) {
        $(this).css('font-size', self.getStyle(el, 'font-size'));
      });

      canvas = document.createElement("canvas");
      canvas.className = "screenShotTempCanvas";
      //convert SVG into a XML string
      xml = (new XMLSerializer()).serializeToString(this);

      // Removing the name space as IE throws an error
      xml = xml.replace(/xmlns=\"http:\/\/www\.w3\.org\/2000\/svg\"/, '');

      //draw the SVG onto a canvas
      canvg(canvas, xml);
      $(canvas).insertAfter(this);
      //hide the SVG element
      ////this.className = "tempHide";
      $(this).attr('class', 'tempHide');
      $(this).hide();
    });


  }

   getStyle(el, styleProp) {
    var camelize = function(str) {
      return str.replace(/\-(\w)/g, function(str, letter) {
        return letter.toUpperCase();
      });
    };
  
    if (el.currentStyle) {
      return el.currentStyle[camelize(styleProp)];
    } else if (document.defaultView && document.defaultView.getComputedStyle) {
      return document.defaultView.getComputedStyle(el, null)
        .getPropertyValue(styleProp);
    } else {
      return el.style[camelize(styleProp)];
    }
  }

  
  ngOnInit() {
   // this.renderPDF('sample.pdf', document.getElementById('magneto-app'));
  }

}
