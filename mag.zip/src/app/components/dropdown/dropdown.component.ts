import { Component, OnInit, Input, SimpleChanges, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatOption } from '@angular/material';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import * as _ from 'lodash';
import { copyStyles } from '@angular/animations/browser/src/util';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent implements OnInit {
  @Input() dataSource;
  @Input() placeHolder: string = "Select";
  @Output() selectedOptionChange = new EventEmitter();
  @Input() selectAll: boolean;
  @Input() pageDetails: string;
  public selectedOption: any;
  searchUserForm: FormGroup;
  public placeHolderText: string;
  @ViewChild('allSelected') private allSelected: MatOption;

  selected2: any;
  constructor(private fb: FormBuilder) {
  }

  onInputChange($event) {
    //console.log(this.selectedOption);
    if (!$event) {
      this.selectedOptionChange.emit(this.selectedOption);   // Broadcast Event
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    this.placeHolderText = this.placeHolder;

    if (this.pageDetails != 'equipment' && this.pageDetails != 'global') {
      this.dataSource = _.sortBy(this.dataSource, [function (o) { return o.name; }]);
    } 

    if (this.pageDetails == 'equipment') {
      this.selectedOption = this.dataSource && _.hasIn(this.dataSource[0], 'id') ? this.dataSource[0].id : null;
    }
    if (this.pageDetails == 'global') {
      this.selectedOption = this.dataSource && _.hasIn(this.dataSource[0], 'name') ? this.dataSource[0].name : null;
    }

    this.setSelectedAll()

  }
  
  ngOnInit() {
    this.searchUserForm = this.fb.group({
      userType: new FormControl('')
    });
    localStorage.setItem('initialSelect', '1');
  }

  compareWithFunc(a:string, b:[]) {
    return a === b['id'];
  }

  getSelectedItem(all) {

    if (this.allSelected.selected) {
    
      this.allSelected.deselect();
      this.selectedOption = this.searchUserForm.controls.userType.value;
      return false;
    }
    // Checking if all check box is selected or not, to enable all checkbox.
    if (this.searchUserForm.controls.userType.value.length == this.dataSource.length) {
      this.allSelected.select();
      this.searchUserForm.controls.userType
      .patchValue([...this.dataSource.map(item =>{  
        return item.id;
      }), 0]);
      this.selectedOption = this.searchUserForm.controls.userType.value;
    }
    this.selectedOption = this.searchUserForm.controls.userType.value;
  }

  toggleAllSelection($event) {
    let selectedArray = [];
    if (this.allSelected.selected) {
      this.searchUserForm.controls.userType
        .patchValue([...this.dataSource.map(item =>{          
          selectedArray.push(item.id);
          return item.id;
        }), 0]);
      this.selectedOption = selectedArray;
    } else {
      this.searchUserForm.controls.userType.patchValue([]);
      this.selectedOption = null;
    }
  }

  setSelectedAll() {
    if (localStorage.getItem('initialSelect') == '1' && this.selectAll == true){
      if(this.searchUserForm && this.searchUserForm.controls.userType){
        this.searchUserForm.controls.userType
        .patchValue([...this.dataSource.map(item => item.id), 0]);
        this.selectedOption = this.searchUserForm.controls.userType.value
        localStorage.setItem('initialSelect', '0');
      }     
    }
  }
}