import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropdownComponent } from './dropdown.component';

describe('DropdownComponent', () => {
  let component: DropdownComponent;
  let fixture: ComponentFixture<DropdownComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
