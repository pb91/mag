import { Component, OnInit, OnDestroy, SimpleChanges, OnChanges, Input } from '@angular/core';
import { AuthenticationService } from '@appServices/authentication.service';
import { NavigationService } from '@appServices/navigation.service';
import { ActivatedRoute } from '@angular/router';
import { User } from '@appModels/user';
import { Router } from '@angular/router';
import {MatDialog, MatDialogRef} from '@angular/material';
import * as fromStore from './../../globalStore';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnChanges {
  @Input() pageTitle : string;
  @Input() subTitle : string;
  currentUser: User;

  constructor(
    public router: Router,
    public dialog: MatDialog,
    private _navigationService: NavigationService,
    private route: ActivatedRoute,
    public authenticationService: AuthenticationService) {
  }

  onMenuClicked() {
    this._navigationService.toggleMenu();
  }

  ngOnChanges(changes: SimpleChanges) {
   
  }

  changePassword(){
    this.router.navigate(['/changepassword']);
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(LogoutConfirmDialog);    
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  ngOnInit() {
    this.authenticationService.currentUser.subscribe(x => (this.currentUser = x
      
      )
    );
  }

  // this.pageTitle = this.route.snapshot.data
}


@Component({
  selector: 'logout-confirm-dialog',
  templateUrl: 'logout-confirm-dialog.html',
})
export class LogoutConfirmDialog {
  logout = false;
  hovering = false;
  open = false;
  public loading: boolean;
  isDisabled: boolean;
  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<LogoutConfirmDialog>,
    private store: Store<fromStore.ContainerState>,
    private authenticationService: AuthenticationService,
    private router: Router,
  ) {
    dialogRef.disableClose = true;
  }

    cancelLogout(): void {
      this.dialogRef.close();
    }
    onLogoutClick() {      
      this.isDisabled = true;
      this.loading = true;
      this.store.dispatch(new fromStore.ResetPreference());
      this.authenticationService.logout().subscribe(state => {
        this.loading = false;
        this.dialogRef.close();
        this.router.navigateByUrl('sign-in');
      }, error => {
        this.isDisabled = false;
        this.loading = false;
        this.dialogRef.close();
      });   
    }
}