import { Component, OnInit, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-progressbar',
  templateUrl: './progressbar.component.html',
  styleUrls: ['./progressbar.component.scss']
})
export class ProgressbarComponent implements OnInit {
  @Input() loadingFlag : boolean;

  showHideFlag : boolean;
  constructor() { }

  ngOnChanges(changes: SimpleChanges) {
    this.showHideFlag  = this.loadingFlag
  }

  ngOnInit() {
  }

}
