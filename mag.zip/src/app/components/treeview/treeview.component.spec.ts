import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreeviewComponent } from './treeview.component';
let finalArray = {
  Buildings: {},
  Departments: {},
  Equipments: {},
  Devices: {}
};
describe('TreeviewComponent', () => {
  let component: TreeviewComponent;
  let fixture: ComponentFixture<TreeviewComponent>;

  beforeEach(() => {
    component = new TreeviewComponent();
  });
  it('Should be pass Imput Array Object', () => {
    component.dataSource = this.finalArray;
  });
});

/*
-------Test Cases-----
Test Case 1: Check results on putting of Inputs to Treeview and this will show all list of device list like Buildings, Departments, Equipments, Devices
Test Case 3: Check this tree with like menu and submenu.
Test Case 2: Check with click on any of this device list and this will show details of that perticular device
*/ 