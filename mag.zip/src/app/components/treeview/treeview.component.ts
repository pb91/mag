import {NestedTreeControl} from '@angular/cdk/tree';
import {Component, Injectable, OnInit, Input, Output, EventEmitter, SimpleChanges} from '@angular/core';
import {MatTreeNestedDataSource} from '@angular/material/tree';
import { DataSource } from '@angular/cdk/table';

/**
 * Json node data with nested structure. Each node has a filename and a value or a list of children
 */
export class FileNode {
  children: FileNode[];
  filename: string;
  type: any;
}
/**
/**
 * The Json tree data in string. The data could be parsed into Json object
 */

@Component({
  selector: 'app-treeview',
  templateUrl: './treeview.component.html',
  styleUrls: ['./treeview.component.scss']
})
export class TreeviewComponent implements OnInit {
  @Input() dataSource = {};
  @Output() leafNodeSelected = new EventEmitter();

  ngOnInit() {
    
  }

  ngOnChanges(changes: SimpleChanges) {
    this.nestedDataSource.data = this.buildFileTree(this.dataSource, 0);
  }


  nestedTreeControl: NestedTreeControl<FileNode>;
  nestedDataSource: MatTreeNestedDataSource<FileNode>;

  constructor() {
    this.nestedTreeControl = new NestedTreeControl<FileNode>(this._getChildren);
    this.nestedDataSource = new MatTreeNestedDataSource();
  }

  hasNestedChild = (_: number, nodeData: FileNode) => !nodeData.type;

  private _getChildren = (node: FileNode) => node.children;


  buildFileTree(obj: {[key: string]: any}, level: number): FileNode[] {
    return Object.keys(obj).reduce<FileNode[]>((accumulator, key) => {
      const value = obj[key];
      const node = new FileNode();
      node.filename = key;
      if (value != null) {
        if (typeof value === 'object') {
          node.children = this.buildFileTree(value, level + 1);
        } else {
          node.type = value;
        }
      }
      return accumulator.concat(node);
    }, []);
  }

  onLeafNodeClick(id: string, name: string) {
    this.leafNodeSelected.emit({ id: name, name: id });
  }

}

