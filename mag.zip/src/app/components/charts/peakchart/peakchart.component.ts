import { Component, OnInit, SimpleChanges, Input} from '@angular/core';
import { UtilityService  } from '../../../shared/utility.service';

// Highchart Imports
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
import HC_boost from 'highcharts/modules/boost';
import NoDataToDisplay  from 'highcharts/modules/no-data-to-display';
HC_exporting(Highcharts);
HC_boost(Highcharts);
NoDataToDisplay(Highcharts);
import * as $ from 'jquery';
// Utility Imports
import * as _ from 'lodash';
import * as moment from 'moment';
import { Title } from '@angular/platform-browser';
import { Observable , Subscription , } from 'rxjs';
import {SidebarResizeService} from '../../../shared/sidebar-resize.service'

@Component({
  selector: 'app-peakchart',
  templateUrl: './peakchart.component.html',
  styleUrls: ['./peakchart.component.scss']
})
export class PeakchartComponent implements OnInit {

  chartOptions: any;
  Highcharts = Highcharts; // required
  updateFlag = false; // optional boolean
  oneToOneFlag = true; // optional boolean, defaults to false
  chartConstructor = 'chart'; // optional string, defaults to 'chart'
  chart;
  updateFromInput = false;
  yaxis : any ;
  yaxisVal = " "

  // Input paramenter
  @Input() dataSource;
  @Input() chartTitle : string = '';
  @Input() chartSubTitle : string = '';
  @Input() yAxisText : string = '';
  @Input() Load:any ;
  @Input() toggle : any;
  subscription: Subscription;

  constructor(private utils: UtilityService,
    private SidebarResizeService : SidebarResizeService) {
    const self = this;
    this.chartOptions =
    {
      chart: {
        zoomType: 'x',
        events: {
          load: function () {
            if (!this.renderer.forExport) {
              self.chart = this;
            }
          }
        },
      },
      title: {
        text: "Power Demand (kW) and Peak Demand (kW)"
      },
      yAxis: {
        title: {
            text: ''
        },
        labels: {
          formatter: function (that) {
              self.yaxis = this;
              return  `${this.value} ${self.yaxisVal}` 
          }
        },
        plotLines: [{
            value: 348.31,
            color: 'red',
            dashStyle: 'shortdash',
            width: 2,
            label: {
                text: 'EQPPLPXG01SWG'
            }
        }, {
            value: 68,
            color: 'red',
            dashStyle: 'shortdash',
            width: 2,
            label: {
                text: 'EQPAAPXG01SWG'
            }
        }]
    },
      subtitle: {
        text: this.chartSubTitle
      },
      tooltip: {
        valueDecimals: 2
      },
      credits: {
        enabled: false
      },
      exporting: {
        enabled: false,
        buttons: {
            contextButton: {
                menuItems: ["downloadPNG", "downloadJPEG", "downloadPDF", "downloadSVG"]
            }
        }
      },
      xAxis: {
        events: {
          afterSetExtremes: function() {
            $('.highcharts-button').show();
          }
        },
        type: 'datetime',
        dateTimeLabelFormats: {
          month: '%b %e'
        }
      },
      series: []
    };


    this.subscription = this.SidebarResizeService.getMessage().subscribe(message => {
      if (message) {

        /// Settimeout is required to get an instance of this.chart which will be availbale once it is loaded in dom. 
       setTimeout(() => {
          this.chart.reflow();
       }, 0)
      } 
    });

   }

  ngOnInit() {
    
 
  }

  formatSeries(data, type, yAxis, displayType) {
    let dataSeries = [];
    let category = [];
    _.forEach(data.value, (value, key) => {

      var gmtDateTime = moment.utc(value.eventAt);
      var local = gmtDateTime.local().valueOf();

      dataSeries[key] = [local, parseInt(value.value)];
      category.push(moment(local).valueOf());
    });
    dataSeries.sort();
    let label = displayType == "spline" ?  `${data.label} - Cost` : data.label;
    return  {name: label, type: type, data: dataSeries};
  }

  formatData(seriesData) {
    let formattedData = [];
    let source = seriesData;
    let kpiName = _.hasIn(source, 'kpiName') && source.kpiName;
    let unit = source ? source.unit : '';
    switch (kpiName) {
      case 'powerDemand': {
        let chatTitle = this.utils.displayChartTitle("demandChart");
        this.yaxisVal = chatTitle.units;
        let costData = [];
        const displayType = 'line';
        _.forEach(source.value, (value, key) => {
          costData[key] = this.formatSeries(value, displayType, 1, displayType);
        });
        return costData;
      }
      case 'PeakDemand': {
        let plotLines = [];
        let value = source.value.value && source.value.value.toFixed(2);
          plotLines.push({
            value: source.value.value,
            color: 'red',
            dashStyle: 'shortdash',
            width: 2,
            label: {
                text: `Peak Demand ${value}`
            }
        });
        this.chartOptions.yAxis.plotLines  = plotLines;
      }
      default: {
        return [];
      }
    }
  }

  mailLoop(dataSource) {
    let contructData = [];
    _.forEach(dataSource, (value, key) => {
      contructData[key] = this.formatData(value);
    });
    return contructData;
  }

  ngOnChanges(changes: SimpleChanges) {

    if (this.dataSource) {   
      this.chartOptions.series = [];  

      $('.highcharts-button').hide(); 
      $('.highcharts-button').click();
      let dataSeries = this.mailLoop(this.dataSource);

      let mainData = [];
      _.forEach(dataSeries, (value, pkey) => {
        _.forEach(value, (value, ckey) => {
          mainData.push(value);
        });
      });
      this.chartOptions.series = mainData;
      this.updateFlag = true;
    } else {
      this.chartOptions.series = [];
    }
    

    setTimeout(()=>{
      if(this.Load){
        this.chart.showLoading();
        this.chart.hideNoData();
      } else {
        if(this.yaxis && _.hasIn(this.yaxis, 'axis')) {
          this.yaxis.axis.labelFormatter();
        }

        this.chart.hideLoading();
        if(_.size(this.chartOptions.series) == 0){
          this.chart.showNoData();
        }else{
          this.chart.hideNoData()
        }
      }
      
      
      this.chart.reflow();
      this.updateFlag = true;
    })
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}

}
