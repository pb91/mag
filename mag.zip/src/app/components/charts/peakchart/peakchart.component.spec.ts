import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeakchartComponent } from './peakchart.component';

describe('PeakchartComponent', () => {
  let component: PeakchartComponent;
  let fixture: ComponentFixture<PeakchartComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
