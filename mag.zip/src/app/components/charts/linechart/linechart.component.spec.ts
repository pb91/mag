import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinechartComponent } from './linechart.component';

describe('LinechartComponent', () => {
  let component: LinechartComponent;
  let fixture: ComponentFixture<LinechartComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
