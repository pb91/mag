import { Component, OnInit, SimpleChanges, Input} from '@angular/core';

// Highchart Imports
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
import HC_boost from 'highcharts/modules/boost';
import NoDataToDisplay  from 'highcharts/modules/no-data-to-display';
HC_exporting(Highcharts);
HC_boost(Highcharts);
NoDataToDisplay(Highcharts);
import * as $ from 'jquery';


// Utility Imports
import * as _ from 'lodash';
import * as moment from 'moment';
import { Title } from '@angular/platform-browser';
import { Observable , Subscription , } from 'rxjs';
import {SidebarResizeService} from '../../../shared/sidebar-resize.service'

Highcharts.setOptions({
  global: {
    useUTC: true
  }
});

@Component({
  selector: 'app-linechart',
  templateUrl: './linechart.component.html',
  styleUrls: ['./linechart.component.scss']
})
export class LinechartComponent implements OnInit {

  chartOptions: any;
  Highcharts = Highcharts; // required
  updateFlag = false; // optional boolean
  oneToOneFlag = true; // optional boolean, defaults to false
  chartConstructor = 'chart'; // optional string, defaults to 'chart'
  chart;
  updateFromInput = false;
  yaxis : any ;
  yaxisVal = " "
  subscription: Subscription;

  // Input paramenter
  @Input() dataSource;
  @Input() chartTitle : string = '';
  @Input() chartSubTitle : string = '';
  @Input() yAxisText : string = '';
  @Input() chartType : string = '';
  @Input() Load:any ;
  @Input() unit : string;
  @Input() interval: string;
  @Input() toggle : any;

  constructor( private SidebarResizeService : SidebarResizeService) {
    const self = this;
    this.chartOptions =
      {
        chart: {
          zoomType: 'x',
          events: {
            load: function () {
              if (!this.renderer.forExport) {
                self.chart = this;
              }
            }
          },
        },
        title: {
          text: this.chartTitle
        },
        exporting: {
          enabled: false,
          buttons: {
              contextButton: {
                  menuItems: ["downloadPNG", "downloadJPEG", "downloadPDF", "downloadSVG"]
              }
          }
        },
        credits: {
          enabled: false
        },
        plotOptions: {
          series: {
            turboThreshold: 0
          }
        },
        yAxis: {
          title: {
            text: this.yAxisText
          },
          labels: {
            formatter: function (that) {
                self.yaxis = this;
                return  `${this.value} ${self.yaxisVal}` 
            }
          },
        },
        subtitle: {
          text: this.chartSubTitle
        },
        tooltip: {
          valueDecimals: 2
        },
        xAxis: {
          events: {
            afterSetExtremes: function() {
              $('.highcharts-button').show();
            }
          },
          type: 'datetime',
          dateTimeLabelFormats: {
            millisecond: '%e %b %H:%M',
            month: '%b %e',
            day: '%e %b',
            week: '%e %b',
          }
        },
        series: []
      };


      this.subscription = this.SidebarResizeService.getMessage().subscribe(message => {
        if (message) {
  
          /// Settimeout is required to get an instance of this.chart which will be availbale once it is loaded in dom. 
         setTimeout(() => {
            this.chart.reflow();
         }, 0)
        } 
      });
   }
  
  ngOnInit() {

  }

  // This is to format a data
  formatData(seriesData, chartType) {
    let dataSeries = [];
    let type = chartType ? chartType : 'area';
    _.forEach(seriesData, function(items, keyp) {
          let data = [];
      _.forEach(items.value, function(items, keyc) {
        var gmtDateTime = moment.utc(items.eventAt);
        var local = gmtDateTime.local().valueOf();
        data[keyc] = [local, parseInt(items.value)];
      });
       data.sort();
       
        dataSeries[keyp] = {name:items.label, type: type, data: data};
    });
    var result = _.sortBy(dataSeries, 'name');
    return result;
  }

  ngOnChanges(changes: SimpleChanges) {
    $('.highcharts-button').hide();
    $('.highcharts-button').click();
    if (this.dataSource) {
      this.chartOptions.series = this.formatData(this.dataSource, this.chartType);
    } else {
      this.chartOptions.series = [];
    }
    setTimeout(()=>{
      if(this.Load){
        this.chart.showLoading();
        this.chart.hideNoData();
      } else {
        if(this.yaxis && _.hasIn(this.yaxis, 'axis')) {
          this.yaxisVal = this.unit;
          this.yaxis.axis.labelFormatter();
        }
      //  this.chartOptions.xAxis[0].setExtremes(null,null);
        this.chart.hideLoading();
        if(_.size( this.chartOptions.series) == 0){ this.chart.showNoData();}else{
          this.chart.hideNoData()
        }
      }
      this.chart.setTitle({text:  this.chartTitle});
      this.chart.reflow();
    })
    this.updateFlag = true;
  }


  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}

}