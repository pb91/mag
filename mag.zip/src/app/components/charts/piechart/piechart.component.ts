import { Component, OnInit, Input, SimpleChanges, AfterViewInit } from '@angular/core';
import { UtilityService  } from '../../../shared/utility.service';

// Highchart Imports
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
import HC_boost from 'highcharts/modules/boost';
import NoDataToDisplay from 'highcharts/modules/no-data-to-display';

Highcharts.setOptions({
  lang: {
      thousandsSep: ','
  }
});

HC_exporting(Highcharts);
HC_boost(Highcharts);
NoDataToDisplay(Highcharts);


import * as HighchartsMore from "highcharts/highcharts-more";
import * as HighchartsExporting from "highcharts/modules/exporting";
import { Observable , Subscription , } from 'rxjs';
import {SidebarResizeService} from '../../../shared/sidebar-resize.service'

// Utility Imports
import * as _ from 'lodash';
import * as moment from 'moment';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-piechart',
  templateUrl: './piechart.component.html',
  styleUrls: ['./piechart.component.scss']
})
export class PiechartComponent implements OnInit, AfterViewInit {

  chartOptions: any;
  Highcharts = Highcharts; // required

  updateFlag = false; // optional boolean
  oneToOneFlag = true; // optional boolean, defaults to false
  chartConstructor = 'chart'; // optional string, defaults to 'chart'

  chart;
  updateFromInput = false;
  // Input paramenter
  @Input() dataSource;
  @Input() chartTitle: string = '';
  @Input() seriesName: string = '';
  @Input() Load: boolean ;
  @Input() toggle : any;
  public chartTheme;
  subscription: Subscription;



  constructor(private utils: UtilityService ,   private SidebarResizeService : SidebarResizeService) {
    const self = this;
    this.chartOptions = {
      lang: {
        thousandsSep: ','
      },
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        events: {
          load: function () {
            if (!this.renderer.forExport) {
              self.chart = this;
            }
          }
        },
      },
      title: {
        text: this.chartTitle
      },
      exporting: {
        enabled: false,
        buttons: {
            contextButton: {
                menuItems: ["downloadPNG", "downloadJPEG", "downloadPDF", "downloadSVG"]
            }
        }
      },
      tooltip: {
        pointFormat: '<b>{point.y}</b>'
      },
      xAxis: {
        type: 'datetime'
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        series: {
          cursor: 'pointer',
          point: {
            events: {
              click: function () {
              }
            }
          }
        },
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: true,
            format: '<b>{point.name}</b>: {point.y} <br> Percentage : {point.percentage:.1f} %'
          },
          showInLegend: true
        }
      },
      series: [
        {
          name: this.seriesName,
          colorByPoint: true, 
          data: []
        }
      ]
    };

    
    this.subscription = this.SidebarResizeService.getMessage().subscribe(message => {
      if (message) {

        /// Settimeout is required to get an instance of this.chart which will be availbale once it is loaded in dom. 
       setTimeout(() => {
          this.chart.reflow();
       }, 0)
      } 
    });
  }
  ngOnInit() {
  
    this.chartTheme = {
      colors: [
        "#058DC7",
        "#50B432",
        "#ED561B",
        "#DDDF00",
        "#24CBE5",
        "#64E572",
        "#FF9655",
        "#FFF263",
        "#6AF9C4"
      ],
      chart: {
        backgroundColor: "#efefef"
      },
      title: {
        style: {
          color: "red",
          font: 'bold 20px "Trebuchet MS", Verdana, sans-serif'
        }
      },
      subtitle: {
        style: {
          color: "blue",
          font: 'bold 10px "Trebuchet MS", Verdana, sans-serif'
        }
      },
      tooltip: {
        valueDecimals: 2
      },
      legend: {
        itemStyle: {
          font: "9pt Trebuchet MS, Verdana, sans-serif",
          color: "black"
        },
        itemHoverStyle: {
          color: "gray"
        }
      }
    };

  }


  ngAfterViewInit() {
    
    //  this.chartOptions.options.lang.noData = 'No data to display';
  }

  // This is to format a data
  // TODO: Data format need to implement dynamically
  formatData(seriesData) {
    let self = this;
    if(seriesData instanceof Array) {
      let formattedData = [];

      seriesData.forEach((value) => {
        let data = self.utils.roundNumber(value.value, 2);
        formattedData.push({'name': value.label, 'y': data})
      }); 
      var result = _.sortBy(formattedData, 'name');
      return result;
    }
    return [];
  }

  ngOnChanges(changes: SimpleChanges) {
    let self = this;
    if (this.dataSource) {
        let Type = _.hasIn(this.dataSource, 'Type') && this.dataSource["Type"];

      if (Type == 'status') {
        let formattedData = [];
        if (this.dataSource['Results'] instanceof Array) {
          this.dataSource['Results'].forEach(function (value) {
            let data = self.utils.roundNumber(value.value, 3);
            formattedData.push({ 'name': value.Label, 'y': data })
          });
        }
        this.chartOptions.series[0].data = formattedData;
      } else {
        this.chartOptions.series[0].data = this.formatData(this.dataSource);
      }

    

    }else{
      this.chartOptions.series[0].data = [];
    }
    
    setTimeout(()=>{
      if(this.Load){
        this.chart.showLoading();
        this.chart.hideNoData();
      }else{
        this.chart.hideLoading();
        if(_.size( this.chartOptions.series[0].data) == 0){
           this.chart.showNoData();
        }
        else{
          this.chart.hideNoData()
        }
      }
      this.chart.setTitle({text:  this.chartTitle});
      this.chart.reflow();
    })
   
    this.updateFlag = true;
  }


  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}


}
