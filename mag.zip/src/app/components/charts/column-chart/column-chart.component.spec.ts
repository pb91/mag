import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColumnChartComponent } from './column-chart.component';

describe('ColumnChartComponent', () => {
  let component: ColumnChartComponent;
  let fixture: ComponentFixture<ColumnChartComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
