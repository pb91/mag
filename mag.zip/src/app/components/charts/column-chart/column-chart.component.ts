import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { UtilityService  } from '../../../shared/utility.service';
import { Observable , Subscription , } from 'rxjs';
import {SidebarResizeService} from '../../../shared/sidebar-resize.service'

// Highchart Imports
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
import HC_boost from 'highcharts/modules/boost';
import NoDataToDisplay  from 'highcharts/modules/no-data-to-display';
HC_exporting(Highcharts);
HC_boost(Highcharts);
NoDataToDisplay(Highcharts);
import * as $ from 'jquery';

@Component({
  selector: 'app-column-chart',
  templateUrl: './column-chart.component.html',
  styleUrls: ['./column-chart.component.scss']
})
export class ColumnChartComponent implements OnInit{

  chartOptions: any;
  Highcharts = Highcharts; // required
  updateFlag = false; // optional boolean
  oneToOneFlag = true; // optional boolean, defaults to false
  chartConstructor = 'chart'; // optional string, defaults to 'chart'
  categories: any

  // Input paramenter
  @Input() dataSource;
  @Input() chartTitle: string = '';
  @Input() Load:any;
  @Input() toggle : any;
 
  chartTitleText: string;

  chart;
  updateFromInput = false;

  chartCallback;
  subscription: Subscription;


  constructor(private SidebarResizeService : SidebarResizeService) {
  
    const self = this;
    self.chartOptions = {
      chart: {
        type: 'column',
        zoomType: 'x',
        events: {
          load: function() {
            if (!this.renderer.forExport) {
              self.chart = this;
            }
          }
        },
        options : {
          lang : {
            noData : "No Data"
          }
        },
      },
      title: {
        text: this.chartTitle
      },

      xAxis: {
        events: {
          afterSetExtremes: function() {
            $('.highcharts-button').show();
          }
        }, 
        title: {
          text: 'Device'
      },
        categories: [],
        labels:
        {
          step: 1,
           //rotation: 270,
          style: {
            textOverflow: 'ellipsis',
            cursor: 'pointer'
          }
        }
      },
      yAxis: {
        allowDecimals: false,
        title: {
          text: 'Availability & Utilization'
        }
      },
      credits: {
        enabled: false
    },
      tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b><br/>',
        shared : true,
        valueDecimals: 2
      },
      exporting: {
        enabled: false,
        buttons: {
            contextButton: {
                menuItems: ["downloadPNG", "downloadJPEG", "downloadPDF", "downloadSVG"]
            }
        }
      },
      plotOptions: {
        bar: {
          depth: 40
        }
      },
      series: []
    };

    this.subscription = this.SidebarResizeService.getMessage().subscribe(message => {
      if (message) {

        /// Settimeout is required to get an instance of this.chart which will be availbale once it is loaded in dom. 
       setTimeout(() => {
          this.chart.reflow();
       }, 0)
      } 
    });

  }
  ngOnInit() {

  }

  formatData(seriesData) {
    let dataSeries = {'series' : [] , 'categories' : [] };
    let dataUtil = [];
    let dataAvail = [];
    let category = [];
    let source = _.hasIn(seriesData, 'summaryTag') && seriesData.summaryTag;
    _.forEach(source.value, (value, key) => {
      _.forEach(value.response, (_value, _key) => {
        dataUtil.push(_value.utilization);
        dataAvail.push(_value.availability)
        category.push(_value.deviceID);
      });

    });

    if(dataAvail.length || dataUtil.length){
      dataSeries.series = [{name : 'Availability' , data : dataAvail },{name : 'Utilization' , data : dataUtil}];
    }

    dataSeries.categories = category;
    return  dataSeries ;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.dataSource) {
      $('.highcharts-button').hide();
      $('.highcharts-button').click();
      const dataSeries = this.formatData(this.dataSource);
      this.chartOptions.title.text = this.chartTitle;
      this.chartOptions.series = dataSeries && dataSeries.series ; 
      if( dataSeries && (_.size(dataSeries.categories) >10)){
        this.chartOptions.xAxis.labels.rotation = 270;
      }
      this.chartOptions.xAxis.categories = dataSeries && dataSeries.categories
      this.updateFlag = true;
    }else{
      this.chartOptions.series = [] ; 
      this.chartOptions.xAxis.categories = [];
    }
    setTimeout(()=>{
      if(this.Load){
        this.chart.showLoading();
        this.chart.hideNoData();
      }else{
        this.chart.hideLoading();
        if(_.size( this.chartOptions.series) == 0){ 
          this.chart.showNoData();
        } else {
          this.chart.hideNoData()
        }
      }
      this.chart.setTitle({text:  this.chartTitle});
      this.chart.reflow();
    })
  }


  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}
}
