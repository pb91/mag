import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { UtilityService } from '../../../shared/utility.service';
import * as $ from 'jquery';
// Highchart Imports
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
import HC_boost from 'highcharts/modules/boost';
import NoDataToDisplay from 'highcharts/modules/no-data-to-display';
import { Observable , Subscription , } from 'rxjs';

import {SidebarResizeService} from '../../../shared/sidebar-resize.service'

Highcharts.setOptions({
  lang: {
      thousandsSep: ','
  },
  colors: [
    "#4ca2f9", "#63b598", "#ce7d78", "#ea9e70", "#a48a9e", "#648177" ,"#b11573" ,"#f2510e", 
    "#f205e6" ,"#14a9ad" ,"#a4e43f" ,"#d298e2" ,"#6119d0",
    "#d2737d" ,"#c0a43c"  ,"#79806e" ,"#61da5e" ,"#cd2f00" ,
    "#9348af" ,"#01ac53" ,"#c5a4fb" ,"#996635","#0d5ac1" ,"#4bb473" ,"#75d89e" ,
    "#2f3f94" ,"#2f7b99" ,"#da967d" ,"#34891f" ,"#b0d87b" ,"#ca4751" ,"#7e50a8" ,
    "#c4d647" ,"#e0eeb8" ,"#11dec1" ,"#289812" ,"#566ca0" ,"#ffdbe1" ,"#2f1179" ,
    "#935b6d" ,"#916988" ,"#513d98" ,"#aead3a", "#9e6d71", "#4b5bdc", "#0cd36d",
    "#250662", "#cb5bea", "#228916", "#ac3e1b", "#df514a", "#539397", "#880977",
    "#f697c1", "#ba96ce", "#679c9d", "#c6c42c", "#5d2c52", "#48b41b", "#e1cf3b",
    "#5be4f0", "#57c4d8", "#a4d17a", "#be608b", "#96b00c", "#088baf",
    "#f158bf", "#e145ba", "#ee91e3", "#05d371", "#5426e0", "#802234",
    "#6749e8", "#0971f0", "#8fb413", "#b2b4f0", "#c3c89d", "#c9a941", "#41d158",
    "#fb21a3", "#51aed9", "#5bb32d", "#21538e", "#89d534", "#d36647",
    "#7fb411", "#0023b8", "#3b8c2a", "#986b53", "#f50422", "#983f7a", "#ea24a3",
    "#79352c", "#521250", "#c79ed2", "#d6dd92", "#e33e52", "#b2be57", "#fa06ec",
    "#1bb699", "#6b2e5f", "#64820f", "#21538e", "#89d534", "#d36647",
    "#7fb411", "#0023b8", "#3b8c2a", "#986b53", "#f50422", "#983f7a", "#ea24a3",
    "#79352c", "#521250", "#c79ed2", "#d6dd92", "#e33e52", "#b2be57", "#fa06ec",
    "#1bb699", "#6b2e5f", "#64820f", "#9cb64a", "#996c48", "#9ab9b7",
    "#06e052", "#e3a481", "#0eb621", "#fc458e", "#b2db15", "#aa226d", "#792ed8",
    "#73872a", "#520d3a", "#cefcb8", "#a5b3d9", "#7d1d85", "#c4fd57", "#f1ae16",
    "#8fe22a", "#ef6e3c", "#243eeb", "#dd93fd", "#3f8473", "#e7dbce",
    "#421f79", "#7a3d93", "#635f6d", "#93f2d7", "#9b5c2a", "#15b9ee", "#0f5997",
    "#409188", "#911e20", "#1350ce", "#10e5b1", "#fff4d7", "#cb2582", "#ce00be",
    "#32d5d6", "#608572", "#c79bc2", "#00f87c", "#77772a", "#6995ba",
    "#fc6b57", "#f07815", "#8fd883", "#060e27", "#96e591", "#21d52e", "#d00043",
    "#b47162", "#1ec227", "#4f0f6f", "#1d1d58", "#947002", "#bde052", "#e08c56",
    "#28fcfd", "#36486a", "#d02e29", "#1ae6db", "#3e464c", "#a84a8f",
    "#911e7e", "#3f16d9", "#0f525f", "#ac7c0a", "#b4c086", "#c9d730", "#30cc49",
    "#3d6751", "#fb4c03", "#640fc1", "#62c03e", "#d3493a", "#88aa0b", "#406df9",
    "#615af0", "#2a3434", "#4a543f", "#79bca0", "#a8b8d4", "#00efd4",
    "#7ad236", "#7260d8", "#1deaa7", "#06f43a", "#823c59", "#e3d94c", "#dc1c06",
    "#f53b2a", "#b46238", "#2dfff6", "#a82b89", "#1a8011", "#436a9f", "#1a806a",
    "#4cf09d", "#c188a2", "#67eb4b", "#b308d3", "#fc7e41", "#af3101","#71b1f4", 
    "#a2f8a5", "#e23dd0", "#d3486d", "#00f7f9", "#474893", "#3cec35", "#1c65cb", 
    "#5d1d0c", "#2d7d2a", "#ff3420", "#5cdd87", "#a259a4", "#e4ac44", "#88e9b8", 
    "#c2b0e2", "#86e98f", "#ae90e2", "#1a806b", "#436a9e", "#0ec0ff", "#f812b3", 
    "#b17fc9", "#8d6c2f", "#d3277a", "#2ca1ae", "#9685eb", "#8a96c6", "#dba2e6", 
    "#76fc1b", "#608fa4", "#20f6ba", "#07d7f6", "#dce77a", "#77ecca"]
});

HC_exporting(Highcharts);
HC_boost(Highcharts);
NoDataToDisplay(Highcharts);

@Component({
  selector: 'app-stackedchart',
  templateUrl: './stackedchart.component.html',
  styleUrls: ['./stackedchart.component.scss']
})
export class StackedchartComponent implements OnInit {

  chartOptions: any;
  Highcharts = Highcharts; // required
  updateFlag = false; // optional boolean
  oneToOneFlag = true; // optional boolean, defaults to false
  chartConstructor = 'chart'; // optional string, defaults to 'chart'
  categories: any
  chart;
  updateFromInput = false;
  yaxisVal = " "

 

  // Input paramenter
  @Input() dataSource: any;
  @Input() chartTitle: string = '';
  @Input() Load: any;
  @Input() interval: string;
  @Input() toggle : any;
  @Input() chartType : string;

  chartTitleText: string;

  secondayAxisLabel: boolean = false;
  yaxis : any ;
  subscription: Subscription;

  constructor(private utils: UtilityService ,  private SidebarResizeService : SidebarResizeService) {
    const self = this;
    this.chartOptions = {
      chart: {
        type: 'column',
        zoomType: 'x',
        events: {
          load: function () {
            if (!this.renderer.forExport) {
              self.chart = this;
            }
          }
        },
      },
      title: {
        text: this.chartTitle
      },
      xAxis: {
        events: {
          afterSetExtremes: function() {
            $('.highcharts-button').show();
          }
        },
        type: 'datetime',
        dateTimeLabelFormats: {
          millisecond: '%b %e',
          month: '%b %e'
        },
      },
      exporting: {
        enabled: false,
        buttons: {
          contextButton: {
            menuItems: ["downloadPNG", "downloadJPEG", "downloadPDF", "downloadSVG"]
          }
        }
      },
      yAxis: [{ // Primary yAxis
        
        labels: {
        formatter: function (that) {
              self.yaxis = this;
              return  `${this.value} ${self.yaxisVal}` 
          }
        },
        title: {
          text: '',
          style: {
            color: Highcharts.getOptions().colors[1]
          }
        }
      }, { // Secondary yAxis
        title: {
          text: '',
          style: {
            color: Highcharts.getOptions().colors[0]
          }
        },
        labels: {
          format: '{value} $',
          style: {
            color: Highcharts.getOptions().colors[0]
          }
        },
        opposite: true
      }],
      tooltip: {
        pointFormat: '<b>{point.y}</b>'
      },
      credits: {
        enabled: false
      },
      legend: {
        enabled: true
      },
      plotOptions: {
        series: {
          turboThreshold: 0
        },
        dataGrouping: {
          enabled: true,
          approximation: 'average',
          forced: true
        },
        column: {
          stacking: 'normal'
        },
      },
      series: []
    };

    this.subscription = this.SidebarResizeService.getMessage().subscribe(message => {
      if (message) {
        /// Settimeout is required to get an instance of this.chart which will be availbale once it is loaded in dom. 
       setTimeout(() => {
          this.chart.reflow();
       }, 0)
      } 
    });
  }
  ngOnInit() {

  }

  formatSeries(data, type, yAxis, displayType, zIndex) {
    let dataSeries = [];
    let category = [];
    let self = this;
    _.forEach(data.value, (value, key) => {
      let data = self.utils.roundNumber(value.value, 2);

      var gmtDateTime = moment.utc(value.eventAt);
      var local = gmtDateTime.local().valueOf();

      dataSeries.push({ 'x': local, 'y': data });
      category.push(local);
    });
    var result = _.sortBy(dataSeries, 'x');
    if (_.isEmpty(this.categories)) {
      this.categories = category;
    }

    let label = displayType == "spline" ? `${data.label} $` : `${data.label} kWh` ;
    
    return { name: label, yAxis: yAxis, type: type, data: result, zIndex };

  }

  /***********  Format for global dashboard charts ****************/
  formatSeriesGlobal(data, type, yAxis, displayType) {
    let dataSeries = [];
    let category = [];
    _.forEach(data.values, (value, key) => {
      var local = moment(value.eventAt).local().valueOf();
      dataSeries.push({ 'x': local, 'y': value.value });
      category.push(local);
    });
    var result = _.sortBy(dataSeries, 'x');
    if (_.isEmpty(this.categories)) {
      this.categories = category;
    }
    let label = displayType == "spline" ? `${data.label} - $` : data.label;
    return { name: label, type: type, data: result };
  }

  getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
  
  formatData(seriesData) {
    let formattedData = [];
    let source = _.hasIn(seriesData, 'summaryTag') ? seriesData.summaryTag : seriesData ;
    let kpiName = _.hasIn(source, 'kpiName') && source.kpiName;
   let unit = source ? source.unit : '';
    switch (kpiName) {
      case 'energyCost': {
        this.secondayAxisLabel = true;
        let costData = [];
        const displayType = 'spline';
        _.forEach(source.value, (value, key) => {
          costData[key] = this.formatSeries(value, displayType, 1, displayType, 2);
        });
        return costData;
      }
      case 'energyconsumed': {
        let chatTitle = this.utils.displayChartTitle("energyConsumption");
        this.yaxisVal = chatTitle['units'];
        this.secondayAxisLabel = true;
        let costData = [];
        const displayType = 'column';
        _.forEach(source.value, (value, key) => {
          costData[key] = this.formatSeries(value, displayType, 0, displayType, 1);
        });
        return costData;
      }

      case 'GlobalEnergyConsumption': {
        let chatTitle = this.utils.displayChartTitle("globalConsumption");
        this.yaxisVal = chatTitle['units'];;
        let consumption = [];
        const displayType = 'column';
        _.forEach(source.value, (value, key) => {
          consumption[key] = this.formatSeriesGlobal(value, displayType, 0, displayType);
        });
        return consumption
      }

      case 'GlobalEnergySaving': {
        let chatTitle = this.utils.displayChartTitle("globalSaving");
        this.yaxisVal = chatTitle['units'];;
        let saving = [];
        const displayType = 'column';
        _.forEach(source.value, (value, key) => {
          saving[key] = this.formatSeriesGlobal(value, displayType, 0, displayType);
        });
        return saving
      }



      default: {
        return [];
      }
    }
  }

  mailLoop(dataSource) {
    let contructData = [];
    _.forEach(dataSource, (value, key) => {
      contructData[key] = this.formatData(value);
    });
    return contructData;
  }

  ngOnChanges(changes: SimpleChanges) {

    if (this.dataSource) {

      $('.highcharts-button').hide();
      $('.highcharts-button').click();
      let dataSeries = this.mailLoop(this.dataSource);
      let mainData = [];
      _.forEach(dataSeries, (value, pkey) => {
        _.forEach(value, (value, ckey) => {
          mainData.push(value);
        });
      });
      var legend = this.chart && this.chart.legend;
      //  this.chartOptions.yAxis.splice(1, 1);
      mainData = _.orderBy(mainData, ['name'],['asc']);
      

      this.chartOptions.series = mainData;
      this.chartOptions.yAxis[1].text = this.secondayAxisLabel ? 'Cost' : '';
      if (!this.chartOptions.series.length) {
        this.chartOptions.series = [];
      } else {
        this.updateFlag = true;
        _.has(legend, "group") && legend.group.show();
        _.has(legend, "box") &&legend.box.show();
        if(_.has(legend, "display")) { legend.display = true; }

      }
      setTimeout(() => {
        let noData = true;
        if (this.Load) {
          this.chart.showLoading();
          this.chart.hideNoData();
        } else {

          //  this.yaxis && this.yaxis.axis.labelFormatter();
          if(this.yaxis && _.hasIn(this.yaxis, 'axis')) {
            this.yaxis.axis.labelFormatter();
          }

          this.chart.hideLoading();
          _.forEach(this.chartOptions.series, (obj) => {
            if (obj.data.length) {
              noData = false;
              return false
            }
          })
          if (noData) { 
            this.chart.showNoData(); 
          _.forEach(this.chart.series,( obj )=>{
            obj.setData([] );
           
            _.has(legend, "group") && legend.group.hide();
            _.has(legend, "box") &&legend.box.hide();
            if(_.has(legend, "display")) { legend.display = true; }

          })
          } else {
            this.chart.hideNoData()
          }
        }
        this.chart.setTitle({ text: this.chartTitle });
        if(this.chartType == 'global') {
          this.chartOptions.tooltip = {
            formatter: function() {
              return `${moment(this.x).format('MMMM YYYY ')}<br><span style="color:${this.points[0].series.color}">${this.points[0].series.name}</span>: <b>${this.y.toFixed(2)}</b>`;
            },
            shared: true,
            valueDecimals: 2
          };
        }

     
        this.chart.reflow();
        this.chartOptions.yAxis[1].text = this.secondayAxisLabel ? 'Cost' : '';
      }, 0)
    }
  }


  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}
}