import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StackedchartComponent } from './stackedchart.component';

describe('StackedchartComponent', () => {
  let component: StackedchartComponent;
  let fixture: ComponentFixture<StackedchartComponent>;


  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
