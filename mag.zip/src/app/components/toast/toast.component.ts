import { Component, OnInit} from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'lodash';

@Component({
  selector: 'app-toast',
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.scss']
})
export class ToastComponent implements OnInit {
  private toastrOption : object = {
      timeOut: 20000,
      showEasing: "swing",
      preventDuplicates: true
  }
  constructor(private toastrService: ToastrService) {}
   
  showError(error:any) {
    let message:string;

    if(_.hasIn(error.error, "Message")) {
      message = error.error.Message;
    } else if(_.hasIn(error.error, "message")) {
      message = error.error.message;
    } else if( _.hasIn(error, "statusText")) {
      message = error.statusText;
    } else {
      message = error.message;
    }
    
    this.toastrService.error(message, 'Error', this.toastrOption);
  }

  showSucess(message:string) {
    this.toastrService.success(message, 'Success', this.toastrOption);
  }

  showWarning(message:string) {
    this.toastrService.warning(message, 'Warning', this.toastrOption);
  }

  ngOnInit() {}
}