import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-actionicons',
  templateUrl: './actionicons.component.html',
  styleUrls: ['./actionicons.component.scss']
})
export class ActioniconsComponent implements OnInit {
  @Input() pageTitle : string;
  constructor() { }

  ngOnInit() {

  }

}
