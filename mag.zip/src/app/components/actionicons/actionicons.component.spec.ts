import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActioniconsComponent } from './actionicons.component';
describe('ActioniconsComponent', () => {
  let component: ActioniconsComponent;
  let fixture: ComponentFixture<ActioniconsComponent>;

  beforeEach(() => {
    component = new ActioniconsComponent();
  });

  afterEach(() => {
    component = null;
  });

  it('Should create ActioniconsComponent ', () => {
    expect(true).toBeTruthy();
  });

  it('should show have pageTitle INPUT', () => {
    component.pageTitle = "This is page"
  });

});
