import { Component, Inject, ElementRef, OnInit, Input, OnChanges, ViewChild, ViewEncapsulation , EventEmitter , Output} from '@angular/core';
import * as _ from 'lodash';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.scss']
})
export class ListViewComponent implements OnInit {
@Input() bldgCollect : any;
@Input() deptCollect :any;
@Input() eqpCollect : any;
@Input() head : string;
@Input() data ;
@Input() palette ;
@Input() hex ;
@Input() name ;
@Input() loadingFlag ;
@Input() saveFlag : boolean;
@Input() asset :string;
@Input() viewOnly : boolean;
form_ : boolean = false;
error : boolean = false;
id =  null;
name_;
regions = [];
editing : boolean = false;
@Output() addItem : EventEmitter<any> = new EventEmitter();
@Output() updateItem : EventEmitter<any> = new EventEmitter();
@Output() deleteItem : EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() {
    this.setColor()
   
  }

  ngOnChanges(){
    this.setColor()
  }





  setColor(){
    this.bldgCollect = this.bldgCollect.map((obj)=>{
      return _.pick(obj , ['BuildingID', 'BuildingName' , 'Images'])
    });
    this.deptCollect = this.deptCollect.map((obj)=>{
      return _.pick(obj , ['DepartmentID', 'DepartmentName' , 'Images'])
    });

    this.eqpCollect = this.eqpCollect.map((obj)=>{
      return _.pick(obj , ['Equipment','Description'])
    })

    console.log(" this.eqpCollect",  this.eqpCollect)
    this.name.forEach((element , index) => {
      if(element){
        this.bldgCollect.forEach(obj => {

          if(obj.BuildingID.trim() === element.name.trim()){
            obj.color = this.palette[index]
          }
        })

        this.deptCollect.forEach(obj => {

          if(obj.DepartmentID.trim() === element.name.trim()){
            obj.color = this.palette[index]
          }
        })

        
        this.eqpCollect.forEach(obj => {
          if(obj.Equipment.trim() === element.name.trim()){
            obj.color = this.palette[index]
          }
        })


      }
    });

    console.log("  this.bldgCollect",   this.bldgCollect)
  }

  add(){
    if( this.name_ && this.name_.length){
      this.error = false;
      this.form_ = !this.form_;
      this.addItem.emit({id : this.id , name :  this.name_});
      this.loadingFlag =  true;
    }else{
      this.error = true;
    }

  }


  update(data){
   
    let selectedBuild = _.cloneDeep(data) ;
    if(selectedBuild.BuildingID && selectedBuild.BuildingName){
      selectedBuild.buildingid =  selectedBuild.BuildingID;
      selectedBuild.buildingname  =  selectedBuild.BuildingName;

      delete selectedBuild.BuildingName;
      delete selectedBuild.BuildingID;
    } else if(selectedBuild.DepartmentID && selectedBuild.DepartmentName){
      selectedBuild.departmentid =  selectedBuild.DepartmentID;
      selectedBuild.departmentname  =  selectedBuild.DepartmentName;

      delete selectedBuild.DepartmentName;
      delete selectedBuild.DepartmentID;
    } else if(selectedBuild.Equipment  ){
      selectedBuild.equipment =  selectedBuild.Equipment;
      selectedBuild.description = selectedBuild.Description
      delete selectedBuild.Equipment;
      delete selectedBuild.Description;
    }
   
    delete selectedBuild.Images;
    delete selectedBuild.editing;
    delete selectedBuild.color;
   

    this.updateItem.emit(selectedBuild);
    this.loadingFlag =  true;
    this.editing = !this.editing
    console.log("Data" , data);
  }

  delete(data){
  console.log("data -----" , data)
    let selectedImage = _.cloneDeep(data) ;
    delete selectedImage.Images;
    delete selectedImage.editing;
    delete selectedImage.color;

    this.deleteItem.emit(selectedImage);
    this.loadingFlag =  true;
    this.editing = !this.editing
  }

  openForm() {
    this.form_ = !this.form_
    this.error = false;
    this.id = "";
    this.name_ = "";
  }

}
