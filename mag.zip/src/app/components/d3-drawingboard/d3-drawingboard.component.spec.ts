import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { D3DrawingboardComponent } from './d3-drawingboard.component';

describe('D3DrawingboardComponent', () => {
  let component: D3DrawingboardComponent;
  let fixture: ComponentFixture<D3DrawingboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ D3DrawingboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(D3DrawingboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
