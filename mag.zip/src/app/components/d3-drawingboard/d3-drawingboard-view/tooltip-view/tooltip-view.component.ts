import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-show-card',
  templateUrl: './tooltip-view.component.html',
  styleUrls: ['./tooltip-view.component.scss']
})
export class ShowCardComponent implements OnInit {
@Input() dashCard;
@Input() name;
@Input() id;
@Input() loading;
@Input() asset;
@Input() noTool;
@Output() action : EventEmitter<any> = new EventEmitter();
  constructor(){

  }

  ngOnInit() {
  }

  navigate(){
    this.action.emit({'event' : 'NAV' , 'id' : this.id })
  }

}
