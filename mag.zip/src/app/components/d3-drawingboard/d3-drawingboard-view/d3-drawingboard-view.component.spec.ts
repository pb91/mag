import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { D3DrawingboardViewComponent } from './d3-drawingboard-view.component';

describe('D3DrawingboardComponent', () => {
  let component: D3DrawingboardViewComponent;
  let fixture: ComponentFixture<D3DrawingboardViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ D3DrawingboardViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(D3DrawingboardViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
