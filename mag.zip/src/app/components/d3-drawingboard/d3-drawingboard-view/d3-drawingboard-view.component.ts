import { Component,ViewContainerRef, Inject, ElementRef, OnInit, Input, OnChanges, ViewChild, ViewEncapsulation , EventEmitter , Output,ComponentFactoryResolver} from '@angular/core';

import {TooltipDirective} from './tooltip-view/tooltip-view.directive';
import {ShowCardComponent} from './tooltip-view/tooltip-view.component'

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import * as d3 from 'd3';
import { Observable } from 'rxjs';
import * as _ from 'lodash';


export interface DialogData {
  name: string;
}

@Component({
  selector: 'app-d3-drawingboard-view',
  templateUrl: './d3-drawingboard-view.component.html',
  styleUrls: ['./d3-drawingboard-view.component.scss']
})
export class D3DrawingboardViewComponent implements OnInit {
  @ViewChild('chart')

  public chartContainer: ElementRef;
  @ViewChild('tooltip') tooltip: ElementRef;
 
  @Input() data ;
  @Input() palette ;
  @Input() hex ;
  @Input() name ;
  @Input() imageName = '';
  @Input() dashCard;
  @Input() loadingFlag : boolean ; 
  @Input() asset : string;
  @Input() herarchy;
  @Input() selectedBuildingID;
  @Input() selectedBuildingNAME;
  @Output() action : EventEmitter<any> = new EventEmitter();
 
  @Input() tool : boolean = false;
  div;
  SWTCH : number  ;
  zommed : boolean = false;
  margin = { top: 0, right: 0, bottom: 0, left: 0 };
  svg
  active: number = undefined;
  polygen: Array<any> = [];
  focus;
  view;
  checked: boolean = true;
  checked1: boolean = false;
  zoomTrans = { x: 0, y: 0, scale: 1 }
  saveFlag : boolean = false;
  @ViewChild('tpl')  tpl: ElementRef;
  @ViewChild('tltp') tltp : ElementRef;
  tooltipname ;
  tooltipId;
  selectedPolygon : any = {};

  constructor(public dialog: MatDialog ,private componentFactoryResolver: ComponentFactoryResolver ) { }

  ngOnChanges(){
   // this.createChart();
  }

  ngOnInit() {
    this.checked = true;
    this.checked1 = false;
    this.createChart();
  }
  private createChart(): void {

    d3.select('svg').remove();
    const element = this.chartContainer.nativeElement;
   
    this.svg = d3.select(element).append('svg')
      .attr('width', '100%')
      .attr('height', 600)
      .attr("border", 3)
      .call(d3.zoom().scaleExtent([1, 8]).on("zoom", (e) => {
        this.removeTooltip();
        this.zoomTrans.x = d3.event.transform.x;
        this.zoomTrans.y = d3.event.transform.y;
        this.zoomTrans.scale = d3.event.transform.k;
        this.svg.attr("transform", d3.event.transform)
      }))
      .on("dblclick.zoom", null)
   
      .append("g");

    

    this.svg.on('click', (d) => {
      this.removeTooltip();
      let el = element;
      let e_posx : number =0  , e_posy : number = 0 ,e_scx : number= 0 , e_scy :number = 0;
      if (el.offsetParent){
        do { 
            e_posx += el.offsetLeft;
            e_posy += el.offsetTop;
            e_scx += el.scrollLeft;
            e_scy += el.scrollTop;
        } while (el = el.offsetParent);
    }

      let x = (d3.event.x - e_posx - e_scx - this.zoomTrans.x) / this.zoomTrans.scale;
      let y = (d3.event.y - e_posy + e_scy - this.zoomTrans.y) / this.zoomTrans.scale;

      console.log("d3.event.x",d3.event.x);
      console.log("e_posx",e_posx)
      console.log("e_scx",e_scx);
      console.log(" this.zoomTrans.x", this.zoomTrans.x)
      console.log(" this.zoomTrans.scale", this.zoomTrans.scale)

      console.log("d3.event.y",d3.event.y);
      console.log("e_posy",e_posy)
      console.log("e_scy",e_scy);
      console.log(" this.zoomTrans.y", this.zoomTrans.y)
      console.log(" this.zoomTrans.scale", this.zoomTrans.scale)

      console.log("this.tltp" , this.tltp)



      this.data.forEach((obj, index) => {
        if (obj.length) {
          if (this.findInPoly(obj, [x, y])) {
            this.centroid(obj);
            if (this.name[index] !== undefined && this.name[index] !== null && this.name[index].name) {
             // d3.selectAll('.tooltip').remove();
              this.action.emit({'event': 'META' , 'asset' : this.asset , 'data': this.name[index].name});
              this.tool = true;
            
              this.tooltipId= this.name[index].name;
              this.tooltipname = this.getTooltipDetails(this.tooltipId , this.asset) ;
            
         console.log( "this.tooltipname" ,this.tooltipname)  // .style('display','block');
              let div =   d3.select(".tooltip").style('display', 'block')
              .style('opacity',1)
              .style('background-color' , 'white')
              .style('border', 'solid #8080804f')
              .style('border-width', '1px')
              .style('left', (x + "px"))
              .style('top', (y + "px"))
              .style('height','210px')
              .style('width','200px')
              .style('box-shadow' , '10px 10px 10px 10px rgba(0, 0, 0, 0.2)')
              .style('position','absolute')
              // .html(`<div  #tltp style="background:#007bc1;height:30%;text-align: left;padding: 15px 15px 0px 15px;">
              // <p style="margin:0;color:#ffff;">
              // <span style="font-size:16px;font-weight:bold;display:block;margin: 5px;">${this.name[index].name}</span>
          
              // <span style="font-size:12px;display:block;margin: 5px;">${this.dashCard[3].number} Department </span>
          
              // <span  style="font-size:12px;display:block;margin: 5px;"> ${this.dashCard[2].number} Devices </span>
              // </p>
              // </div>
              // <div style="padding: 15px;">
              // <br>
              // <span style="font-size:12px;display:block;margin: 5px;text-alignment:left">${this.dashCard[2].number} Alarms</span>
          
              // <span style="font-size:12px;display:block;margin: 5px;text-alignment:left">cost ${this.dashCard[1].unit} ${this.dashCard[1].number}</span>
          
              // <span  style="font-size:12px;display:block;margin: 5px;text-alignment:left">saving </span>
              // <span  style="font-size:12px;display:block;margin: 5px;text-alignment:left"><i class="fas fa-bell"></i> used ${this.dashCard[0].unit}${this.dashCard[0].number} </span>
              // <a href="Javascript:Void(0); " style="font-size:11px;display:block;margin: 5px;" (click)="console.log('hey')">Navigate</a>
              // </div>`)
              // .on('click', (d)=> {console.log("i am clicked"); if(this.asset === "PLANT" ){
              //   d3.selectAll('.tooltip').remove();
              //   this.action.emit({'event': 'LEVEL' , 'asset' : this.asset });
              // } });

//this.loadComponent();
//
            }
          }
        }

      })
    


    });


  this.svg.append('image')
      .attr('xlink:href', this.imageName)
      .attr('width', 1354)
      .attr('height', 700)
      .attr('x', 10)
      .attr('y', 10)
      this.draw()
      this.clearPolylinesAndCircles();


  }


  getTooltipDetails(id , asset){
    let rtrn ;
    if(asset === "PLANT"){
      this.herarchy['PLANT']['BUILDING'].forEach(element => {
     
          if(element.id == id){
           
            rtrn = element.name;
          }
      });
    }else if(asset === "BUILDING"){

      this.herarchy['PLANT']['BUILDING'].forEach(element => {
        console.log("selectedBuildingID",this.selectedBuildingID)
        if(element.id == this.selectedBuildingID){
          
          console.log("id",id)
          console.log("asset",asset)
          console.log("element",element)
          element["DEPARTMENT"].forEach(ele => {
            console.log("ele",ele)
            if(ele.id == id){
              
              rtrn = ele.name;
            }
          });
        }
    });

    }else if(asset === "DEPARTMENT"){

    }

    return rtrn;
  }

  removeTooltip(){
    this.tool = false;
    d3.select(".tooltip").style('display', 'none')
            .style('opacity',0)
            .style('border', 'solid #8080804f')
            .style('width' , '0px')
            .style('height' , '0px')
  }


  findInPoly(polygon, point) {
    var n = polygon.length,
      p = polygon[n - 1],
      x = point[0], y = point[1],
      x0 = p[0], y0 = p[1],
      x1, y1,
      inside = false;

    for (var i = 0; i < n; ++i) {
      p = polygon[i], x1 = p[0], y1 = p[1];
      if (((y1 > y) !== (y0 > y)) && (x < (x0 - x1) * (y - y1) / (y0 - y1) + x1)) inside = !inside;
      x0 = x1, y0 = y1;
    }

    return inside;
  }

  centroid(polygon) {
    var i = -1,
      n = polygon.length,
      x = 0,
      y = 0,
      a,
      b = polygon[n - 1],
      c,
      k = 0;

    while (++i < n) {
      a = b;
      b = polygon[i];
      k += c = a[0] * b[1] - b[0] * a[1];
      x += (a[0] + b[0]) * c;
      y += (a[1] + b[1]) * c;
    }

    return k *= 3, [x / k, y / k];
  }

  draw() {
    this.clearPolylinesAndCircles();
    this.svg.select('g.drawPoly').remove();
    if (this.data.length === 1) {
      this.closePolygon(this.data[0], 0)
    } else if (this.data.length > 1) {
      for (let i = 0; i < this.data.length; i++) {
        this.closePolygon(this.data[i], i)
      }
    }

  }



  closePolygon(obj, p) {
    this.svg.select('g.drawPoly').remove();

    if (!this.palette[p]) {
      this.palette[p] = '#' + (function lol(m, s, c) { return s[m.floor(m.random() * s.length)] + (c && lol(m, s, c - 1)); })(Math, '0123456789ABCDEF', 4);
    }

    var g = this.svg.append('g');
    if (!this.hex[p]) {
      this.hex[p] = this.hexToRgb(this.palette[p]);
    }

    let fillColor = this.hex[p]
    let self = this;
    g.append('polygon')
      .attr('points', obj)
      .style('fill', 'rgba(' + fillColor.r + ',' + fillColor.g + ',' + fillColor.b + ',0.3)')
      .on('click', function (d) {
      }).on('mouseover', function(d) {d3.select(this).style("cursor", "pointer")});

    ///creating label for polygons
  
  let point = this.centroid(obj);
  if(this.name[p] && this.name[p].name){
    g.append("text")
    .attr("x",point[0])
    .attr("y", point[1])
    .attr("dy", ".35em")
    .style('fill', 'rgba(' + fillColor.r + ',' + fillColor.g + ',' + fillColor.b + ',1)')
    .style('font-weight',"bolder")
    .text(`${this.name[p].name}`);
}

 
      
    for (var i = 0; i < obj.length; i++) {
      var circle = g.selectAll('circles')
        .data([obj[i]])
        .enter()
        .append('circle')
        .attr('cx', obj[i][0])
        .attr('cy', obj[i][1])
        .attr('r', 2)
        .attr('fill', this.hex[p])
        .attr('stroke', this.palette[p])
        .attr('is-handle', 'true')
        .style({ cursor: 'move' })

    }
  }


  getRandomColor() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  clearPolylinesAndCircles() {
    this.svg.selectAll('g polyline').remove();
    // this.svg.selectAll('g circle').remove();
  }


  changeIndex(dir){
    this.removeTooltip();
    this.action.emit({'event' :dir});
  }

  actionEvnt(eve){
    eve.asset = this.asset;
    this.action.emit(eve);
    console.log("eve" , eve)
  }


}

