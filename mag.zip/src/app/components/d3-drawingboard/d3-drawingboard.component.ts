import { Component, Inject, ElementRef, OnInit, Input, OnChanges, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import * as d3 from 'd3';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

import { Overlay, ConnectionPositionPair, PositionStrategy, OverlayConfig } from '@angular/cdk/overlay';
import { TemplatePortal, PortalInjector } from '@angular/cdk/portal';
import { Popover } from './popover/popover.service';

import { DialogboxComponent } from '@appComponents/dialogbox/dialogbox.component';



export interface DialogData {
  name: string;
}

@Component({
  selector: 'app-d3-drawingboard',
  templateUrl: './d3-drawingboard.component.html',
  styleUrls: ['./d3-drawingboard.component.scss']
})
export class D3DrawingboardComponent implements OnInit {
  @ViewChild('chart')
  public chartContainer: ElementRef;
  @Input() viewOnly;
  @Input() justView;
  @Input() data;
  @Input() palette;
  @Input() hex;
  @Input() name;
  @Input() imageName = '';
  @Input() levelType: string;
  @Input() levelData;
  @Input() dptlevelData;
  @Input() eqplevelData;

  @Input() loadingFlag: boolean;
  @Input() asset: string;
  @Output() action: EventEmitter<any> = new EventEmitter();
  @Output() addItem: EventEmitter<any> = new EventEmitter();
  @Output() updateItem: EventEmitter<any> = new EventEmitter();
  @Output() deleteItem: EventEmitter<any> = new EventEmitter();

  SWTCH: number;
  zommed: boolean = false;
  margin = { top: 0, right: 0, bottom: 0, left: 0 };
  svg
  active: number = undefined;
  polygen: Array<any> = [];
  focus;
  view;
  checked: boolean = true;
  checked1: boolean = false;
  zoomTrans = { x: 0, y: 0, scale: 1 }
  saveFlag: boolean = false;
  @ViewChild('tpl') tpl: ElementRef;
  selectedPolygon: any = {};
  constructor(public dialog: MatDialog, private popper: Popover) { }


  // ngOnChanges(): void {
  //   this.createChart();
  // }

  ngOnInit() {
    this.checked = true;
    this.checked1 = false;
    this.createChart();
  }

  addItem_(e) {
    this.addItem.emit(e);
  }

  updateItem_(e) {
    this.updateItem.emit(e);
  }

  deleteItem_(e) {
    this.name.forEach((element, index) => {
      if (element) {
        if (element.name === e.BuildingID) {
          this.name[index] = null;
        }
      }
    });

    if(this.data.length || this.palette.length || this.hex.length || this.name.length){
      let jsn = {
        event: "SAVE",
        data: this.data,
        palette: this.palette,
        hex: this.hex,
        name: this.name,
        imageName: this.imageName
      }
  
      this.action.emit(jsn);
    }
 
    this.deleteItem.emit(e);

  }



  show(content: ElementRef, data) {
    const ref = this.popper.open<{ data: any }>({
      content,
      width: '300px',
      data: {
        data
      }
    });

    ref.afterClosed$.subscribe(res => {
      if (res.data) {
        console.log(res);
        let option: string = res.data.toString();
        switch (option.trim()) {
          case "SAVE": {
            console.log("this.selectedPolygon", this.selectedPolygon)
            if (this.selectedPolygon['selected'] && this.selectedPolygon['obj'] !== this.selectedPolygon['selected']) {

              if(this.selectedPolygon['selected'].trim() !== this.name[this.selectedPolygon.index].name){


                this.name.forEach((ele, index) => {
                  if (ele) {
                    if (this.selectedPolygon['selected'].trim() === ele.name.trim()) {
                      this.name[index] = null;
                    }
                  }
                });
  
  
  
                this.name[this.selectedPolygon.index] = { name: this.selectedPolygon['selected'] };
                let jsn = {
                  event: "SAVE",
                  data: this.data,
                  palette: this.palette,
                  hex: this.hex,
                  name: this.name,
                  imageName: this.imageName
                }
                this.action.emit(jsn);
                this.saveFlag = !this.saveFlag;
  

              }



            }

          }
            break;
          case "DELETE": {
            console.log("delete", this.selectedPolygon);

            console.log("data", {
              data: this.data,
              palette: this.palette,
              hex: this.hex,
              name: this.name
            })

            this.data.splice(this.selectedPolygon.index, 1);
            this.palette.splice(this.selectedPolygon.index, 1);
            this.hex.splice(this.selectedPolygon.index, 1);
            this.name.splice(this.selectedPolygon.index, 1);
            let jsn = {
              event: "DELETE",
              data: this.data,
              palette: this.palette,
              hex: this.hex,
              name: this.name,
              imageName: this.imageName
            }
            this.action.emit(jsn);
          }
        }
      }
    })

  }

  open(obj, index, levelData) {
    this.SWTCH = 2;
    this.selectedPolygon['index'] = index;
    this.selectedPolygon['obj'] = obj;
    this.selectedPolygon['selected'] = this.selectedPolygon['obj'] ? this.selectedPolygon['obj'].name : null;

    this.show(this.tpl, { obj, index, levelData })
  }


  private createChart(): void {

    d3.select('svg').remove();
    const element = this.chartContainer.nativeElement;

    this.svg = d3.select(element).append('svg')
      .attr('width', 960)
      .attr('height', 600)
      .attr("border", 3)
   
      .call(d3.zoom().scaleExtent([1, 8]).on("zoom", (e) => {

        this.zoomTrans.x = d3.event.transform.x;
        this.zoomTrans.y = d3.event.transform.y;
        this.zoomTrans.scale = d3.event.transform.k;
        this.svg.attr("transform", d3.event.transform)
      }))
      .on("dblclick.zoom", null)
      .append("g");

    this.svg.on('click', (d) => {

      let el = element;
      let e_posx: number = 0, e_posy: number = 0, e_scx: number = 0, e_scy: number = 0;
      if (el.offsetParent) {
        do {
          e_posx += el.offsetLeft;
          e_posy += el.offsetTop;
          e_scx += el.scrollLeft;
          e_scy += el.scrollTop;
        } while (el = el.offsetParent);
      }

      let x = (d3.event.x - e_posx - e_scx - this.zoomTrans.x) / this.zoomTrans.scale;
      let y = (d3.event.y - e_posy + e_scy - this.zoomTrans.y) / this.zoomTrans.scale;

      if (!this.viewOnly && !this.justView) {
        if (this.checked && !this.checked1) {
          if (this.active !== undefined) {
            this.data[this.active].push([x, y]);
            this.polylineCircle();
          }
        } else if (!this.checked && this.checked1) {
          this.data.forEach((obj, index) => {

            if (obj.length) {
              if (this.findInPoly(obj, [x, y])) {

                this.centroid(obj);
                if (this.name[index] !== undefined && this.name[index] !== null && this.name[index].name) {
                  // this.openDialog(this.name[index], index , this.levelData);
                  this.open(this.name[index], index, this.levelData)
                } else {
                  this.open(undefined, index, this.levelData)
                  //this.openDialog(undefined, index , this.levelData);
                }
              }
            }

          })
        }
      } else if (this.viewOnly) {
        this.data.forEach((obj, index) => {

          if (obj.length) {
            if (this.findInPoly(obj, [x, y])) {

              this.centroid(obj);
              if (this.name[index] !== undefined && this.name[index] !== null && this.name[index].name) {
                // this.openDialog(this.name[index], index , this.levelData);
                this.open(this.name[index], index, this.levelData)
              } else {
                this.open(undefined, index, this.levelData)
                //this.openDialog(undefined, index , this.levelData);
              }
            }
          }

        })
      } else if (this.justView) {

      }
    });

    this.svg.append('image')
      .attr('xlink:href', this.imageName)
      .attr('width', 1354)
      .attr('height', 700)
      .attr('x', 10)
      .attr('y', 10)
    this.draw()
    this.clearPolylinesAndCircles();
  }


  onChange(): void {
    this.checked = !this.checked;
    if (this.checked) {
      this.checked1 = false;
    }
  }

  onChangeEdit(): void {
    this.checked1 = !this.checked1;

    if (this.checked1) {
      this.checked = false;
    }
  }



  findInPoly(polygon, point) {

    var n = polygon.length,
      p = polygon[n - 1],
      x = point[0], y = point[1],
      x0 = p[0], y0 = p[1],
      x1, y1,
      inside = false;

    for (var i = 0; i < n; ++i) {
      p = polygon[i], x1 = p[0], y1 = p[1];
      if (((y1 > y) !== (y0 > y)) && (x < (x0 - x1) * (y - y1) / (y0 - y1) + x1)) inside = !inside;
      x0 = x1, y0 = y1;
    }
    console.log("point", point);
    console.log("point", polygon);
    console.log("inside", inside);
    return inside;
  }

  centroid(polygon) {
    var i = -1,
      n = polygon.length,
      x = 0,
      y = 0,
      a,
      b = polygon[n - 1],
      c,
      k = 0;

    while (++i < n) {
      a = b;
      b = polygon[i];
      k += c = a[0] * b[1] - b[0] * a[1];
      x += (a[0] + b[0]) * c;
      y += (a[1] + b[1]) * c;
    }

    return k *= 3, [x / k, y / k];
  }

  draw() {
    this.clearPolylinesAndCircles();
    this.svg.select('g.drawPoly').remove();
    this.active = undefined;
   // this.btnClick('Add');
    if (this.data.length === 1) {
      this.closePolygon(this.data[0], 0)
    } else if (this.data.length > 1) {
      for (let i = 0; i < this.data.length; i++) {
        this.closePolygon(this.data[i], i)
      }
    }

  }


  polylineCircle() {
    let g;
    if (this.svg.select('g.drawPoly').empty()) { g = this.svg.attr('class', 'drawPoly'); }
    if (d3.event.target.hasAttribute('is-handle')) {
      this.draw();
      return;
    };
    this.drawCircles();
    this.drawPolylines();
  }


  drawPolylines() {
    this.svg.attr('class', 'drawPoly').select('polyline').remove();
    var polyline = this.svg.attr('class', 'drawPoly').append('polyline').attr('points', this.data[this.active])
      .style('fill', 'none')
      .attr('stroke', '#000');
  }


  drawCircles() {
    for (var i = 0; i < this.data[this.active].length; i++) {
      this.svg.attr('class', 'drawPoly').append('circle')
        .attr('cx', this.data[this.active][i][0])
        .attr('cy', this.data[this.active][i][1])
        .attr('r', 5)
        .attr('fill', 'blue')
        .attr('stroke', '#000')
        .attr('is-handle', 'true')
        .style({ cursor: 'pointer' });
    }
  }

  closePolygon(obj, p) {
    this.svg.select('g.drawPoly').remove();

    if (!this.palette[p]) {
      this.palette[p] = '#' + (function lol(m, s, c) { return s[m.floor(m.random() * s.length)] + (c && lol(m, s, c - 1)); })(Math, '0123456789ABCDEF', 4);
    }

    var g = this.svg.append('g');
    if (!this.hex[p]) {
      this.hex[p] = this.hexToRgb(this.palette[p]);
    }

    let fillColor = this.hex[p]
    let self = this;
    g.append('polygon')
      .attr('points', obj)
      .style('fill', 'rgba(' + fillColor.r + ',' + fillColor.g + ',' + fillColor.b + ',0.3)')
      .on('click', function (d) {
        self.transition_self(this)
      }).on('mouseover', function (d) {
        console.log("this.viewOnly", self.viewOnly); if (self.viewOnly) {
          d3.select(this).style("cursor", "pointer");


        }
      })



    //   {
    // "mouseover": function(d) {d3.select(this).style("cursor", "pointer");},
    //  "mouseout": function(d) {d3.select(this).style("cursor", "default");}
    // });



    for (var i = 0; i < obj.length; i++) {
      var circle = g.selectAll('circles')
        .data([obj[i]])
        .enter()
        .append('circle')
        .attr('cx', obj[i][0])
        .attr('cy', obj[i][1])
        .attr('r', 5)
        .attr('fill', this.hex[p])
        .attr('stroke', this.palette[p])
        .attr('is-handle', 'true')
        .style({ cursor: 'move' })

    }
  }


  getRandomColor() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  clearPolylinesAndCircles() {
    this.svg.selectAll('g polyline').remove();
    // this.svg.selectAll('g circle').remove();
  }


  btnClick(opt) {

    switch (opt.trim()) {
      case "Add":
        if (!this.checkForNewArray()) {
          this.data.push([]);
        }
        this.active = this.data.length - 1;
        break;
      case "Save":
        let jsn = {
          event: "SAVE",
          data: this.data,
          palette: this.palette,
          hex: this.hex,
          name: this.name,
          imageName: this.imageName
        }
        this.action.emit(jsn);

        this.clearPolylinesAndCircles()
        break;
      case "Clear":

        const dialogRef = this.dialog.open(DialogboxComponent, {
          width: '300px',
          height: '120px',
          data: `"Clear All" will clear all the data, Are you sure you still want to proceed?`
        });

        dialogRef.afterClosed().subscribe(result => {

          if (result) {


            this.data = [];
            this.palette = [];
            this.hex = [];
            this.name = [];
            this.svg.selectAll('g polygon').remove();
            this.svg.selectAll('g cirlce').remove();
            this.clearPolylinesAndCircles();
            this.svg.selectAll('g circle').remove();
            this.active = undefined;


            let jsn_clr = {
              event: "CLEAR",
              data: this.data,
              palette: this.palette,
              hex: this.hex,
              name: this.name,
              imageName: this.imageName
            }
            this.action.emit(jsn_clr)
          }

        });

        break;
      case "Undo":

        this.data[this.active] = [];
        this.svg.selectAll('g polygon').remove();
        this.svg.selectAll('g circle').remove();
        this.clearPolylinesAndCircles();
        this.draw();

        break;
      default:
    }

  }


  transition_self(poly) {
    let masterGroup = d3.select("#chart svg g ");
    if (!this.checked && !this.checked1) {
      if (!this.zommed) {
        let arr = [];
        for (let i = 0; i <= poly.points.length - 1; i++) {
          arr.push([poly.points.getItem(i).x, poly.points.getItem(i).y])
        }


        d3.select(poly).attr("class", "test");
        var bbox = d3.select(poly).node().getBBox();

        var rectAttr = {
          x: bbox.x,
          y: bbox.y,
          width: bbox.width,
          height: bbox.height,
        };
        var transX, transY;
        this.svg.transition().duration(1000).attr('transform', (d) => {

          var testScale = Math.max(rectAttr.width, rectAttr.height);
          testScale = testScale * 2;

          var widthScale = 970 / testScale
          var heightScale = 500 / testScale
          var scale = Math.max(widthScale, heightScale);

          transX = -(this.centroid(arr)[0] + 0) * scale + 1280 / 2;
          transY = -(this.centroid(arr)[1] + 0) * scale + 670 / 2;

          return 'translate(' + transX + ',' + transY + ')scale(' + scale + ')';
        })

        this.zommed = true;
      } else {
        this.svg.transition().duration(1000).attr('transform', function (d) {
          return 'translate(' + 0 + ',' + 0 + ')scale(' + 1 + ')';

        })
        this.zommed = false;
      }

    }
  }


  checkForNewArray(): boolean {

    return this.data[this.data.length - 1] && _.isEmpty(this.data[this.data.length - 1]) ? true : false;
  }


}

