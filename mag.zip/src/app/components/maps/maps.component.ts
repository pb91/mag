import { Component, OnInit, ViewChild, Input, SimpleChanges, OnChanges, ChangeDetectorRef} from '@angular/core';
import * as _ from 'lodash';
import { MapMouseEvent, LngLatBounds, Map } from 'mapbox-gl';
declare var require;
const defaultTheme = require('@pxblue/mapbox/default.json');
import { UtilityService  } from '../../shared/utility.service';

@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html',
  styleUrls: ['./maps.component.scss']
})
export class MapsComponent implements OnInit, OnChanges {
  @ViewChild('gmap') gmapElement: any;
  points: GeoJSON.FeatureCollection<GeoJSON.Point>;
  selectedPoint: GeoJSON.Feature<GeoJSON.Point> | null;
  @Input() dataSource;
  mapTheme = defaultTheme;
  latitude: any;
  longitude: any;
  isHidden = false;
  detailsArray: any;
  ngOnInit(): void { }
  bounds: LngLatBounds;
  cursorStyle: string
  map: Map;
  constructor(private ChangeDetectorRef: ChangeDetectorRef, private utils: UtilityService) {}
  

  ngAfterContentInit() {
    // this.map.invalidateSize();
  //  this.map.resize();
  }

  onClick(evt: MapMouseEvent) {
    this.selectedPoint = null;
    this.ChangeDetectorRef.detectChanges();
    this.selectedPoint = (<any>evt).features[0];
  }

  redirect(PlantID: string) {
    return this.utils.returnHyperLink(PlantID);
  }

  addMarker(dataSource:any) {
    let self = this;
    let features = [];
    dataSource.forEach(function(value: object, key: number) {      
      let latitude = _.hasIn(value, "latitude") ? value['latitude'] : null;
      let longitude = _.hasIn(value, "longitude") ? value['longitude'] : null;
      let plantName = _.hasIn(value, "user") ? value['user'] : '';
      let PlantID = _.hasIn(value, "PlantID") ? value['PlantID'] : '';    
      let array = [];
      array.push(longitude)
      array.push(latitude)
      if(longitude != "" && latitude!= "") {
			features.push({
        'type': 'Feature',
        'properties': {
          'icon' : "marker",
          "iconSize": [150, 150],
          'description': plantName,
          'link': self.redirect(PlantID),
        },
        'geometry': {
          'type': 'Point',
          'coordinates': array
        }
      });
      }
    });

    this.points = {
      'type': 'FeatureCollection',
      'features': features
    };
  }

  ngOnChanges(changes: SimpleChanges) {
    if(this.dataSource instanceof Array) {
      this.addMarker(this.dataSource);
    }  
  }
}