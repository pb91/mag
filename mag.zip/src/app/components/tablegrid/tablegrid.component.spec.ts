import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TablegridComponent } from './tablegrid.component';

describe('TablegridComponent', () => {
  let component: TablegridComponent;
  let fixture: ComponentFixture<TablegridComponent>;
  afterEach(() => {
    component = null;
  });


  it('should create', () => {
    expect(true).toBeTruthy();
  });

});
