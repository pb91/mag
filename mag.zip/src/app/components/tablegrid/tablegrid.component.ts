import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges, OnChanges, QueryList, ViewChildren } from '@angular/core';
import { MatSort, MatPaginator, MatTableDataSource, Sort, getMatIconNameNotFoundError, MatMenuTrigger } from '@angular/material';
import { FormControl } from '@angular/forms';
import * as _ from 'lodash';

export interface PeriodicElement {
  name: string;
  position: string;
  weight: string;
  symbol: string;
}

@Component({
  selector: 'app-tablegrid',
  templateUrl: './tablegrid.component.html',
  styleUrls: ['./tablegrid.component.scss']
})
export class TablegridComponent implements OnInit,OnChanges {
  @Input() dataSourceMain;
  @Input() pageDetails:string;
  @Input() enableCheckBox : boolean;
  @Input() configuration;
  @Input() checkedItem : string[];
  @Output() buttonPressed = new EventEmitter();
  @Output() cloneClicked = new EventEmitter();
  @Output() anchorPressed = new EventEmitter();
  @Output() getCheckedItem = new EventEmitter();
  @Output() editClicked = new EventEmitter();
  @Output() onDeleteClicked = new EventEmitter();
  @Output() onViewClicked = new EventEmitter();
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  @ViewChildren(MatMenuTrigger) trigger: QueryList<MatMenuTrigger>;
  dataSource : any = {data: []};
  dataSourceInput : any;
  displayedColumns = [];
  displayedColumnsTemp = [];
  columnFilterData = [];
  groupByOptions = [];
  groupByColsSelected=[];
  isGroupByActive=false;
  sortable = [];
  isColCheckBox = [];
  isColButton = [];
  isColAnchor = [];
  isColStatus = [];
  isColAction = [];
  isColIcon = [];
  isDateField = [];
  isColClone = [];
  isFilterableColumns=[];
  public searchValue: any = {};
  public searchCondition: any = {};
  public globalSearchValue: any = '';
  filtered = false;
  filteredData : any;
  toppings = new FormControl();
  filterSearchEnabled = true;

  isGroup(index, item): boolean{
    return item.isGroupBy;
  }

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource(this.dataSourceMain);
    this.configuration.columns.forEach(element => {
      this.searchCondition[element.column]={};
      this.searchCondition[element.column]['label']=this.configuration.columnFilterConditions[0]['label'];
      this.searchCondition[element.column]['value']=this.configuration.columnFilterConditions[0]['value'];
      this.searchCondition[element.column]['show']=this.configuration.columnFilterConditions[0].search;
    });
    this.updateColumns();
    this.dataSourceInput = this.dataSourceMain;
    this.dataSource.paginator=this.paginator;
   
  }

  ngOnChanges(changes: SimpleChanges) {
    this.dataSource.data= this.dataSourceInput = changes.dataSourceMain.currentValue;
  }

  displayCheckedItem(element: object) {
      if(_.hasIn(element, "id") && _.indexOf(this.checkedItem, element["id"]) !== -1) {
            return true
      }
      return false;
  }

  groupBy(data, columns) {
    const resObj = {};
    let self = this;
    data.forEach(element => {
      let searchWord = '';
      columns.forEach(dataget => searchWord += (element[dataget]) ? (element[dataget] + ' ') : '');
      searchWord = searchWord.trim();
      if (searchWord in resObj) {
        resObj[searchWord].push(element);
      } else {
        resObj[searchWord] = [element];
      }
    });
    const resArr = [];

    Object.keys(resObj).forEach(key => {
     
      let name = this.constructGroupingHeader(resObj[key], columns);
      resArr.push({ initial: name, isGroupBy: true });
      resObj[key].forEach(r => resArr.push(r));
    });
    return resArr;
  }

  constructGroupingHeader(object, columnArray) {
    if(_.size(columnArray) == 1) {
      let columnName = columnArray[0];
      return object[0][`${columnName}`];
    } else {
      var temp = "";
      columnArray.forEach((element, index) => {
        let columnName = columnArray[index];
        if(index == 0) {
          temp = object[0][`${columnName}`];
        } else {
          let secondNameTemp = object[0][`${columnName}`];
          temp = `${temp} & ${secondNameTemp}`;
        }
      });
      return temp
    }
  }

  updateColumns() {
    this.displayedColumns = [];
    this.displayedColumnsTemp = [];
    this.groupByOptions = [];
    this.sortable = [];
    this.configuration.columns.forEach(element => {
      if (element.visibility === true) {
        this.displayedColumns.push(element.column);
        this.displayedColumnsTemp.push({column : element.column, minWidth : _.hasIn(element, "minWidth") ? element.column : ""});
        if (element.groupBy) {
          this.groupByOptions.push({ label: element.column, state: element.groupBy });
        }
        if (element.sort || element.sort === undefined) {
          this.sortable.push(element.column);
        }
        if (element.isBtn) {
          this.isColButton.push(element.column);
        }
        if (element.isCheckBox) {
          this.isColCheckBox.push(element.column);
        }
        if (element.isAnchor) {
          this.isColAnchor.push(element.column);
        }
        if (element.isStatus) {
          this.isColStatus.push(element.column);
        }
        if (element.isAction) {
          this.isColAction.push(element.column);
        }
        if (element.isIcon) {
          this.isColIcon.push(element.column);
        }

        if (element.isClone) {
          this.isColClone.push(element.column);
        }

        if (element.isDate) {
          this.isDateField.push(element.column);
        }

        if (element.filter) {
          this.isFilterableColumns.push(element.column);
        }
      }
    });
    this.columnFilterData = (this.configuration.filters.column === true) ? JSON.parse(JSON.stringify(this.configuration.columns)) : [];
    // Sort Options
    this.sort.disabled = (this.configuration.filters.sort === undefined) ? false : !this.configuration.filters.sort;
   
  }

  toggle(type: string, colName: string) {
    this.configuration.columns.forEach((element, index) => {
      if (element.column === colName) {
        if (type === 'column') {
          this.configuration.columns[index].visibility = !this.configuration.columns[index].visibility;
        } else if (type === 'groupBy') {
          this.configuration.columns[index].groupByState = !this.configuration.columns[index].groupByState;
        } 
      }
    });
    this.updateColumns();
  }

  isSortable(colName: string) {
    return (this.sortable.indexOf(colName) !== -1) ? true : false;
  }

  isButton(colName: string) {
    return (this.isColButton.indexOf(colName) !== -1) ? true : false;
  }

  isAnchor(colName: string) {
    return (this.isColAnchor.indexOf(colName) !== -1) ? true : false;
  }

  isCheckBox(colName: string) {
    return (this.isColCheckBox.indexOf(colName) !== -1) ? true : false;
  }

  isStatus(colName: string) {
    return (this.isColStatus.indexOf(colName) !== -1) ? true : false;
  }

  isAction(colName: string) {
    return (this.isColAction.indexOf(colName) !== -1) ? true : false;
  }

  isIcon(colName: string) {
    return (this.isColIcon.indexOf(colName) !== -1) ? true : false;
  }

  isClone(colName: string) {
    return (this.isColClone.indexOf(colName) !== -1) ? true : false;
  }

  isDate(colName: string) {
    return (this.isDateField.indexOf(colName) !== -1) ? true : false;
  }

  onEditClick(item: object) {
    this.editClicked.emit({data: item} );
  }

  onDeleteClick(item: object) {
    this.onDeleteClicked.emit({data: item} );
  }

  onCheckBoxSelected(event: object, colName: String, colData) {
    if(event['checked']) {
      this.getCheckedItem.emit({ colname: colName, data: colData} );
    }
  }

  onViewClick(item: object) {
    this.onViewClicked.emit({data: item} );
  }

  onBtnClick(colName: String, colData) {
    this.buttonPressed.emit({ colname: colName, data: colData} );
  }

  onCloneClicked(colName: String, colData){
    this.cloneClicked.emit({ colname: colName, data: colData} );
  }

  onAnchorClick(colName: String, colData) {
    this.anchorPressed.emit({ colname: colName, data: colData} );
  }

  isFilterable(colName: string) {
    return (this.isFilterableColumns.indexOf(colName) !== -1);
  }

  isFilterableSearch(colName: string, searchCondition : string){
    this.configuration.columnFilterConditions.forEach(element => {
        if(element.value===searchCondition){
          this.searchCondition[colName].show=element.search;
        }
    });
    if(searchCondition=='none'){
      this.clearSearchOrColumn(colName);
    }
    
  }
  resetSearchFilter() {
    this.filterSearchEnabled = true;
  }

  // Sort Event Handler : Tested|  Added on 28-01-19
  sortData(sort: Sort) {
    let data;
    if (this.filtered) {
      data = this.filteredData.slice();
    } else {
      data = this.dataSourceInput.slice();
    }
    if (!sort.active || sort.direction === '') {
      this.dataSource.data = data;
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      return (this.sortable.indexOf(sort.active) !== -1) ? compare(a[sort.active], b[sort.active], isAsc) : 0;
    });
    
  }

  applyFilter(searchString: string, colName: string, condition: string) {
    // Conditions For transitions
    if(this.isGroupByActive){
      this.dataSource.data=this.dataSourceInput.slice();
    }
    this.filtered = (this.searchCondition === '' && colName === undefined) ? false : true;
    this.globalSearchValue = (searchString) ? searchString : '';

    const data = this.dataSourceInput.slice();

    this.dataSource.data = this.filteredData = data.filter((currentValue) => {
      if (colName !== undefined) {
        condition = (condition === undefined) ? 'none' : condition;
        currentValue[colName] = (currentValue[colName] === undefined) ? '' : currentValue[colName];
        switch (condition) {
          case 'none': return (currentValue[colName].toString().toLowerCase().indexOf(searchString.toLowerCase()) !== -1) ? true : false;
          case 'is-empty': return (currentValue[colName].toString().toLowerCase() === '') ? true : false;
          case 'is-not-empty': return (currentValue[colName].toString().toLowerCase() === '') ? false : true;
          case 'is-equal': return (currentValue[colName].toString().toLowerCase() === searchString) ? true : false;
          case 'contains': return currentValue[colName].toString().toLowerCase().includes(searchString.toLowerCase()) ? true : false;
          case 'is-not-equal': return (currentValue[colName].toString().toLowerCase() === searchString) ? false : true;
        }
      } else {
        const tempdata = this.displayedColumns.map((column) => currentValue[column]).join().toLowerCase();
        return (tempdata.indexOf(searchString.toLowerCase()) !== -1) ? true : false;
      }
    });
  }

  clearSearchOrColumn(colName?) {
    if (colName !== undefined) {
      this.searchCondition[colName].value=this.configuration.columnFilterConditions[0].value;
      this.searchCondition[colName].show=this.configuration.columnFilterConditions[0].search;
    }
    this.globalSearchValue = '';
    this.dataSource.data = this.dataSourceInput.slice();
    this.filtered = false;
  }

  groupbyData(colName) {
    if (!this.groupByColsSelected.includes(colName)) {
      if (!this.isGroupByActive) { this.isGroupByActive = true; }
      this.groupByColsSelected.push(colName);
      this.dataSource.data=(this.filtered) ? this.groupBy(this.filteredData, this.groupByColsSelected) : this.groupBy(this.dataSourceInput.slice(), this.groupByColsSelected);
    } else {
      this.groupByColsSelected = this.groupByColsSelected.filter(function (ele) {
        return ele != colName;
      });
      if (this.groupByColsSelected.length == 0) {
        this.dataSource.data = (this.filtered) ? this.filteredData : this.dataSourceInput.slice();
        this.isGroupByActive = false;
      } else {
        this.dataSource.data = (this.filtered) ? this.groupBy(this.filteredData, this.groupByColsSelected) : this.groupBy(this.dataSourceInput.slice(), this.groupByColsSelected)
      }
    }
  }

  closeAllMenus() {
    let l=this.trigger.toArray()
    for(let i=0;i<l.length;i++){
        l[i].closeMenu();
    }
  }

}

function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

