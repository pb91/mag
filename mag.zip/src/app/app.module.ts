import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from "@angular/cdk/layout";
import { FlexLayoutModule } from '@angular/flex-layout';

import { A11yModule } from '@angular/cdk/a11y';
import { BidiModule } from '@angular/cdk/bidi';
import { ObserversModule } from '@angular/cdk/observers';
import { OverlayModule } from '@angular/cdk/overlay';
import { PlatformModule } from '@angular/cdk/platform';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { PopoverComponent } from  './components/d3-drawingboard/popover/popover.component';

import 'hammerjs';
import { HighchartsChartModule } from 'highcharts-angular';
import * as Highcharts from 'highcharts';

Highcharts.setOptions({global: {
   // useUTC : true
  timezoneOffset: new Date().getTimezoneOffset()
}});
  

// Material components
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatFormFieldModule,
  MatPaginatorModule,
  MatSortModule,
  MatOptionModule,
  MatTreeModule
  } from '@angular/material';

 import { NgxMapboxGLModule } from 'ngx-mapbox-gl';

import { MatIconRegistry } from '@angular/material';
// Environment
import { environment } from 'environments/environment';

// Date range picker
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';


// Routing
import { AppRoutingModule } from './app-routing.module';

// Components
import { AppComponent, LogoutConfirmMobileDialog } from './app.component';
import { DashboardComponent } from '@appContainers/dashboard/dashboard.component';
import { LoginComponent } from '@appContainers/login/login.component';
// Services
import { AuthenticationService } from '@appServices/authentication.service';
import { NavigationService } from '@appServices/navigation.service';

import { HeaderComponent, LogoutConfirmDialog } from './components/header/header.component';
import { PlantService } from '@appServices/plant.service';
import { PlantsummaryComponent } from './containers/plantsummary/plantsummary.component';
import { WidgetComponent } from './components/widget/widget.component';
import { TableComponent } from './components/table/table.component';
import { ServiceWorkerModule } from '@angular/service-worker';

import { ToastrModule } from 'ngx-toastr';



// NGRX Related Modules
import { StoreModule, MetaReducer } from '@ngrx/store';
import { EffectsModule} from '@ngrx/effects';
// import { NavigationbarComponent } from './components/navigationbar/navigationbar.component';
import { reducers } from './globalStore/reducers/index';
import { MainContainerService } from '@appServices/mainContainer.service';
import { effects} from './globalStore/effects';
import { RequestInterceptorService } from '@appServices/request-interceptor.service';
import { MapsComponent } from './components/maps/maps.component';
import * as _ from 'lodash';
import { DaterangepickerComponent } from './components/daterangepicker/daterangepicker.component';
import { TablegridComponent } from './components/tablegrid/tablegrid.component';
import { ModalModule } from "ngx-bootstrap";
import { FilterItemDirective } from './components/tablegrid/filter-item.directive';
import { TreeviewComponent } from './components/treeview/treeview.component';
import { PiechartComponent } from './components/charts/piechart/piechart.component';
import { LinechartComponent } from './components/charts/linechart/linechart.component';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { StackedchartComponent } from './components/charts/stackedchart/stackedchart.component';
import { ProgressbarComponent } from './components/progressbar/progressbar.component';

import { ToastComponent } from './components/toast/toast.component';
import { DepartmentComponent } from './containers/department/department.component';
import { EquipmentComponent } from './containers/equipment/equipment.component';
import { EquipmentMainComponent } from './containers/equipment/equipmentMain/equipmentMain.component';
import {EquipmentViewComponent} from '@appContainers/equipment/equipmentView/equipmentView.component';
import {DeviceListComponent } from '@appContainers/equipment/equipmentDevice/equipmentDevice.component';

import { HtmltopdfComponent } from './components/htmltopdf/htmltopdf.component';
import { ActioniconsComponent } from './components/actionicons/actionicons.component';
import { DisplaypreferenceComponent } from './components/displaypreference/displaypreference.component';
import { PeakchartComponent } from './components/charts/peakchart/peakchart.component';
import { ColumnChartComponent } from './components/charts/column-chart/column-chart.component';
import { PlanthierarchyComponent } from './containers/planthierarchy/planthierarchy.component';
import { AlarmsComponent } from './containers/alarms/alarms.component';
import { UnauthorizedComponent } from './containers/unauthorized/unauthorized.component';
import { RemoveUnderscorePipe } from './shared/remove-underscore.pipe';
import {ReversePipe } from './shared/reverse.pipe';
import {FirstCharUpperPipe } from './shared/FIrstCharUpper.pipe';

// import the WindowRef provider
import {WindowRef} from './shared/WindowRef';
import { SideBarResizeEmmiterDirective } from './shared/side-bar-resize-emmiter.directive';
import { PlantComponent } from './containers/usersManagement/plant/plant.component';
import { EditComponent } from './containers/usersManagement/plant/edit/edit.component';

import { UserComponent, UserUploadDialog } from './containers/usersManagement/user/user.component';
import { UserEditComponent } from './containers/usersManagement/user/user-edit/user-edit.component';
import { UsersService } from '@appServices/users.service';
import { DialogboxComponent } from './components/dialogbox/dialogbox.component';
import { DateformatPipe } from './shared/dateformat.pipe';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { FloorPlanEditComponent } from './containers/floorplan/floor-plan-edit/floor-plan-edit.component';
import {FloorPlanViewComponent} from './containers/floorplan/floor-plan-view/floor-plan-view.component';
import {FloorPlanViewOrgComponent} from './containers/floorplan/floor-plan-view-org/floor-plan-view-org.component';
import { D3DrawingboardComponent } from './components/d3-drawingboard/d3-drawingboard.component';
import {D3DrawingboardViewComponent} from './components/d3-drawingboard/d3-drawingboard-view/d3-drawingboard-view.component';
import {FloorPlanComponent} from './containers/floorplan/floor-plan-upload/floor-plan-upload.component'

import { ListViewComponent } from './components/d3-drawingboard/list-view/list-view.component';
import {ShowCardComponent} from './components/d3-drawingboard/d3-drawingboard-view/tooltip-view/tooltip-view.component';
import {TooltipDirective} from './components/d3-drawingboard/d3-drawingboard-view/tooltip-view/tooltip-view.directive'


import { DeviceEditComponent } from './containers/planthierarchy/device-edit/device-edit.component';
import { DeviceUpdateComponent } from './containers/planthierarchy/device-update/device-update.component';
import { ForgotComponent } from './containers/forgot/forgot.component';
import { FooterComponent } from './components/footer/footer.component';
import { ChangepasswordComponent } from './containers/changepassword/changepassword.component';
import { VerifyaccountComponent } from './containers/verifyaccount/verifyaccount.component';
import { MapboxgeocoderComponent } from './components/mapboxgeocoder/mapboxgeocoder.component';
// import { CategoryComponent } from './containers/category/category.component';
// import { CategoryEditComponent } from './containers/category/category-edit/category-edit.component';


@NgModule({
  imports: [
    NgxMapboxGLModule.withConfig({
      accessToken: environment.mapBoxAccessToken
    }),
    FormsModule,
    ModalModule,
    LayoutModule,
    StoreModule.forRoot(reducers),
    EffectsModule.forRoot(effects),
    NgxDaterangepickerMd.forRoot({
      format: 'MM/DD/YYYY',
      separator: ' To ', // default is ' - '
      cancelLabel: 'Cancel', // detault is 'Cancel'
      applyLabel: 'Okay', // detault is 'Apply'
  }),
    FlexLayoutModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({ timeOut: 10000,
      preventDuplicates: true}), // ToastrModule added
    MatGridListModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTabsModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatPaginatorModule,
    MatSortModule,
    MatRadioModule,
    MatProgressBarModule,
    MatButtonToggleModule,
    MatTableModule,
    MatMenuModule,
    MatCheckboxModule, MatFormFieldModule, MatInputModule, MatOptionModule,
    MatSelectModule, MatSlideToggleModule, MatCardModule, MatChipsModule, MatDialogModule,
    // CDK
    A11yModule,
    BidiModule,
    ObserversModule,
    OverlayModule,
    PlatformModule,
    PortalModule,
    ScrollDispatchModule,
    CdkStepperModule,
    CdkTableModule,
    HighchartsChartModule,
    MatTreeModule
    // ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
  ],
  declarations: [
    AppComponent,
    LogoutConfirmMobileDialog,
    LogoutConfirmDialog,
    UserUploadDialog,
    DialogboxComponent,
    DashboardComponent,
    LoginComponent,
    HeaderComponent,
    PlantsummaryComponent,
    WidgetComponent,
    TableComponent,
    MapsComponent,
    DaterangepickerComponent,
    TablegridComponent,
    FilterItemDirective,
    TreeviewComponent,
    PiechartComponent,
    LinechartComponent,
    DropdownComponent,
    StackedchartComponent,
    ProgressbarComponent,
    ToastComponent,
    DepartmentComponent,
    EquipmentComponent,
    EquipmentMainComponent,
    EquipmentViewComponent,
    DeviceListComponent,
    HtmltopdfComponent,
    ActioniconsComponent,
    DisplaypreferenceComponent,
    PeakchartComponent,
    ColumnChartComponent,
    PlanthierarchyComponent,
    AlarmsComponent,
    UnauthorizedComponent,
    RemoveUnderscorePipe,
    ReversePipe,
    FirstCharUpperPipe,
    SideBarResizeEmmiterDirective,
    PlantComponent,
    EditComponent,
    UserComponent,
    UserEditComponent,
    DateformatPipe,
    FileUploadComponent,
    FloorPlanEditComponent,
    FloorPlanViewComponent,
    FloorPlanViewOrgComponent,
    D3DrawingboardComponent,
    D3DrawingboardViewComponent,
    ListViewComponent,
        ShowCardComponent,
    PopoverComponent,
    DeviceEditComponent,
    DeviceUpdateComponent,
    ForgotComponent,
    FooterComponent,
    ChangepasswordComponent,
    VerifyaccountComponent,
    MapboxgeocoderComponent,
    FloorPlanComponent,
    TooltipDirective,
    // CategoryComponent,
    // CategoryEditComponent
  ],
  providers: [
    AuthenticationService,
    UsersService,
    { provide: HTTP_INTERCEPTORS, useClass: RequestInterceptorService, multi: true },
    MatIconRegistry,
    PlantService,
    MainContainerService,
    NavigationService,
    ToastComponent,
    WindowRef
  ],
  entryComponents: [TreeviewComponent,LogoutConfirmDialog, LogoutConfirmMobileDialog, DialogboxComponent, UserUploadDialog , PopoverComponent,ShowCardComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }