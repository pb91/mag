import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { Notifications } from '../models/headerBar/notifications.model';
import { CombinedNavigation } from '../models/navigationBar/combined.model';
@Injectable({
  providedIn: 'root'
})
export class MainContainerService {

  constructor(private http: HttpClient) {}

  getNotifications(): Observable<Notifications> {
    return this.http
      .get<Notifications>(
        'http://pp.dlv1.logichive.in:8999/api/testjson'
      )
      .pipe(map(result => result));
  }

  getPreferences(): Observable<CombinedNavigation> {
    // return 
    return this.http
      .get<CombinedNavigation>(
        'http://pp.dlv1.logichive.in:8999/api/preference'
      )
      .pipe(map(result => result
      ));
  }
}
