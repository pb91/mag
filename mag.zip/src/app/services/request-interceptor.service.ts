import { throwError, Observable, BehaviorSubject } from 'rxjs';
import { ToastComponent } from '@appComponents/toast/toast.component';
import { take, filter, catchError, switchMap } from 'rxjs/operators';
import { Injectable, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '@appModels/user';
import * as moment from 'moment';

import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpClient
} from '@angular/common/http';

import { AuthenticationService } from './authentication.service';
import { environment } from 'environments/environment';

@Injectable()
export class RequestInterceptorService implements HttpInterceptor {
  private refreshTokenInProgress = false;
  // Refresh Token Subject tracks the current token, or is null if no token is currently
  // available (e.g. refresh pending).
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(public inj: Injector,
    private router: Router,
    public notificationError : ToastComponent) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const auth = this.inj.get(AuthenticationService);
    return next.handle(this.addAuthenticationToken(request, auth)).pipe(
      catchError(error => {
        // We don't want to refresh token for some requests like login or refresh token itself
        // So we verify url and we throw an error if it's the case
        if (request.url.includes('token') || request.url.includes('login')) {
          // We do another check to see if refresh token failed
          // In this case we want to logout user and to redirect it to login page
          if (request.url.includes('token')) {
            auth.logout();
          } else if (request.url.includes('login')) {
           // auth.logout();
          }

          this.notificationError.showError(error);
          return throwError(error);
        }
        // If error status is different than 401 we want to skip refresh token
        // So we check that and throw the error if it's the case
        if (error.status !== 401) {
          if (request.url.includes('refresh') && error.status === 503) {
              this.notificationError.showError(error);
              auth.clearUser();
          } else {
            this.notificationError.showError(error);
            return throwError(error);
          }
        }

        let savedTime = localStorage.getItem('setTime');
        if (error.status === 401 && savedTime !== null && savedTime !== undefined) {
          let now = moment().local().valueOf();
          let difference = now - parseInt(savedTime);
          if(difference < 300000) {
            return next.handle(this.addAuthenticationToken(request, auth));
          }
        }
    

        if (this.refreshTokenInProgress) {
          // If refreshTokenInProgress is true, we will wait until refreshTokenSubject has a non-null value
          // – which means the new token is ready and we can retry the request again
          return this.refreshTokenSubject.pipe(
            filter(result => result !== null),
            take(1),
            switchMap(() =>
              next.handle(this.addAuthenticationToken(request, auth))
            )
          );
        } else {

          // This is workaround to validate, 
          // If we called refresh API less than 5 seconds we are avoid calling again.
          // let savedTime = localStorage.getItem('setTime');
          // let difference = 0;
          // if(savedTime !== null && savedTime !== undefined) {
          //   let now = moment().local().valueOf();
          //   difference = now - parseInt(savedTime);
          // } else {
          //   difference = 300001;
          // }
          
          // if(difference > 300000) {
            this.refreshTokenInProgress = true;
            // Set the refreshTokenSubject to null so that subsequent API calls will wait until the new token has been retrieved
            this.refreshTokenSubject.next(null);
            // Call auth.refreshAccessToken(this is an Observable that will be returned)
            return auth.refreshToken().pipe(
              switchMap((token: any) => {
                // When the call to refreshToken completes we reset the refreshTokenInProgress to false
                // for the next time the token needs to be refreshed

                this.refreshTokenInProgress = false;
                this.refreshTokenSubject.next(token);
  
                return next.handle(this.addAuthenticationToken(request, auth));
              }),
              catchError((err: any) => {

                this.refreshTokenInProgress = false;
                this.notificationError.showError(error);
                return throwError(error);
              })
            );
          //}
        }
      })
    );
  }
  
  // tslint:disable:indent
  
  addAuthenticationToken(request, auth: AuthenticationService) {
    // Get access token from Local Storage
     const accessToken = auth.getAuthToken();
   // const accessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkN0ZlFDOExlLThOc0M3b0MyelFrWnBjcmZPYyIsImtpZCI6IkN0ZlFDOExlLThOc0M3b0MyelFrWnBjcmZPYyJ9.eyJhdWQiOiJodHRwczovL3Byb2RhZGVhdG9uaW90Lm9ubWljcm9zb2Z0LmNvbS9wcm9kd2ViYXBpc2VydmljZSIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzgzZTNmNmY0LTNlZTktNGIzOC1hOTMwLTU4ZTcxN2M5MDBjNS8iLCJpYXQiOjE1NjAyMzkwMzUsIm5iZiI6MTU2MDIzOTAzNSwiZXhwIjoxNTYwMjQyOTM1LCJhY3IiOiIxIiwiYWlvIjoiNDJaZ1lBaFJjY2lkTVQxeXlxOWxrVklOUDZUTWxHU1VydW8xQlB6bi9UZmRMY003V1FJQSIsImFtciI6WyJwd2QiXSwiYXBwaWQiOiJlMDkyMGJjOS01MWI2LTQwMzItODFmZC1kMTgwODUxZGQwNTgiLCJhcHBpZGFjciI6IjAiLCJpcGFkZHIiOiIyMy4xMDAuMjQuNCIsIm5hbWUiOiJZYXN2YW50aCIsIm9pZCI6IjY0ZjEwOTQ5LWEzNDUtNDVmMy05Y2RiLWQ1ZTZlYWFlY2IxMiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6IjNmOHpiVGU5OUdXVFJlSHg5amIwVEpXSE9sMlFvSEFleHVzM05EbWRLcDQiLCJ0aWQiOiI4M2UzZjZmNC0zZWU5LTRiMzgtYTkzMC01OGU3MTdjOTAwYzUiLCJ1bmlxdWVfbmFtZSI6ImY1ZjQyMDU4LWIzMDUtNDAxNy1hNTdiLTFkN2Q3ZjJlMWMxMkBQcm9kQURFYXRvbklvVC5vbm1pY3Jvc29mdC5jb20iLCJ1cG4iOiJmNWY0MjA1OC1iMzA1LTQwMTctYTU3Yi0xZDdkN2YyZTFjMTJAUHJvZEFERWF0b25Jb1Qub25taWNyb3NvZnQuY29tIiwidXRpIjoiUmVSTnhkZ2ZtVS04MFIwX3Fpb0lBQSIsInZlciI6IjEuMCJ9.HgQpEs_9ki98vzyNJDZihR7D9jXW5U7Puw4FVHmultTM82NE0ioC7oe_svx17BC_ohSrKWSRUhn9tuYaoEKVMuI4ZbtY4TVgiHl7tzgowgIjOxsH-hacEMVqtEaSkl-ry60l2kuI2IIXeNVqz-VVW232aGtTBIXdqMNvLH510GAIXISjzk5sPxrIHXCMeaA_tiIQTgUBExdlffKiwV00Au-9GpCqUYvIQQAO7K1x6bpBc5AhcoIuVnXrwNdkXZJOtQemrEh8Y1Kv0RGzaqHy2WIZ7JKH0TLNQjrf5DoJ_zNKIFqyUVJZ1GzYYsDauqQFzhmcYrlgYG4WJLBzWt54_Q";

    // If access token is null this means that user is not logged in
    // And we return the original request
    
    // if (request.url.includes('login') || !accessToken) {
    if (request.url.includes('login') || request.url.includes('resetpassword') || request.url.includes('verifyverificationcode') || request.url.includes('userregistration') || request.url.includes('validateregistration')  || request.url.includes('setpassword')) {
      return request;
    }

    if(accessToken == "undefined" || !accessToken) {
     auth.clearUser();
      this.router.navigateByUrl('sign-in');
    }

    // For file upload we have to remove the content type key, so we adding below condition.
    if (request.url.includes('hierarchy') || request.url.includes('import')|| request.url.includes('upload')) {
      return request.clone({
        setHeaders: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
          'Ocp-Apim-Subscription-Key': environment.subscriptionKey,
          Authorization: `Bearer ${accessToken}`
        }
      });
    }

    // // For KPI ocp-subscription key is different.
    // if (request.url.includes('Telemetry')) {
    //     console.log("telemetry");
    // }

    return request.clone({
      setHeaders: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'Content-Type': 'application/json',
        'Ocp-Apim-Trace' : true,
        'Ocp-Apim-Subscription-Key': environment.subscriptionKey,
        Authorization: `Bearer ${accessToken}`
      }
    });

  }
}