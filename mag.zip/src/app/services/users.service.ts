import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs/Observable';
import { tap, map } from 'rxjs/operators';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  public baseURL = environment.authUrl;
  public subscriptionKey = environment.subscriptionKey;
  public applicationId = environment.applicationId;

  constructor(private http: HttpClient) {
  }

  getActivityLogs(){ 
    let url = `${environment.evaBaseURL}/activitylog/getlog`;    
    return this.http.get<any>(url)
    .pipe(map(result=> result))
  }


  /** Create & Update Plant */
  createUpdatePlant(object: any, plantId : string) {
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    
    let url:string;
    if(plantId) {
      url = `${environment.apiBaseUrl}/updateplant/${plantId}`;
    } else { 
      url = `${environment.apiBaseUrl}/createplant`;
    }

    return this.http.put(url, object,
      { headers }).pipe(
        map(data => {
          // successful
          return data;
        })
      );
  }

  /** Delete Plant By ID */
  deletePlantById(plantId: any) {
    let url = `${environment.apiBaseUrl}/deleteplant/${plantId}`;
    return this.http.delete(url).pipe(
      tap(data => data)
    );
  }

  getUserList(plantId: string) {
    
    let url = `${environment.apiBaseUserUrl}/users/viewusers`;
    if(plantId) {
      url = `${environment.apiBaseUserUrl}/plant/viewusers/${plantId}`;
    }
    
    return this.http.get<any>(url)
      .pipe(map(result => result));
  }

  getLocalFormatDate(dateString){
    var gmtDateTime = moment.utc(dateString);
    let local = gmtDateTime.local().valueOf();
    return moment(local).format('llll')
  }

  updateUserPerInfo(obj: any, plantId: string) {
    const headers = new HttpHeaders()
    .set("Content-Type", "application/json");
    let url = `${environment.apiBaseUserUrl}/users/updateuserinformation?siteid=${plantId}`;
    return this.http.put(url, obj,
      { headers }).pipe(
        map(data => {

          return data;
        })
      );

  }

  saveUser(obj: any, plantId: string) {
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    
    let url = `${environment.apiBaseUserUrl}/users/createuser`;
    if(plantId) {
        url = `${url}?siteid=${plantId}`;
    }
    
    return this.http.put(url, obj,
      { headers }).pipe(
        map(data => {
          // successful
          return data;
        })
      );

  }

  getSelectedUser(id: any, siteId: any) {
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    let url = `${environment.apiBaseUserUrl}/users/userdetail/${id}`;
    if(siteId) {
      url = `${url}?siteid=${siteId}`;
    }
    
    return this.http.get(url,
      { headers }).pipe(
        map(data => {
          // successful
          return data;
        })
      );
  }

   /** Get Plant By ID */
   GetPlantById(plantId: any) {
    let url = `${environment.apiBaseUrl}/plantdetail/${plantId}`;
    return this.http.get(url).pipe(
      tap(data => data)
    );
  }

  deleteSelectedUser(id: any, plantId: string) {
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");

    let url = `${environment.apiBaseUserUrl}/users/deleteuser/${id}`;
    if(plantId) {
      url = `${url}?siteid=${plantId}`;
    }
    return this.http.delete(url,
      { headers }).pipe(
        map(data => {
          // successful
          return data;
        })
      );
  }

    /** GET Upload Plant Hierarchy */
    uploadBlukUser(plantid:string, file:any): Observable<any> {
      var fd = new FormData();
      fd.append('file', file);
      const headers = new HttpHeaders()
      let url = `${environment.apiBaseUserUrl}/users/import/${plantid}`;
      return this.http.put(url, fd , { headers }).pipe(
          map(data => {
            // successful
            return data;
          })  
        );
   }


  

}