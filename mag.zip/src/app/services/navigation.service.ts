import { Observable, Subject } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class NavigationService {
    private toggleSource = new Subject<any>();
    navToggled$ = this.toggleSource.asObservable();
    toggleMenu() {
        this.toggleSource.next(true);
    }
}

export class MessageService {
    private _listners = new Subject<any>();

    listen(): Observable<any> {
       return this._listners.asObservable();
    }

    filter(filterBy: string) {
       this._listners.next(filterBy);
    }
}