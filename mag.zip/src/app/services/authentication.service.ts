import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, share, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from 'environments/environment';
import * as _ from 'lodash';
import { NavigationService } from '@appServices/navigation.service';
import * as moment from 'moment';

import { User } from '@appModels/user';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  public baseURL = environment.authUrl;
  public subscriptionKey = environment.subscriptionKey;
  public applicationId = environment.applicationId;

  constructor(private http: HttpClient,
    private router: Router,
    private _navigationService: NavigationService
    ) {
    this.currentUserSubject = new BehaviorSubject<User>(
      JSON.parse(localStorage.getItem('currentUser'))
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  login(username: string, password: string) {
    const headers = new HttpHeaders()
      .append('Content-Type', 'application/json')
      .append('Ocp-Apim-Subscription-Key', this.subscriptionKey);
    return this.http
      .post<any>(`${this.baseURL}/login`,{
          user: username,
          password: password,
          applicationId: this.applicationId
        },
        { headers: headers }
      )
      .pipe(
        map(user => {
          // login successful
          if (user) {
            // store user details in local storage to keep user logged in between page refreshes
            localStorage.setItem('currentUser', JSON.stringify(user));
            localStorage.setItem('accessToken', user.Data.token);
            localStorage.setItem('userRoles', user.Data.UserRole);
            this.currentUserSubject.next(user);
          }
          return user;
        })
      );
  }

  resetPassword(username: string) {
    const headers = new HttpHeaders()
    .append('Content-Type', 'application/json')
    .append('Ocp-Apim-Subscription-Key', this.subscriptionKey);
      return this.http.get<any>(`${environment.evaAuth}/resetpassword?emailid=${username}`, { headers: headers })
        .pipe(
          tap(device => device)
        );
  }

  clearUser(){
    localStorage.removeItem('currentUser');
    localStorage.removeItem('accessToken');
    localStorage.removeItem('userRoles');
    this.currentUserSubject.next(null);
    this.router.navigateByUrl('sign-in');
  }

  logout() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const userId = currentUser && currentUser.Data['id'];
    let url = `${this.baseURL}/logoff?userid=${userId}`;
    return this.http.delete<any>(url).pipe(map(result => {
      localStorage.removeItem('currentUser');
      localStorage.removeItem('accessToken');
      localStorage.removeItem('userRoles');
      localStorage.removeItem('setTime');
      this.currentUserSubject.next(null);
      // remove user from local storage to log user out
    }));
  }

  getAuthToken() {
    return localStorage.getItem('accessToken');
  }

  changePassword(requestPayload: object): Observable<string> {
    const headers = new HttpHeaders()
    .append('Content-Type', 'application/json')
    return this.http
    .post<any>(`${environment.evaAuth}/changepassword`,requestPayload,
      { headers: headers }
    )
    .pipe(
      map(user => {
        return user;
      })
   );
  }
  
  verifyAccount(userId: string, requestPayload: object): Observable<string> {
    const headers = new HttpHeaders()
    .append('Content-Type', 'application/json')
    .append('Ocp-Apim-Subscription-Key', this.subscriptionKey);
    return this.http
    .post<any>(`${environment.evaAuth}/verifyverificationcode/${userId}`,requestPayload,
      { headers: headers }
    )
    .pipe(
      map(user => {
        return user;
      })
   );
  }

  refreshToken(): Observable<string> {
    const headers = new HttpHeaders()
      .append('Content-Type', 'application/json')
      .append('Ocp-Apim-Subscription-Key', this.subscriptionKey);
    const userData = JSON.parse(localStorage.getItem('currentUser'));
    return this.http
      .post(`${this.baseURL}/refresh`,
        { user: userData.Data.email, token: localStorage.getItem('accessToken') },
        { headers: headers }
      )
      .pipe(
        tap(data => {
          let response = data && data['Data'] && data['Data'];
          let currentTime = moment().local().valueOf();
          localStorage.setItem('setTime', currentTime.toString());
          localStorage.setItem('accessToken', response['Token']);
        }),
        map(data => data['Data'].Token)
      );
  }

  registerUser(email: string): Observable<string> {
    const headers = new HttpHeaders()
    .append('Content-Type', 'application/json')
    .append('Ocp-Apim-Subscription-Key', this.subscriptionKey);
    let url = `${environment.apiBaseUserUrl}/users/userregistration/${email}`;
    return this.http.get<any>(url, { headers: headers })
        .pipe(
          tap(device => device)
        );
  }


  registerVerifyCode(verifyCode: number, emailId: string): Observable<any> {
    const headers = new HttpHeaders()
    .append('Content-Type', 'application/json')
    .append('Ocp-Apim-Subscription-Key', this.subscriptionKey);
    let url = `${environment.apiBaseUserUrl}/users/validateregistration`;

    let requestPayload = {
      verification_code : verifyCode,
      email_id: emailId
    }
    return this.http.post<any>(url,requestPayload, {observe: 'response', headers: headers}).pipe(
      map(user => {
        return user;
      })
   );
  }

  setPassword(userDetails: object): Observable<string> {
    const headers = new HttpHeaders()
      .append('Content-Type', 'application/json')
      .append('Ocp-Apim-Subscription-Key', this.subscriptionKey);
      let url = `${environment.apiBaseUserUrl}/users/setpassword`;
      return this.http.post<any>(url,userDetails,{ headers: headers }).pipe(
        map(user => {
          return user;
        })
    );
  }

}
