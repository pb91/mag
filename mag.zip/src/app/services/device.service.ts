import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { tap, map } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class DeviceService {
  public baseURL = environment.evaBaseURL;

  constructor(private http: HttpClient) { }

  getDeviceDeatils(deviceId:string, plantId: string): Observable<any> {
    let url = `${this.baseURL}/devices/latestreading/${deviceId}?plantId=${plantId}`;
    return this.http
        .get<any>(url)
        .pipe(map(result => result));
  }

  /** GET Device **/
  getDeviceList(plantId : any): Observable<any> {
    return this.http.get<any>(`${this.baseURL}/devices/syncdevicetree/${plantId}`)
      .pipe(
        tap(device => device)
      );
  }

  /** Delete Device By Plant id */
  deleteDeviceById(plantId: string, deviceId: string) {
    let url = `${this.baseURL}/devices/deletedevice/${deviceId}?plantId=${plantId}`;
    return this.http.delete(url).pipe(
      tap(data => data)
    );
  }

  /** Create Device */
  createUpdateDevice(object: any, plantId : string) {
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    let url:string;
    url = `${this.baseURL}/devices/deviceregistration/${plantId}`;

    return this.http.post(url, object,
      { headers }).pipe(
        map(data => {
          return data;
        })
      );
  }

   /** Update Device */
  updateDevice(object: any, plantId : string) {
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    let url:string;
    url = `${this.baseURL}/devices/updatedevice/${plantId}`;
    return this.http.put(url, object , { headers }).pipe(
        map(data => {
          // successful
          return data;
        })
      );
 }

 /**  Category Section  */
  createCategory(object: any, plantId: string) {
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    let url: string;
    url = `${environment.evaCategory}/category/createcategory/${plantId}`;
    return this.http.post(url, object,
      { headers }).pipe(
        map(data => {
          return data;
        })
      );
  }

  /**  View Category Section  */
  viewCategory(categoryId: any, plantId: string) {
    let url: string;
    url = `${environment.evaCategory}/category/viewcategory/${plantId}?category_id=${categoryId}`;
    return this.http.get<any>(url).pipe(
      tap(device => device)
    );
  }
}

