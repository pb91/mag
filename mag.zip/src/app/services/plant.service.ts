import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { tap, map } from 'rxjs/operators';
import { forkJoin } from "rxjs/observable/forkJoin";
import { environment } from 'environments/environment';
import * as _ from 'lodash';
import { SELECTED_USER_FAIL } from '../globalStore';

@Injectable({
  providedIn: 'root'
})
export class PlantService {

  constructor(
    private http: HttpClient) { }

  getInterval(interval: string){
    if(interval == "minute") { 
      return "5min"
    } else if (interval == "hourly") {
      return "60min"
    } else if (interval == "daily") {
      return "24hr"
    } else {
      return interval;
    }
  }

  getFormatURL(url:string, trait:string, tag:string, from:string, to:string, id: string, interval:string){
    let formattedURL = url;
    // Mandatory Fields
    formattedURL= `${formattedURL}?from=${from}`;
    formattedURL= `${formattedURL}&to=${to}`;
    // Optional Fields
    formattedURL= (tag) ? `${formattedURL}&tag=${tag}` : formattedURL;
    formattedURL= (trait) ? `${formattedURL}&rolluplevel=${trait}` : formattedURL;
    formattedURL= (trait) ? `${formattedURL}&trait=${trait}` : formattedURL;
    formattedURL= (id) ? `${formattedURL}&idlist=${id}` : formattedURL;
    formattedURL= (interval) ? `${formattedURL}&interval=${interval}` : formattedURL;
    return formattedURL;
  }

  // Equpiment
  constructRequestBody(deviceId: string, deviceName: string, startDate: string, endDate: string, interval: string, kpi: string){
    return {
      "deviceid" : deviceId,
      "devicename" :deviceName,
      "endDate" : endDate,
      "startDate" : startDate,
      "interval" :  this.getInterval(interval), 
      "kpi" : kpi
    }
  }

  // Department
  constructMultipleIdRequestBody(deviceId: string, startDate: string, endDate: string, interval: string, kpi: string, valueType : string){
    let departmentid = deviceId.split(',');

    return valueType ? {
      "departmentid" : departmentid,
      "endDate" : endDate,
      "startDate" : startDate,
      "interval" :  this.getInterval(interval), 
      "kpi" : kpi,
      "valueType": "cumulative"
    } : {
      "departmentid" : departmentid,
      "endDate" : endDate,
      "startDate" : startDate,
      "interval" :  this.getInterval(interval), 
      "kpi" : kpi,
    } 
  }

    // Building
    constructBuildingRequestBody(deviceId: string, startDate: string, endDate: string, interval: string, kpi: string, valueType : string){
      let buildingid = deviceId.split(',');
  
      return valueType ? {
        "buildingid" : buildingid,
        "endDate" : endDate,
        "startDate" : startDate,
        "interval" :  this.getInterval(interval), 
        "kpi" : kpi,
        "valueType": "cumulative"
      } : {
        "buildingid" : buildingid,
        "endDate" : endDate,
        "startDate" : startDate,
        "interval" :  this.getInterval(interval),
        "kpi" : kpi,
      } 
    }

    // Global dashboard page
    constructPlantLevel(deviceId: string, startDate: string, endDate: string, kpi: string){
      let plantId = deviceId.split(',');
  
      return {
        "plantid" : plantId,
        "endDate" : endDate,
        "startDate" : startDate,
        "interval" :  "monthly", 
        "kpi" : kpi,
      } 
    }
  
  /** GET Plants from the server */
  getPlantList(): Observable<any> {
    return this.http.get<any>(environment.apiBaseUrl)
      .pipe(
        tap(plantsDetails => plantsDetails)
      );
  }

  /** GET Upload Plant Hierarchy */
  getUploadPlantHierarchy(plantid:string, file:any): Observable<any> {
    var fd = new FormData();
    fd.append('file', file);
    const headers = new HttpHeaders()
    let url = `${environment.apiBaseUrl}/hierarchy/${plantid}`;
    return this.http.put(url, fd , { headers }).pipe(
        map(data => {
          // successful
          return data;
        })  
      );
 }

   /** GET Upload Plant Hierarchy */
   generateCode(plantid:string): Observable<any> {
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    let url = `${environment.apiBaseUrl}/activationcode/${plantid}`;
    return this.http.post(url,{},{ headers: headers }).pipe(
        map(data => {
          // successful
          return data;
        })
      );
 }

  /** GET Plants By ID from the server */
  getPlantById(plantId : any): Observable<any> {
    return this.http.get<any>(`${environment.apiBaseUrl}/${plantId}/detail`)
      .pipe(
        tap(plantDetails => plantDetails)
      );
  }

  getGlobalEnergySavingData(from : string, to : string){
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const userId = currentUser && currentUser.Data['id'];
    return this.http.get<any>(`${environment.apiBaseUrl}/globalenergysaving?userid=${userId}&from=${from}&to=${to}`)
    .pipe(map(result=>result))
  }

  getGlobalEnergyConsumptionData(from : string, to : string){ 
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const userId = currentUser && currentUser.Data['id'];
    return this.http.get<any>(`${environment.apiBaseUrl}/globalenergyconsumption?userid=${userId}&from=${from}&to=${to}`)
    .pipe(map(result=>result))
  }

  getCostAndConsump(plantId: string, trait: string, tag:string, from: string, to: string, id: string, interval: string) : Observable<any>  {
    let cost = this.getEnergyCostTrend(plantId, trait, tag, from, to, id, interval);
    let consumption = this.getEnergyConsTrend(plantId, trait, tag, from, to, id, interval);
    return forkJoin([cost, consumption]).pipe(
      tap(data => data)
    );
  }

  getEnergyConsumption(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/energyconsumption`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http
        .get<any>(formattedURL)
        .pipe(map(result => result));
  }

  getCarbonEmmision(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/carbonfootprint`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http
        .get<any>(formattedURL)
        .pipe(map(result => result));
  }

  getDeviceStatus(plantId:string): Observable<any> {
    let url = `${environment.apiBaseAssetUrl}/${plantId}/devicestatus`;
    return this.http
        .get<any>(url)
        .pipe(map(result => result));
  }

  getEnergyCost(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/energycost`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http
    .get<any>(formattedURL)
    .pipe(map(result => result));
  }

  getEnergyCostTrend(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/energycost`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    formattedURL = `${formattedURL}&traittype=Trend`;
    return this.http
    .get<any>(formattedURL)
    .pipe(map(result => result));
  }

  getLoadPattern(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/loadpattern`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    formattedURL = `${formattedURL}&traittype=Trend`;
    return this.http
    .get<any>(formattedURL)
    .pipe(map(result => result));
  }
  
  getEnergyIdle(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/energyidling`
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http
        .get<any>(formattedURL)
        .pipe(map(result => result));
  }

  getEnergySaving(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/energysaving`
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http
        .get<any>(formattedURL)
        .pipe(map(result => result));
  }

  getEnergyConsTrend(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/energyconsumption/trend`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    formattedURL = `${formattedURL}&traittype=Trend`;
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));
  }

  getPowerDemand(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/powerdemand`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    formattedURL = `${formattedURL}&traittype=Trend`;
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));
  }

  getPeakDemand(plantId:string, trait:string, tag:string, from:string, to:string, id: string, interval:string): Observable<any> {
    let url = `${environment.apiBaseUrl}/${plantId}/peakdemand`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    formattedURL = `${formattedURL}&traittype=Trend`;
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));
  } 

  getPowerFactor(plantId: string, trait: string, tag:string, from: string, to: string, id: string, interval: string) : Observable<any>  {
    let url = `${environment.apiBaseUrl}/${plantId}/powerfactor`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    formattedURL = `${formattedURL}&traittype=Trend`;
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));
  }

  getAvailabilityUtilization(plantId: string, trait: string, tag:string, from: string, to: string, id: string, interval: string) : Observable<any>  {
    let url = `${environment.apiBaseUrl}/${plantId}/utilization`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));
  }


  getAvailability(plantId: string, trait: string, tag:string, from: string, to: string, id: string, interval: string) : Observable<any>  {
    let url = `${environment.apiBaseUrl}/${plantId}/availability`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));
  }

  getUtilization(plantId: string, trait: string, tag:string, from: string, to: string, id: string, interval: string) : Observable<any>  {
    let url = `${environment.apiBaseUrl}/${plantId}/utilization`;
    let formattedURL = this.getFormatURL(url, trait, tag, from, to, id, interval);
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));
  }

  getPeakDemandAndPowerDemand(plantId: string, trait: string, tag:string, from: string, to: string, id: string, interval: string) : Observable<any>  {
    let peakDemand = this.getPeakDemand(plantId, trait, tag, from, to, id, interval);
   let powerDemand = this.getPowerDemand(plantId, trait, tag, from, to, id, interval);
    return forkJoin([peakDemand, powerDemand]);
  }

  getAlarms(plantId: string, from: string, to: string) : Observable<any>  {
    let url = `${environment.apiBaseAssetUrl}/${plantId}/alarms`;
    let formattedURL = this.getFormatURL(url, null, null, from, to, null, null);
    return this.http.get<any>(formattedURL)
    .pipe(map(result => result));    
  }

  // Equipment Related changes

  getEquipmentTelemetry(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) :Observable<any> {
    let url = `${environment.kpiBaseURL}/EquipmentTelemetry?plantid=${plantId}`;
    let requestBody = this.constructRequestBody(deviceId, trait, from, to, interval, kpi);
    return this.http.post<any>(url, requestBody).pipe(map(result => result));
  }

  getCostAndConsumpEquipment(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) : Observable<any>  {
    let cost = this.getEquipmentTelemetry(plantId, trait, "energyconsumed", from, to, deviceId, interval);
    let consumption = this.getEquipmentTelemetry(plantId, trait, "energyCost", from, to, deviceId, interval);
    return forkJoin([cost, consumption]).pipe(
      tap(data => data)
    );
  }

  // Department Summary 
  getDepartmentCumulative(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) :Observable<any> {
    let url = `${environment.kpiBaseURL}/DepartmentTelemetry?plantid=${plantId}`;
    let requestBody = this.constructMultipleIdRequestBody(deviceId, from, to, interval, kpi, "cumulative");
    return this.http.post<any>(url, requestBody).pipe(map(result => result));
  }

  getDepartmentTelemetry(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) :Observable<any> {
    let url = `${environment.kpiBaseURL}/DepartmentTelemetry?plantid=${plantId}`;
    let requestBody = this.constructMultipleIdRequestBody(deviceId, from, to, interval, kpi, null);
    return this.http.post<any>(url, requestBody).pipe(map(result => result));
  }

  getCostAndConsumpDepartment(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) : Observable<any>  {
    let cost = this.getDepartmentTelemetry(plantId, trait, "energyconsumed", from, to, deviceId, interval);
    let consumption = this.getDepartmentTelemetry(plantId, trait, "energyCost", from, to, deviceId, interval);
    return forkJoin([cost, consumption]).pipe(
      tap(data => data)
    );
  }

  // Plant Summary 
  getPlantCumulative(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) :Observable<any> {
    let url = `${environment.kpiBaseURL}/BuildingTelemetry?plantid=${plantId}`;
    let requestBody = this.constructBuildingRequestBody(deviceId, from, to, interval, kpi, "cumulative");
    return this.http.post<any>(url, requestBody).pipe(map(result => result));
  }

  getPlantTelemetry(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) :Observable<any> {
    let url = `${environment.kpiBaseURL}/BuildingTelemetry?plantid=${plantId}`;
    let requestBody = this.constructBuildingRequestBody(deviceId, from, to, interval, kpi, null);
    return this.http.post<any>(url, requestBody).pipe(map(result => result));
  }

  getCostAndConsumpPlant(plantId: string, trait: string, kpi: string, from: string, to: string, deviceId: string,  interval: string) : Observable<any>  {
    let cost = this.getPlantTelemetry(plantId, trait, "energyconsumed", from, to, deviceId, interval);
    let consumption = this.getPlantTelemetry(plantId, trait, "energyCost", from, to, deviceId, interval);
    return forkJoin([cost, consumption]).pipe(
      tap(data => data)
    );
  }

  // Global Summary 
  getGlobalKPI(from : string, to : string, id: string, kpi: string) :Observable<any> {
    let url = `${environment.kpiBaseURL}/PlantTelemetry`;
    let requestBody = this.constructPlantLevel(id, from, to, kpi);
    return this.http.post<any>(url, requestBody).pipe(map(result => result));
  }
  
  //Add building

  addAsset(plantId: string , type : string, id: string, name : string ){
    let url = `${environment.apiBaseUrl}/create/${plantId}?assettype=${type}`;
   // let formattedURL = this.getFormatURL(url, plantId, type, id, name , );
   let reqPay ;
   if(type.trim() === "building"){
    reqPay = {"buildingid" :id , "buildingname" : name}
   }else if (type.trim() === "department"){
    reqPay = {"departmentid" :id , "departmentname" : name}
   }else if(type.trim() === "equipment"){
    reqPay = {"equipmentname" :name , "description" : name}
   }
    return this.http.post<any>(url ,reqPay)
    .pipe(map(result => result));   
  }


  updateAsset(plantId: string , type : string, data:any){
    let url = `${environment.apiBaseUrl}/update/${plantId}?assettype=${type}`;
    // let formattedURL = this.getFormatURL(url, plantId, type, id, name , );
     return this.http.post<any>(url , data)
     .pipe(map(result => result));   
  }

  deleteAsset(plantId: string , type : string, data:any){
    let reqPay ;
    if(type.trim() === "building"){
     reqPay = data.BuildingID;
    }else if (type.trim() === "department"){
     reqPay = data.DepartmentID;
    }else if(type.trim() === "equipment"){
      reqPay =  data.Equipment;
    }
    
    let url = `${environment.apiBaseUrl}/delete/${plantId}?assettype=${type}&assetid=${reqPay}`;
    // let formattedURL = this.getFormatURL(url, plantId, type, id, name , );
     return this.http.delete<any>(url , data)
     .pipe(map(result => result));   
  }

  saveCoordinates(event, data, palette, hex, name , imageName , plantId , selectedBuilding , selectedDepartment , type){

    let reqPay ;
    if(type.trim() === "building"){
     reqPay = plantId;
    }else if (type.trim() === "department"){
     reqPay = selectedBuilding;
    }else if(type.trim() === "equipment"){
      reqPay = selectedDepartment;
    }

    let url = `${environment.apiBaseUrl}/uploadcoordinate/${plantId}?assettype=${event}&assetid=${reqPay}&imagepath=${imageName}`;
    // let formattedURL = this.getFormatURL(url, plantId, type, id, name , );
    let json = {
      data,
      palette,
      hex,
      name
    }
     return this.http.post<any>(url , json)
     .pipe(map(result => result));   
  }

  deleteImage(id, rollup, image , data){
    //let url = `${environment.apiBaseUrl}/plants/delete/image/${id}`;
    let url = `${environment.apiBaseUrl}/delete/image/${id}?imagePath=${data.imagePath}&rolluplevel=${data.rolluplevel}&id=${data.id}`;
    // let formattedURL = this.getFormatURL(url, plantId, type, id, name , );
  //  let data = {
  //     "imagePath" : image,
  //     "rolluplevel":rollup,
  //     "id":id
  //   }
     return this.http.delete<any>(url )
     .pipe(map(result => result));  
  }

  updateCoordinates(event, data, palette, hex, name , imageName , plantId , selectedBuilding , selectedDepartment , type){
   
    let reqPay ;
    if(type.trim() === "building"){
     reqPay = plantId;
    }else if (type.trim() === "department"){
     reqPay = selectedBuilding;
    }else if(type.trim() === "equipment"){
      reqPay = selectedDepartment;
    }
   
   
    let url = `${environment.apiBaseUrl}/updatecoordinate/${plantId}?assettype=${event}&assetid=${reqPay}&imagepath=${imageName}`;
    // let formattedURL = this.getFormatURL(url, plantId, type, id, name , );
    let json = {
      data,
      palette,
      hex,
      name
    }
     return this.http.put<any>(url , json)
     .pipe(map(result => result));   
  }

}