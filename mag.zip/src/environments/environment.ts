// New Subscription
export const environment = {
  webApp : { magneto : false, pxEVA : true},
  production: true,
  version : 'v 1.1.128',
  mapBoxAccessToken : "pk.eyJ1IjoiaW50ZXJnYWxhY3RpY2tyYWlnb3IiLCJhIjoiY2ptN3ZkeW9oNGxoNzNxb2dpNG9rcHZ2cyJ9.k0yACuymc3N9deSV0b6g3A",
  evaCategory : "https://mx-magneto-dev.azure-api.net/mx-category-service-dev",
  evaAuth : "https://mx-magneto-dev.azure-api.net/mx-magneto-security-service-dev/security",
  evaBaseURL : 'https://mx-magneto-dev.azure-api.net/mx-device-service',
  authUrl: 'https://mx-magneto-dev.azure-api.net/mx-magneto-functions-dev/security',
  apiBaseUrl : 'https://mx-magneto-dev.azure-api.net/mx-magneto-functions-dev/plants',
  apiBaseUserUrl : 'https://mx-magneto-dev.azure-api.net/mx-magneto-functions-dev',
  kpiBaseURL : "https://mx-magneto-dev.azure-api.net/mx-kpiservice-dev",
  apiBaseAssetUrl : 'https://mx-magneto-dev.azure-api.net/mx-magneto-functions-dev/assets',
  subscriptionKey : 'c53e4db0badb48cf89f11f0514a4370c', // 'c53e4db0badb48cf89f11f0514a4370c ',  
  applicationId : "aab92b01-68b7-4511-a793-c6994d8a3012",
  excelTemplatePath : "https://mxmagnetostoragedev.blob.core.windows.net/site-hierarchy/SiteHierarchyTemplate.xlsx",
  excelUserTemplatePath : "https://mxmagnetostoragedev.blob.core.windows.net/users-bulk-import/Bulk_Import_Template_Design.xlsx",
  EULA: "https://www.eaton.com/content/dam/eaton/products/low-voltage-power-distribution-controls-systems/power-energy-meters/pxeva-pxbig/pcd-cloud-end-user-license-agreement.pdf",
  privacyPolicy: "https://www.eaton.com/content/dam/eaton/products/low-voltage-power-distribution-controls-systems/power-energy-meters/pxeva-pxbig/pcd-cloud-privacy-policy.pdf",
  pdfCopyRightMsg : "Copyright © 2019 Eaton. All Rights Reserved. Eaton, PredictPulse, and PulseScore are registered trademarks. All other trademarks are property of their respective owners."
};