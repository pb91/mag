// New Subscription
export const environment = {
  webApp : { magneto : true, pxEVA : false},
  production: true,
  version : 'v 1.1.128',
  mapBoxAccessToken : "pk.eyJ1IjoiaW50ZXJnYWxhY3RpY2tyYWlnb3IiLCJhIjoiY2ptN3ZkeW9oNGxoNzNxb2dpNG9rcHZ2cyJ9.k0yACuymc3N9deSV0b6g3A",
  evaCategory : "https://mx-magneto-dev.azure-api.net/mx-category-service-demo",
  evaAuth : "https://mx-magneto-demo.azure-api.net/mx-magneto-security-service-demo/security",
  evaBaseURL : 'https://mx-magneto-demo.azure-api.net/mx-deviceservice-demo',
  authUrl: 'https://mx-magneto-demo.azure-api.net/mx-magneto-functions-demo/security',
  apiBaseUrl : 'https://mx-magneto-demo.azure-api.net/mx-magneto-functions-demo/plants',
  apiBaseUserUrl : 'https://mx-magneto-demo.azure-api.net/mx-magneto-functions-demo',
  kpiBaseURL : "https://mx-magneto-demo.azure-api.net/mx-kpiservice-demo",
  apiBaseAssetUrl : 'https://mx-magneto-demo.azure-api.net/mx-magneto-functions-demo/assets',
  subscriptionKey : '2d61e1e234b0411c9153adfa809cfcc6',
  applicationId : "e0920bc9-51b6-4032-81fd-d180851dd058",
  excelTemplatePath : "https://mxmagnetostoragedemo.blob.core.windows.net/site-hierarchy/SiteHierarchyTemplate.xlsx ",
  excelUserTemplatePath : "https://mxmagnetostoragedemo.blob.core.windows.net/users-bulk-import/Bulk_Import_Template_Design.xlsx",
  pdfCopyRightMsg : "Copyright © 2019 Eaton. All Rights Reserved. Eaton, PredictPulse, and PulseScore are registered trademarks. All other trademarks are property of their respective owners.",
  EULA: "https://www.eaton.com/content/dam/eaton/products/low-voltage-power-distribution-controls-systems/power-energy-meters/pxeva-pxbig/pcd-cloud-end-user-license-agreement.pdf",
  privacyPolicy: "https://www.eaton.com/content/dam/eaton/products/low-voltage-power-distribution-controls-systems/power-energy-meters/pxeva-pxbig/pcd-cloud-privacy-policy.pdf"
};